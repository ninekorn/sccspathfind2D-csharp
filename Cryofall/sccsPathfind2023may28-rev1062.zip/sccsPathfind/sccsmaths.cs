﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtomicTorch.CBND.CoreMod.Scripts.sccsPathfind
{
    public static class sccsmaths
    {

        public static float DegreeToRadian(float angle)
        {
            return (float)(Math.PI * angle / 180.0f);
        }

        public static float RadianToDegree(float angle)
        {
            return (float)(angle * (180.0f / Math.PI));
        }

        public static float Dot(float aX, float aY, float bX, float bY)
        {
            return (aX * bX) + (aY * bY);
        }

        public static float normalizeradiansfromradians(float radians)
        {
            float degrees = RadianToDegree(radians);
            degrees = degrees % 180;
            if (degrees < 0)
            {
                degrees += 180;
            }
            return DegreeToRadian(degrees);  //DegreeToRadian(degrees);
        }

        public static float normalizedegreesfromdegrees(float degrees)
        {
            //float degrees = RadianToDegree(radians);
            degrees = degrees % 180;
            if (degrees < 0)
            {
                degrees += 180;
            }
            return degrees;  //DegreeToRadian(degrees);
        }
    }
}
