﻿namespace AtomicTorch.CBND.CoreMod.Characters.Mobs
{
    using AtomicTorch.CBND.CoreMod.CharacterSkeletons;
    using AtomicTorch.CBND.CoreMod.Items.Devices;
    using AtomicTorch.CBND.CoreMod.Items.Food;
    using AtomicTorch.CBND.CoreMod.Items.Generic;
    using AtomicTorch.CBND.CoreMod.Items.Weapons.MobWeapons;
    using AtomicTorch.CBND.CoreMod.Skills;
    using AtomicTorch.CBND.CoreMod.Systems.Droplists;


    using AtomicTorch.CBND.CoreMod.Characters;
    using AtomicTorch.CBND.CoreMod.CharacterSkeletons;
    using AtomicTorch.CBND.CoreMod.ConsoleCommands.Admin;
    using AtomicTorch.CBND.CoreMod.Items.Generic;
    using AtomicTorch.CBND.CoreMod.Items.Weapons.MobWeapons;
    using AtomicTorch.CBND.CoreMod.Scripts.sccsPathfind;
    using AtomicTorch.CBND.CoreMod.SoundPresets;
    using AtomicTorch.CBND.CoreMod.Systems.Droplists;
    using AtomicTorch.CBND.GameApi.Data.Characters;
    using AtomicTorch.CBND.GameApi.Data.Physics;
    using AtomicTorch.CBND.GameApi.Scripting;
    using AtomicTorch.CBND.GameApi.ServicesServer;
    using AtomicTorch.GameEngine.Common.DataStructures;
    using AtomicTorch.GameEngine.Common.Primitives;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using static sccspathfindstructs;
    using sccsvec2int = sccspathfindstructs.sccsvec2int;


    public class MobMutantHyena : MobHyena
    {
        public override bool AiIsRunAwayFromHeavyVehicles => false;

        public override double MobKillExperienceMultiplier => 5.0;

        public override string Name => "Mutated hyena";

        public override double StatDefaultHealthMax => 150;

        public override double StatMoveSpeed => 2.5;

        protected override void PrepareProtoCharacterMob(
            out ProtoCharacterSkeleton skeleton,
            ref double scale,
            DropItemsList lootDroplist)
        {
            skeleton = GetProtoEntity<SkeletonMutantHyena>();

            // primary loot
            lootDroplist
                .Add<ItemInsectMeatRaw>(count: 2, countRandom: 2)
                .Add<ItemFur>(count: 1)
                .Add<ItemBones>(count: 1, countRandom: 1)
                // requires device
                .Add<ItemKeiniteRaw>(count: 4,
                                     countRandom: 2,
                                     condition: ItemKeiniteCollector.ConditionHasDeviceEquipped);

            // extra loot
            lootDroplist.Add(condition: SkillHunting.ServerRollExtraLoot,
                             nestedList: new DropItemsList(outputs: 1)
                                         .Add<ItemMeatRaw>(count: 1)
                                         .Add<ItemFur>(count: 1)
                                         .Add<ItemBones>(count: 1)
                                         .Add<ItemAnimalFat>(count: 1));
        }

        protected override void ServerInitializeCharacterMob(ServerInitializeData data)
        {
            base.ServerInitializeCharacterMob(data);

            var weaponProto = GetProtoEntity<ItemWeaponMobGenericMedium>();
            data.PrivateState.WeaponState.SharedSetWeaponProtoOnly(weaponProto);
            data.PublicState.SharedSetCurrentWeaponProtoOnly(weaponProto);
        }
        /*
        protected override void ServerUpdateMob(ServerUpdateData data)
        {
            var character = data.GameObject;

            ServerCharacterAiHelper.ProcessAggressiveAi(
                character,
                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                isRetreating: false,
                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                distanceRetreat: 0,
                distanceEnemyTooClose: 1,
                distanceEnemyTooFar: 8,
                movementDirection: out var movementDirection,
                rotationAngleRad: out var rotationAngleRad);

            this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
        }*/




        //AtomicTorch.CBND.CoreMod.ConsoleCommands.Debug.ConsoleDebugTestNotification debug = new ConsoleCommands.Debug.ConsoleDebugTestNotification();
        sccspathfind pathfindscript;
        int startpathfindmainswtc = 0;
        sccsvec2float initialpathfindstartpos = new sccsvec2float();

        sccsvec2float initialpathfindtargetpos = new sccsvec2float();

        sccsvec2float lastinitialpathfindtargetpos = new sccsvec2float();

        int swtcdebug = 0;

        float distnpctoplayersqrtlast = 0;
        System.Collections.Generic.List<sccsvec2int> listofobstaclesinit = new System.Collections.Generic.List<sccsvec2int>();
        ITempList<TestResult> obstacles;


        System.Collections.Generic.List<sccsvec2int> listofobstaclesonthewaytwo = new System.Collections.Generic.List<sccsvec2int>();

        System.Collections.Generic.List<sccsvec2int> listofobstaclesontheway = new System.Collections.Generic.List<sccsvec2int>();
        ITempList<TestResult> obstaclesontheway;
        ITempList<TestResult> obstaclesonthewaytwo;

        int swtcobstaclesontheway = 0;

        sccsvec2float npcposlast = new sccsvec2float();

        float lastdistsquared = 0;
        Vector2F directionnpctopathfindnodef = new Vector2F(0, 0);
        ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
        float distsquared = 0;
        sccsvec2float playerpos;
        sccsvec2float npcpos;

        ICharacter playercharacter;

        float disttonode0last = 0;
        Vector2D playercharactercenter;
        Vector2D npcCharacterCenter;

        int npcmovementtype = 0;
        float disttonode = 0;

        sccsvec2float lastcurrentnpcpos = new sccsvec2float();

        //List<sccspathfindnode> pathfindretracedpath = new List<sccspathfindnode>();
        int pathfindretracedpathswtc = 0;
        sccspathfindnode poppednode;
        bool haspopped = false;
        bool lasthaspopped = false;
        int haspoppedcounter = 0;
        int lasthaspoppedcounter = 0;

        int haspoppedcountermax = 1;

        sccsvec2float lastcurrentnpcdirection = new sccsvec2float();
        sccsvec2float currentnpcdirection = new sccsvec2float();

        Vector2D frontdirectionposition = new Vector2D();
        //Vector2D frontdirectionpositionnotnormalized = new Vector2D();
        double frontdirectionpositionnotnormalized = 0.0;
        float lastdistnpctoplayersqrt = 0;
        float distnpctoplayersqrt = 0;

        int hasreachedpathend = 0;
        int firstnodeofpathfindpoppedswtc = 0;
        int decrementcounterforpath = 0;

        int pathfindmaincounter = 0;
        int pathfindmaincountermax = 0;//LEAVE AT 0 TO HAVE 1 ITERATION PER FRAME. THE HIGHER THE VALUE, THE LESS TIMES THE PATHFIND LOGIC IS ENGAGED.logic is currently broken unless it's at zero

        int haschasedcharacter = 0;

        int hasreachingnodestuckframecounter = 0;
        int hasreachingnodestuckframecountermax = 30;

        int hasreachedandattackedplayer = 0;
        int lasthasreachedandattackedplayer = 0;

        protected override void ServerUpdateMob(ServerUpdateData data)
        {
            engagepathfindaction(data);
        }

        private void engagepathfindaction(ServerUpdateData data)
        {

            var npccharacter = data.GameObject;
            npcmovementtype = 0;
            //haspopped = false;

            if (startpathfindmainswtc == 0)
            {
                if (pathfindmaincountermax < 0)
                {
                    pathfindmaincountermax = 0;
                }

                pathfindscript = new sccspathfind();
                pathfindscript.pathfindoptionhgf = 1;//0FCOST//1HCOST//2MISCFCOSTISH
                pathfindscript.debugtoconsolemsg = 0; // debugs messages to the console.
                pathfindscript.pathfindimax = 3; //loops the pathfind 3 times per frame. //9. //PUT AT 1 MINIMUM
                pathfindscript.hasstartedpathfindcountermax = 75;//IF THE PATHFIND ITERATOR PATHFINDIMAX GOES OVER 75 SEEKER NODE ATTEMPT TO FIND THE TARGET. RESTART THE PATHFIND AUTOMATICALLY
                pathfindscript.framecounterpathfindmax = 0;//LEAVE AT 0 TO HAVE 1 ITERATION PER FRAME. INCREASE TO LET MULTIPLE FRAMES PASS BEFORE LETTING 1 PASS OF PATHFIND THROUGH.
                pathfindscript.createpathfindvisuals = 0;//NOTHING WORKING HERE FOR THE MOMENT.
                pathfindscript.startpathfind = 1;//LEAVE AT 1 SO THAT THE MOMENT THAT THE LOOPPATHFIND FUNCTION IS CALLED, IT WILL AUTOMATICALLY ENGAGE THE REST OF THE PATHFIND LOGIC.
                pathfindscript.maxRetracePath = 75;//IF THE RETRACE PATH IS HIGHER THAN x INTEGER, the path is too long... don't retrace.
                pathfindscript.retracedpathlistcountermaxloop = 1;//retrace only 1 reseeker node per frame. or x integer per frame to loop the retrace path faster.

                if (npccharacter != null)
                {
                    if (npccharacter.PhysicsBody != null)
                    {
                        npcCharacterCenter = npccharacter.Position + npccharacter.PhysicsBody.CenterOffset;

                        playercharacter = ServerCharacterAiHelper.GetClosestTargetPlayer(npccharacter);

                        if (playercharacter != null)
                        {
                            if (playercharacter.PhysicsBody != null)
                            {
                                playercharactercenter = playercharacter.Position + playercharacter.PhysicsBody.CenterOffset;

                                playerpos = new sccsvec2float();
                                playerpos.x = (float)playercharactercenter.X;
                                playerpos.y = (float)playercharactercenter.Y;

                                npcpos = new sccsvec2float();
                                npcpos.x = (float)npcCharacterCenter.X;
                                npcpos.y = (float)npcCharacterCenter.Y;

                                if (pathfindscript != null)
                                {
                                    distsquared = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

                                    lastdistsquared = distsquared;
                                }
                            }
                        }
                    }
                }
                startpathfindmainswtc = 1;
            }


            if (pathfindmaincounter >= pathfindmaincountermax)
            {
                if (npccharacter != null)
                {
                    if (npccharacter.PhysicsBody != null)
                    {
                        npcCharacterCenter = npccharacter.Position + npccharacter.PhysicsBody.CenterOffset;

                        playercharacter = ServerCharacterAiHelper.GetClosestTargetPlayer(npccharacter);

                        if (playercharacter != null)
                        {
                            if (playercharacter.PhysicsBody != null)
                            {
                                playercharactercenter = playercharacter.Position + playercharacter.PhysicsBody.CenterOffset;

                                playerpos = new sccsvec2float();
                                playerpos.x = (float)playercharactercenter.X;
                                playerpos.y = (float)playercharactercenter.Y;

                                npcpos = new sccsvec2float();
                                npcpos.x = (float)npcCharacterCenter.X;
                                npcpos.y = (float)npcCharacterCenter.Y;

                                if (pathfindscript != null)
                                {
                                    distsquared = pathfindscript.GetDistancefloat2d(playerpos, npcpos);
                                    //lastdistsquared = distsquared;

                                    if (distsquared < 75)
                                    {
                                        distnpctoplayersqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);

                                        //GETTING THE CURRENT DIRECTION OF THE NPC BASED ON THE LASTFRAME NPC POSITION AND CURRENT NPC POSITION
                                        if (npcposlast.x != float.NaN && npcposlast.y != float.NaN)
                                        {
                                            currentnpcdirection = new sccsvec2float();
                                            currentnpcdirection.x = npcpos.x - npcposlast.x;
                                            currentnpcdirection.y = npcpos.y - npcposlast.y;

                                            float distnpcposcurrenttonpcposlast = pathfindscript.GetDistancefloat2dsqrt(npcposlast, npcpos);

                                            currentnpcdirection.x /= distnpcposcurrenttonpcposlast;
                                            currentnpcdirection.y /= distnpcposcurrenttonpcposlast;

                                            //sccsvec2float posinfront = new sccsvec2float();
                                            //posinfront.x = npcpos.x + currentnpcdirection.x;
                                            //posinfront.y = npcpos.y + currentnpcdirection.y;

                                            //float disttofrontpoint = pathfindscript.GetDistancefloat2dsqrt(posinfront, npcpos);

                                            frontdirectionposition = new Vector2D(npcpos.x + currentnpcdirection.x, npcpos.y + currentnpcdirection.y); // - new Vector2D(npcpos.x, npcpos.y)

                                            Vector2D posnpctoposfrontnpc = new Vector2D(npcpos.x + currentnpcdirection.x, npcpos.y + currentnpcdirection.y) - new Vector2D(npcpos.x, npcpos.y);

                                            Vector2D dirforlength = new Vector2D(currentnpcdirection.x, currentnpcdirection.y);

                                            frontdirectionpositionnotnormalized = dirforlength.Length;
                                            //frontdirectionposition = frontdirectionposition.Normalized;
                                        }
                                        //GETTING THE CURRENT DIRECTION OF THE NPC BASED ON THE LASTFRAME NPC POSITION AND CURRENT NPC POSITION


                                        if (distnpctoplayersqrt > 1.5f)
                                        {
                                            sccsvec2float dirnpctoplayer0 = new sccsvec2float();
                                            dirnpctoplayer0.x = playerpos.x - npcpos.x;
                                            dirnpctoplayer0.y = playerpos.y - npcpos.y;

                                            dirnpctoplayer0.x /= distnpctoplayersqrt;
                                            dirnpctoplayer0.y /= distnpctoplayersqrt;


                                            sccsvec2float dirright0 = new sccsvec2float();
                                            dirright0.x = 1.0f;
                                            dirright0.y = 0.0f;

                                            float anglerad0 = Vector2F.AngleDeg(new Vector2F(dirnpctoplayer0.x, dirnpctoplayer0.y), new Vector2F(dirright0.x, dirright0.y));

                                            //pathfindscript.startpathfind = 1;


                                            Vector2F dirtoplayer = new Vector2F(dirnpctoplayer0.x, dirnpctoplayer0.y);

                                            float thedotnpcdirtoplayerdirandnpcdirtonode = sccsmaths.Dot(dirnpctoplayer0.x, dirnpctoplayer0.y, currentnpcdirection.x, currentnpcdirection.y);


                                            //INITIALIZING PATHFIND UNWALKABLE TILES... ONLY WHEN THE PATHFIND IS IN STATUS #1
                                            //INITIALIZING PATHFIND UNWALKABLE TILES... ONLY WHEN THE PATHFIND IS IN STATUS #1
                                            if (pathfindscript.startpathfind == 1)
                                            {
                                                if (frontdirectionpositionnotnormalized > 0.0)
                                                {
                                                    if (thedotnpcdirtoplayerdirandnpcdirtonode != float.NaN)
                                                    {
                                                        if (thedotnpcdirtoplayerdirandnpcdirtonode < 0.25f)
                                                        {
                                                            pathfindscript.startpathfind = 1;
                                                        }
                                                    }
                                                }


                                                var character0 = data.GameObject;
                                                var currentStats0 = data.PublicState.CurrentStats;


                                                if (thedotnpcdirtoplayerdirandnpcdirtonode < 0.25f)
                                                {
                                                    sccsvec2float dirright = new sccsvec2float();
                                                    dirright.x = 1.0f;
                                                    dirright.y = 0.0f;

                                                    sccsvec2float dirnpctoplayer = new sccsvec2float();
                                                    dirnpctoplayer.x = playerpos.x - npcpos.x;
                                                    dirnpctoplayer.y = playerpos.y - npcpos.y;

                                                    dirnpctoplayer.x /= distnpctoplayersqrt;
                                                    dirnpctoplayer.y /= distnpctoplayersqrt;

                                                    float anglerad = Vector2F.AngleDeg(new Vector2F(dirnpctoplayer.x, dirnpctoplayer.y), new Vector2F(dirright.x, dirright.y));

                                                    ServerCharacterAiHelper.ProcessRetreatingAi(character0, 0.25f, out var movementDirection0, out var rotationAngleRad0); //distnpctoplayersqrt

                                                    this.ServerSetMobInput(character0, movementDirection0, anglerad);
                                                }


                                                ServerCharacterAiHelper.ProcessAggressiveAi(
                                                  character0,
                                                  targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                                  isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                                  isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                  distanceRetreat: 7,
                                                  distanceEnemyTooClose: 1,
                                                  distanceEnemyTooFar: 3.5,
                                                  movementDirection: out var movementDirection,
                                                  rotationAngleRad: out var rotationAngleRad);

                                                this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);




                                                hasreachingnodestuckframecounter = 0;
                                                haschasedcharacter = 0;
                                                hasreachedpathend = 0;
                                                decrementcounterforpath = 0;
                                                haspopped = false;
                                                firstnodeofpathfindpoppedswtc = 0;
                                                swtcobstaclesontheway = 0;
                                                pathfindretracedpathswtc = 0;
                                                haspoppedcounter = 0;

                                                var physicsSpace = npccharacter.PhysicsBody.PhysicsSpace;

                                                obstacles = physicsSpace.TestLine(
                                                      npcCharacterCenter,
                                                      playercharactercenter,
                                                      CollisionGroup.Default,
                                                      sendDebugEvent: true);

                                                if (listofobstaclesinit != null)
                                                {
                                                    listofobstaclesinit.Clear();
                                                }
                                                else
                                                {
                                                    listofobstaclesinit = new List<sccsvec2int>();
                                                }


                                                if (obstacles != null)
                                                {
                                                    if (obstacles.Count > 0)
                                                    {
                                                        var isTraversableTile = true;
                                                        foreach (var result in obstacles.AsList())
                                                        {
                                                            var body = result.PhysicsBody;
                                                            if (body.AssociatedProtoTile is not null)
                                                            {
                                                                // untraversable tile - a cliff or water
                                                                isTraversableTile = false;
                                                                //break;
                                                            }

                                                            if (body.AssociatedWorldObject is not null)
                                                            {
                                                                // an obstacle - a world object
                                                                isTraversableTile = false;
                                                                //break;
                                                            }

                                                            if (isTraversableTile == false)
                                                            {
                                                                Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                                                sccsvec2int posofobstacle = new sccsvec2int();
                                                                posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                                                                posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                                                                listofobstaclesinit.Add(posofobstacle);
                                                            }
                                                        }
                                                    }
                                                }

                                                initialpathfindstartpos = npcpos;
                                                initialpathfindtargetpos = playerpos;

                                                //INITILIASES THE PATHFIND. THE STARTPATHFIND VARIABLE BECOMES 2 INSIDE THE PATHFIND SCRIPT AFTER ONE PASS
                                                pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);
                                                //INITILIASES THE PATHFIND. THE STARTPATHFIND VARIABLE BECOMES 2 INSIDE THE PATHFIND SCRIPT AFTER ONE PASS
                                            }
                                            //INITIALIZING PATHFIND UNWALKABLE TILES... ONLY WHEN THE PATHFIND IS IN STATUS #1
                                            //INITIALIZING PATHFIND UNWALKABLE TILES... ONLY WHEN THE PATHFIND IS IN STATUS #1


                                            //WHILE THE PATHFIND IS NOT IN STATUS #4, LOOP PATHFIND. STATUS 4 IS TARGET POS FOUND AND PATH RETRACED.
                                            //WHILE THE PATHFIND IS NOT IN STATUS #4, LOOP PATHFIND. STATUS 4 IS TARGET POS FOUND AND PATH RETRACED.
                                            else if (pathfindscript.startpathfind == 2 || pathfindscript.startpathfind == 3)
                                            {
                                                pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);
                                            }
                                            //WHILE THE PATHFIND IS NOT IN STATUS #4, LOOP PATHFIND. STATUS 4 IS TARGET POS FOUND AND PATH RETRACED.
                                            //WHILE THE PATHFIND IS NOT IN STATUS #4, LOOP PATHFIND. STATUS 4 IS TARGET POS FOUND AND PATH RETRACED.

                                            else if (pathfindscript.startpathfind == 4)
                                            {
                                                //distnpctoplayersqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);

                                                //TRYING TO REMOVE A FIRST NODE
                                                if (pathfindretracedpathswtc == 0)
                                                {
                                                    if (pathfindscript.retracedpathlist != null)
                                                    {
                                                        if (pathfindscript.retracedpathlist.Count > 1)
                                                        {
                                                            if (firstnodeofpathfindpoppedswtc == 0)
                                                            {
                                                                decrementcounterforpath = pathfindscript.retracedpathlist.Count;

                                                                firstnodeofpathfindpoppedswtc = 1;
                                                            }

                                                            haspopped = pathfindscript.retracedpathlist.TryPop(out poppednode);
                                                            hasreachingnodestuckframecounter = 0;

                                                            haspoppedcounter++;
                                                            decrementcounterforpath--;


                                                            pathfindretracedpathswtc = 1;
                                                        }
                                                        else
                                                        {
                                                            if (distnpctoplayersqrt <= 1.5f)
                                                            {
                                                                hasreachingnodestuckframecounter = 0;


                                                                hasreachedandattackedplayer = 1;
                                                                var character1 = data.GameObject;
                                                                var currentStats1 = data.PublicState.CurrentStats;

                                                                ServerCharacterAiHelper.ProcessAggressiveAi(
                                                                    character1,
                                                                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character1),
                                                                    isRetreating: currentStats1.HealthCurrent < currentStats1.HealthMax / 3,
                                                                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                                    distanceRetreat: 7,
                                                                    distanceEnemyTooClose: 1,
                                                                    distanceEnemyTooFar: 3.5,
                                                                    movementDirection: out var movementDirection1,
                                                                    rotationAngleRad: out var rotationAngleRad1);

                                                                this.ServerSetMobInput(character1, movementDirection1, rotationAngleRad1);

                                                            }
                                                            else
                                                            {
                                                                pathfindscript.startpathfind = 1;
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (distnpctoplayersqrt <= 1.5f)
                                                        {
                                                            hasreachingnodestuckframecounter = 0;

                                                            hasreachedandattackedplayer = 1;
                                                            var character1 = data.GameObject;
                                                            var currentStats1 = data.PublicState.CurrentStats;

                                                            ServerCharacterAiHelper.ProcessAggressiveAi(
                                                                character1,
                                                                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character1),
                                                                isRetreating: currentStats1.HealthCurrent < currentStats1.HealthMax / 3,
                                                                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                                distanceRetreat: 7,
                                                                distanceEnemyTooClose: 1,
                                                                distanceEnemyTooFar: 3.5,
                                                                movementDirection: out var movementDirection1,
                                                                rotationAngleRad: out var rotationAngleRad1);

                                                            this.ServerSetMobInput(character1, movementDirection1, rotationAngleRad1);

                                                        }
                                                        else
                                                        {
                                                            pathfindscript.startpathfind = 1;
                                                        }
                                                    }
                                                }
                                                //TRYING TO REMOVE A FIRST NODE
                                            }
                                            else
                                            {

                                            }


                                            if (decrementcounterforpath <= 0 && firstnodeofpathfindpoppedswtc == 1)
                                            {
                                                hasreachedandattackedplayer = 1;


                                                if (distnpctoplayersqrt <= 1.5f)
                                                {
                                                    hasreachingnodestuckframecounter = 0;


                                                    var character1 = data.GameObject;
                                                    var currentStats1 = data.PublicState.CurrentStats;

                                                    ServerCharacterAiHelper.ProcessAggressiveAi(
                                                        character1,
                                                        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character1),
                                                        isRetreating: currentStats1.HealthCurrent < currentStats1.HealthMax / 3,
                                                        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                        distanceRetreat: 7,
                                                        distanceEnemyTooClose: 1,
                                                        distanceEnemyTooFar: 3.5,
                                                        movementDirection: out var movementDirection1,
                                                        rotationAngleRad: out var rotationAngleRad1);

                                                    this.ServerSetMobInput(character1, movementDirection1, rotationAngleRad1);

                                                    pathfindretracedpathswtc = 0;
                                                    hasreachedandattackedplayer = 1;
                                                    firstnodeofpathfindpoppedswtc = -2;

                                                }
                                                else
                                                {

                                                    pathfindscript.startpathfind = 1;

                                                }
                                            }
                                            else
                                            {

                                            }



                                            if (firstnodeofpathfindpoppedswtc == 1)
                                            {

                                                if (hasreachingnodestuckframecounter >= hasreachingnodestuckframecountermax)
                                                {

                                                    pathfindscript.startpathfind = 1;
                                                    firstnodeofpathfindpoppedswtc = 0;
                                                    hasreachingnodestuckframecounter = 0;
                                                }


                                                if (haspopped)
                                                {

                                                    sccsvec2float thenodepos = new sccsvec2float();
                                                    thenodepos.x = poppednode.worldpositionx;
                                                    thenodepos.y = poppednode.worldpositiony;

                                                    sccsvec2float npctoinitnpcdiff = new sccsvec2float();
                                                    npctoinitnpcdiff.x = (int)Math.Round((double)npcpos.x) - (int)Math.Round((double)initialpathfindstartpos.x);
                                                    npctoinitnpcdiff.y = (int)Math.Round((double)npcpos.y) - (int)Math.Round((double)initialpathfindstartpos.y);

                                                    disttonode = pathfindscript.GetDistancefloat2dsqrt(npctoinitnpcdiff, thenodepos);

                                                    sccsvec2float dirnodetoinitpos = new sccsvec2float();
                                                    dirnodetoinitpos.x = thenodepos.x - npctoinitnpcdiff.x; //-thenodepos.x;//
                                                    dirnodetoinitpos.y = thenodepos.y - npctoinitnpcdiff.y; //-thenodepos.y;//

                                                    //float hypothenuse = disttonode;
                                                    //float opposite = dirnodetoinitpos.y;
                                                    //float adjacent = dirnodetoinitpos.x;
                                                    //float rotationangledeg = 0;

                                                    if (disttonode == 0 || disttonode < 0.75f)
                                                    {
                                                        if (distnpctoplayersqrt <= 1.5f)
                                                        {
                                                            hasreachingnodestuckframecounter = 0;
                                                            hasreachedandattackedplayer = 1;
                                                            var character1 = data.GameObject;
                                                            var currentStats1 = data.PublicState.CurrentStats;

                                                            ServerCharacterAiHelper.ProcessAggressiveAi(
                                                                character1,
                                                                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character1),
                                                                isRetreating: currentStats1.HealthCurrent < currentStats1.HealthMax / 3,
                                                                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                                distanceRetreat: 7,
                                                                distanceEnemyTooClose: 1,
                                                                distanceEnemyTooFar: 3.5,
                                                                movementDirection: out var movementDirection1,
                                                                rotationAngleRad: out var rotationAngleRad1);

                                                            this.ServerSetMobInput(character1, movementDirection1, rotationAngleRad1);
                                                        }
                                                        else
                                                        {

                                                        }

                                                        pathfindretracedpathswtc = 0;
                                                    }
                                                    else
                                                    {

                                                        if (disttonode != float.NaN && disttonode != 0)
                                                        {
                                                            dirnodetoinitpos.x /= disttonode;
                                                            dirnodetoinitpos.y /= disttonode;

                                                            directionnpctopathfindnodef = new Vector2F(dirnodetoinitpos.x, dirnodetoinitpos.y);

                                                            if (directionnpctopathfindnodef.X != float.NaN && directionnpctopathfindnodef.Y != float.NaN)
                                                            {

                                                                if (directionnpctopathfindnodef.X == 0 && directionnpctopathfindnodef.Y == 0)
                                                                {
                                                                    pathfindretracedpathswtc = 0;
                                                                    pathfindscript.startpathfind = 1;
                                                                }
                                                                else
                                                                {
                                                                    sccsvec2float dirnpctoplayer = new sccsvec2float();
                                                                    dirnpctoplayer.x = playerpos.x - npcpos.x;
                                                                    dirnpctoplayer.y = playerpos.y - npcpos.y;

                                                                    dirnpctoplayer.x /= distnpctoplayersqrt;
                                                                    dirnpctoplayer.y /= distnpctoplayersqrt;


                                                                    sccsvec2float dirright = new sccsvec2float();
                                                                    dirright.x = 1.0f;
                                                                    dirright.y = 0.0f;

                                                                    float anglerad = Vector2F.AngleDeg(new Vector2F(directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y), new Vector2F(dirright.x, dirright.y));

                                                                    //pathfindscript.startpathfind = 1;

                                                                    var character = data.GameObject;
                                                                    var currentStats = data.PublicState.CurrentStats;

                                                                    ServerCharacterAiHelper.ProcessAggressiveAi(
                                                                    character,
                                                                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                                                    isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                                                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                                    distanceRetreat: 7,
                                                                    distanceEnemyTooClose: 1,
                                                                    distanceEnemyTooFar: 3.5, //distnpctoplayersqrt + 1.0f
                                                                    movementDirection: out var movementDirection,
                                                                    rotationAngleRad: out var rotationAngleRad);


                                                                    this.ServerSetMobInput(character, directionnpctopathfindnodef, anglerad);

                                                                    //float thedotnpcdirtoplayerdirandnpcdirtonode = Dot(dirnpctoplayer.x, dirnpctoplayer.y, directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y);


                                                                    if (((int)npctoinitnpcdiff.x == poppednode.worldpositionx && (int)npctoinitnpcdiff.y == poppednode.worldpositiony) ||
                                                                   (int)Math.Round((decimal)npcpos.x) == poppednode.worldpositionx + (int)Math.Round((decimal)initialpathfindstartpos.x) &&
                                                                   (int)Math.Round((decimal)npcpos.y) == poppednode.worldpositiony + (int)Math.Round((decimal)initialpathfindstartpos.y))
                                                                    {
                                                                        pathfindretracedpathswtc = 0;
                                                                    }
                                                                }
                                                            }
                                                            else
                                                            {
                                                                pathfindretracedpathswtc = 0;
                                                                pathfindscript.startpathfind = 1;

                                                            }
                                                        }
                                                        else
                                                        {
                                                            pathfindretracedpathswtc = 0;
                                                            pathfindscript.startpathfind = 1;
                                                        }
                                                    }
                                                }
                                                else
                                                {

                                                }

                                                hasreachingnodestuckframecounter++;
                                            }
                                            else
                                            {

                                            }
                                        }
                                        else if (distnpctoplayersqrt <= 1.5f)
                                        {
                                            hasreachedandattackedplayer = 1;
                                            hasreachingnodestuckframecounter = 0;
                                            var character1 = data.GameObject;
                                            var currentStats1 = data.PublicState.CurrentStats;

                                            ServerCharacterAiHelper.ProcessAggressiveAi(
                                                character1,
                                                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character1),
                                                isRetreating: currentStats1.HealthCurrent < currentStats1.HealthMax / 3,
                                                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                distanceRetreat: 7,
                                                distanceEnemyTooClose: 1,
                                                distanceEnemyTooFar: 3.5,
                                                movementDirection: out var movementDirection1,
                                                rotationAngleRad: out var rotationAngleRad1);

                                            this.ServerSetMobInput(character1, movementDirection1, rotationAngleRad1);


                                        }

                                    }
                                    else
                                    {
                                        hasreachedandattackedplayer = 1;

                                        hasreachingnodestuckframecounter = 0;
                                        var character0 = data.GameObject;
                                        var currentStats0 = data.PublicState.CurrentStats;

                                        ServerCharacterAiHelper.ProcessAggressiveAi(
                                            character0,
                                            targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                            isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                            isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                            distanceRetreat: 7,
                                            distanceEnemyTooClose: 1,
                                            distanceEnemyTooFar: 3.5, //distnpctoplayersqrt + 1.0f
                                            movementDirection: out var movementDirection,
                                            rotationAngleRad: out var rotationAngleRad);

                                        this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);
                                        //pathfindscript.startpathfind = 1;

                                    }

                                }
                                else
                                {
                                    var character = data.GameObject;
                                    var currentStats = data.PublicState.CurrentStats;

                                    ServerCharacterAiHelper.ProcessAggressiveAi(
                                        character,
                                        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                        isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                        distanceRetreat: 7,
                                        distanceEnemyTooClose: 1,
                                        distanceEnemyTooFar: 3.5,
                                        movementDirection: out var movementDirection,
                                        rotationAngleRad: out var rotationAngleRad);

                                    this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
                                    //pathfindscript.startpathfind = 1;

                                    //npcmovementtype = 1;
                                }

                                npcposlast = npcpos;
                            }

                            if (playercharacter.IsDestroyed)
                            {
                                var character0 = data.GameObject;
                                var currentStats0 = data.PublicState.CurrentStats;

                                ServerCharacterAiHelper.ProcessAggressiveAi(
                                    character0,
                                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                    isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                    distanceRetreat: 7,
                                    distanceEnemyTooClose: 1,
                                    distanceEnemyTooFar: 3.5,
                                    movementDirection: out var movementDirection,
                                    rotationAngleRad: out var rotationAngleRad);

                                this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);
                            }

                        }
                        else
                        {
                            var character0 = data.GameObject;
                            var currentStats0 = data.PublicState.CurrentStats;

                            ServerCharacterAiHelper.ProcessAggressiveAi(
                                character0,
                                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                distanceRetreat: 7,
                                distanceEnemyTooClose: 1,
                                distanceEnemyTooFar: 3.5,
                                movementDirection: out var movementDirection,
                                rotationAngleRad: out var rotationAngleRad);

                            this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);
                        }
                    }
                }

                distnpctoplayersqrtlast = distnpctoplayersqrt;
                lasthaspopped = haspopped;
                lasthaspoppedcounter = haspoppedcounter;
                lastdistnpctoplayersqrt = distnpctoplayersqrt;


                pathfindmaincounter = 0;
            }
            pathfindmaincounter++;

            lasthasreachedandattackedplayer = hasreachedandattackedplayer;
        }



        public void checkforobstaclesontheway(ICharacter npccharacter, Vector2D frontdirectionposition)
        {

            if (swtcobstaclesontheway == 0 && haspoppedcounter >= haspoppedcountermax) // && haspoppedcounter >= haspoppedcountermax
            {




                var physicsSpace0 = npccharacter.PhysicsBody.PhysicsSpace;

                obstaclesontheway = physicsSpace0.TestLine(
                      npcCharacterCenter,
                      frontdirectionposition,//playercharactercenter,
                      CollisionGroup.Default,
                      sendDebugEvent: true);

                obstaclesonthewaytwo = physicsSpace0.TestLine(
                   npcCharacterCenter,
                   playercharactercenter,//,
                   CollisionGroup.Default,
                   sendDebugEvent: true);


                if (listofobstaclesontheway != null)
                {
                    listofobstaclesontheway.Clear();
                }
                else
                {
                    listofobstaclesontheway = new List<sccsvec2int>();
                }


                if (obstaclesontheway != null)// && directionnpctopathfindnodef.X != float.NaN && directionnpctopathfindnodef.Y != float.NaN)
                {
                    if (obstaclesontheway.Count > 0)
                    {
                        var isTraversableTile = true;
                        foreach (var result in obstaclesontheway.AsList())
                        {
                            var body = result.PhysicsBody;
                            if (body.AssociatedProtoTile is not null)
                            {
                                // untraversable tile - a cliff or water
                                isTraversableTile = false;
                                //break;
                            }

                            if (body.AssociatedWorldObject is not null)
                            {
                                // an obstacle - a world object
                                isTraversableTile = false;
                                //break;
                            }

                            if (isTraversableTile == false)
                            {
                                Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                sccsvec2int posofobstacle = new sccsvec2int();
                                posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                                posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                                listofobstaclesontheway.Add(posofobstacle);
                            }
                        }



                        for (int i = 0; i < listofobstaclesontheway.Count; i++)
                        {
                            for (int j = 0; j < listofobstaclesinit.Count; j++)
                            {

                                if (listofobstaclesontheway[i].x != listofobstaclesinit[j].x &&
                                    listofobstaclesontheway[i].y != listofobstaclesinit[j].y)
                                {
                                    if (listofobstaclesontheway[i].x != (int)Math.Round((double)playerpos.x) && listofobstaclesontheway[i].x != (int)Math.Round((double)npcpos.x) &&
                                       listofobstaclesontheway[i].y != (int)Math.Round((double)playerpos.y) && listofobstaclesontheway[i].y != (int)Math.Round((double)npcpos.y))
                                    //if (listofobstaclesontheway[i].x != listofobstaclesinit[j].x && listofobstaclesontheway[i].x != (int)Math.Round((double)playerpos.x) && listofobstaclesontheway[i].x != (int)Math.Round((double)npcpos.x) || 
                                    //    listofobstaclesontheway[i].y != listofobstaclesinit[j].y && listofobstaclesontheway[i].y != (int)Math.Round((double)playerpos.y) && listofobstaclesontheway[i].y != (int)Math.Round((double)npcpos.y))
                                    {

                                        sccsvec2float dirnpctoobstacle = new sccsvec2float();
                                        dirnpctoobstacle.x = listofobstaclesontheway[i].x - npcpos.x;
                                        dirnpctoobstacle.y = listofobstaclesontheway[i].y - npcpos.y;

                                        sccsvec2float obstacleposition = new sccsvec2float();
                                        obstacleposition.x = listofobstaclesontheway[i].x;
                                        obstacleposition.y = listofobstaclesontheway[i].y;

                                        float distnpctoobstacle = pathfindscript.GetDistancefloat2dsqrt(obstacleposition, npcpos);

                                        dirnpctoobstacle.x /= distnpctoobstacle;
                                        dirnpctoobstacle.y /= distnpctoobstacle;


                                        if (currentnpcdirection.x != float.NaN && currentnpcdirection.y != float.NaN)
                                        {
                                            if (currentnpcdirection.x != 0 && currentnpcdirection.y != 0)
                                            {
                                                float thedotnpcdirtonodevsnpctoobstacle = sccsmaths.Dot(dirnpctoobstacle.x, dirnpctoobstacle.y, currentnpcdirection.x, currentnpcdirection.y);



                                                adminnotify.Execute(playercharacter, "/dotobstaclea:" + thedotnpcdirtonodevsnpctoobstacle);

                                                if (thedotnpcdirtonodevsnpctoobstacle > 0.85f && distnpctoobstacle < 1.5f * 1.25f)
                                                {
                                                    pathfindscript.startpathfind = 1;
                                                }
                                                else
                                                {
                                                    continue;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }











                if (obstaclesonthewaytwo != null)// && directionnpctopathfindnodef.X != float.NaN && directionnpctopathfindnodef.Y != float.NaN)
                {
                    if (obstaclesonthewaytwo.Count > 0)
                    {
                        var isTraversableTile = true;
                        foreach (var result in obstaclesonthewaytwo.AsList())
                        {
                            var body = result.PhysicsBody;
                            if (body.AssociatedProtoTile is not null)
                            {
                                // untraversable tile - a cliff or water
                                isTraversableTile = false;
                                //break;
                            }

                            if (body.AssociatedWorldObject is not null)
                            {
                                // an obstacle - a world object
                                isTraversableTile = false;
                                //break;
                            }

                            if (isTraversableTile == false)
                            {
                                Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                sccsvec2int posofobstacle = new sccsvec2int();
                                posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                                posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                                listofobstaclesonthewaytwo.Add(posofobstacle);
                            }
                        }



                        for (int i = 0; i < listofobstaclesonthewaytwo.Count; i++)
                        {
                            for (int j = 0; j < listofobstaclesinit.Count; j++)
                            {

                                if (listofobstaclesonthewaytwo[i].x != listofobstaclesinit[j].x &&
                                    listofobstaclesonthewaytwo[i].y != listofobstaclesinit[j].y)
                                {
                                    if (listofobstaclesonthewaytwo[i].x != (int)Math.Round((double)playerpos.x) && listofobstaclesonthewaytwo[i].x != (int)Math.Round((double)npcpos.x) &&
                                       listofobstaclesonthewaytwo[i].y != (int)Math.Round((double)playerpos.y) && listofobstaclesonthewaytwo[i].y != (int)Math.Round((double)npcpos.y))
                                    //if (listofobstaclesonthewaytwo[i].x != listofobstaclesinit[j].x && listofobstaclesonthewaytwo[i].x != (int)Math.Round((double)playerpos.x) && listofobstaclesonthewaytwo[i].x != (int)Math.Round((double)npcpos.x) || 
                                    //    listofobstaclesonthewaytwo[i].y != listofobstaclesinit[j].y && listofobstaclesonthewaytwo[i].y != (int)Math.Round((double)playerpos.y) && listofobstaclesonthewaytwo[i].y != (int)Math.Round((double)npcpos.y))
                                    {

                                        sccsvec2float dirnpctoobstacle = new sccsvec2float();
                                        dirnpctoobstacle.x = listofobstaclesonthewaytwo[i].x - npcpos.x;
                                        dirnpctoobstacle.y = listofobstaclesonthewaytwo[i].y - npcpos.y;

                                        sccsvec2float obstacleposition = new sccsvec2float();
                                        obstacleposition.x = listofobstaclesonthewaytwo[i].x;
                                        obstacleposition.y = listofobstaclesonthewaytwo[i].y;

                                        float distnpctoobstacle = pathfindscript.GetDistancefloat2dsqrt(obstacleposition, npcpos);

                                        dirnpctoobstacle.x /= distnpctoobstacle;
                                        dirnpctoobstacle.y /= distnpctoobstacle;


                                        if (currentnpcdirection.x != float.NaN && currentnpcdirection.y != float.NaN)
                                        {
                                            if (currentnpcdirection.x != 0 && currentnpcdirection.y != 0)
                                            {
                                                float thedotdirnpctoobstaclevsdirnpc = sccsmaths.Dot(dirnpctoobstacle.x, dirnpctoobstacle.y, currentnpcdirection.x, currentnpcdirection.y);



                                                adminnotify.Execute(playercharacter, "/dotobstacleb:" + thedotdirnpctoobstaclevsdirnpc);

                                                if (thedotdirnpctoobstaclevsdirnpc > 0.85f && distnpctoobstacle < 1.5f * 1.25f)
                                                {
                                                    pathfindscript.startpathfind = 1;
                                                }
                                                else
                                                {
                                                    continue;

                                                }
                                            }


                                            //break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                swtcobstaclesontheway = 1;

            }
        }



        private void chasethecharacter(ServerUpdateData data)
        {
            var character1 = data.GameObject;
            var currentStats1 = data.PublicState.CurrentStats;

            ServerCharacterAiHelper.ProcessAggressiveAi(
                character1,
                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character1),
                isRetreating: currentStats1.HealthCurrent < currentStats1.HealthMax / 3,
                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                distanceRetreat: 7,
                distanceEnemyTooClose: 1,
                distanceEnemyTooFar: 3.5,
                movementDirection: out var movementDirection,
                rotationAngleRad: out var rotationAngleRad);

            this.ServerSetMobInput(character1, movementDirection, rotationAngleRad);
        }

    }
}