﻿using System;

namespace sccsr15forms
{
    public class sclevelgenglobals
    {
        public int widthlod0 = 10;
        public int heightlod0 = 10;
        public int depthlod0 = 10;

        public int widthlod1 = 5;
        public int heightlod1 = 5;
        public int depthlod1 = 5;

        public int widthlod2 = 3;
        public int heightlod2 = 3;
        public int depthlod2 = 3;

        public int widthlod3 = 2;
        public int heightlod3 = 2;
        public int depthlod3 = 2;

        public int widthlod4 = 1;
        public int heightlod4 = 1;
        public int depthlod4 = 1;

        public float planeSize = 0.1f;
    }
}
