namespace AtomicTorch.CBND.CoreMod.Characters.Mobs
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    //using UnityEngine;
    //namespace AtomicTorch.CBND.CoreMod.Characters.Mobs

    public class sccspathfindstructs //: MonoBehaviour
    {

        public struct sccspathfindneighboortile
        {
            public byte swtc;
            public sccspathfindnode node; //
            public sccsvec2int sgp; // start grid pos
            public int iot; // index of tile
            public int iog; // indes of grid
            public int worldpositionx;
            public int worldpositiony;
            public byte walkable;
        }

        public struct sccspathfindextraTiles
        {
            public int x;
            public int y;
            //public int z;

            public int worldpositionx;
            public int worldpositiony;
            //public int worldpositionz;
            public int iog; //index of grid
            public sccsvec2int sgp; // start grid pos
            public int iot; // index of tile
            public sccspathfindgriddatafinal docg; //data of current grid
        }

        public class sccspathfindcombineddata
        {
            public List<sccspathfindnode> betterroutechecklist;
            public List<sccspathfindnode[]> log;
            public List<sccspathfindnode> openset;
            public List<sccspathfindnode> closedset;
            public List<sccspathfindnode> finalset;
        }

        public struct sccspathfindcheckallsidesdata
        {
            public List<sccspathfindneighboortile> neighboors;
            //public List<sccspathfindextraTiles> extraTiles;
            public List<sccspathfindneighboortile> extraTiles;

        }
        public struct sccspathfindgridWorldSize
        {
            public int xL; //x axis grid left
            public int xR; //x axis grid right
            public int yT; //y axis grid top
            public int yB; //y axis grid bottom
                           //public int zF; //y axis grid top
                           //public int zB; //y axis grid bottom
        }

        public struct sccspathfindobstacledata
        {
            public byte thebyte;
            public int x;
            public int y;
            //public int z;
            public int index;
            public int gridindex;
            public int worldpositionx;
            public int worldpositiony;
            //public int worldpositionz;
            public int gridposx;
            public int gridposy;
            //public int gridposz;
            public int gridtilex;
            public int gridtiley;
            //public int gridtilez;
        }


        public struct sccspathfindnode
        {
            public int parentiog;
            public int parentiot;
            public byte open;
            public byte closed;
            public byte nodeinitswtc;
            public int x;
            public int y;
            //public int z;
            public int index;
            public byte walkable;
            public int gridindex;
            public int worldpositionx;
            public int worldpositiony;
            //public int worldpositionz;

            public float gcost;
            public float hcost;
            public float fcost;
            public float toinitcost;

            public int gridposx;
            public int gridposy;
            //public int gridposz;
            public int gridtilex;
            public int gridtiley;
            //public int gridtilez;
        }
        public struct sccspathfindgridworldindex
        {
            //public int pushaddindex;
            //public int flatindex;

            public int x;
            public int y;
            //public int z;

            public int gridX;
            public int gridY;
            //public int gridZ;
        }
        public struct sccspathfindgriddatafinal
        {
            public sccspathfindgridworldindex gridData;
            public int index;
        }

        public struct sccsvec3int //? c# 10.0 
        {
            public int x;
            public int y;
            public int z;
        }

        public struct sccsvec2float //? c# 10.0 
        {
            public float x;
            public float y;
        }

        public struct sccsvec2int //? c# 10.0 
        {
            public int x;
            public int y;
        }
    }
}
