﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtomicTorch.CBND.CoreMod.Scripts.sccsPathfind
{
    public static class sccspathfindglobals
    {
        public static byte stopatpathfindendswtc = 0;
        public static byte checkforobstaclesonthewayswtc = 0;
        

    }
}
