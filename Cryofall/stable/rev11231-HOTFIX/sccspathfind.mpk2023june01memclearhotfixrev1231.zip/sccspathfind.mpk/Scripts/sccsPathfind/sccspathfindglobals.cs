﻿namespace AtomicTorch.CBND.CoreMod.Scripts.sccsPathfind
{
    public static class sccspathfindglobals
    {
        public static byte stopatpathfindendswtc = 1;
        public static byte checkforobstaclesonthewayswtc = 0;
    }
}
