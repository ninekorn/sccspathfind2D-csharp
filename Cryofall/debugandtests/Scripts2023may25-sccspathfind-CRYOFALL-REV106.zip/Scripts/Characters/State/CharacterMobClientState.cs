﻿namespace AtomicTorch.CBND.CoreMod.Characters
{
    public class CharacterMobClientState : BaseCharacterClientState
    {
    }
}