﻿namespace AtomicTorch.CBND.CoreMod.Characters
{
    public interface IProtoCharacterBoss : IProtoCharacterMob
    {
    }
}