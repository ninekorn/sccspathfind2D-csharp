﻿namespace AtomicTorch.CBND.CoreMod.Characters.Mobs
{
    using AtomicTorch.CBND.CoreMod.CharacterSkeletons;
    using AtomicTorch.CBND.CoreMod.Items.Generic;
    using AtomicTorch.CBND.CoreMod.Items.Weapons.MobWeapons;
    using AtomicTorch.CBND.CoreMod.SoundPresets;
    using AtomicTorch.CBND.CoreMod.Systems.Droplists;

    using sccspathfindnode = sccspathfindstructs.sccspathfindnode;
    using sccspathfindcombineddata = sccspathfindstructs.sccspathfindcombineddata;
    using sccspathfindgriddatafinal = sccspathfindstructs.sccspathfindgriddatafinal;
    using sccspathfindgridworldindex = sccspathfindstructs.sccspathfindgridworldindex;
    using sccspathfindgridWorldSize = sccspathfindstructs.sccspathfindgridWorldSize;
    using sccspathfindcheckallsidesdata = sccspathfindstructs.sccspathfindcheckallsidesdata;
    using sccspathfindneighboortile = sccspathfindstructs.sccspathfindneighboortile;
    using sccspathfindextraTiles = sccspathfindstructs.sccspathfindextraTiles;
    using sccspathfindobstacledata = sccspathfindstructs.sccspathfindobstacledata;
    using sccsvec2int = sccspathfindstructs.sccsvec2int;
    using static sccspathfindstructs;
    using static sccsvestationoutpost;

    using AtomicTorch.CBND.CoreMod.Characters;
    using AtomicTorch.CBND.CoreMod.ConsoleCommands.Admin;
    using AtomicTorch.CBND.GameApi.Data.Physics;
    using System.Windows.Documents;
    using AtomicTorch.CBND.GameApi.Scripting;
    using AtomicTorch.CBND.GameApi.ServicesServer;


    using System.Collections.Generic;
    using System.Collections;
    using System;
    using AtomicTorch.GameEngine.Common.Primitives;
    using System.Numerics;
    using AtomicTorch.GameEngine.Common.DataStructures;
    using AtomicTorch.CBND.CoreMod.Characters.Player;
    using AtomicTorch.CBND.GameApi.Data.Characters;

    public class MobSnakeGreen : ProtoCharacterMob
    {

        private static readonly IWorldServerService ServerWorldService
            = Api.IsServer
                  ? Api.Server.World
                  : null;
        public override bool AiIsRunAwayFromHeavyVehicles => true;

        public override float CharacterWorldHeight => 0.8f;

        public override double MobKillExperienceMultiplier => 1.0;

        public override string Name => "Green snake";

        public override ObjectMaterial ObjectMaterial => ObjectMaterial.SoftTissues;

        public override double StatDefaultHealthMax => 50;

        public override double StatMoveSpeed => 1.65;

        protected override void PrepareProtoCharacterMob(
            out ProtoCharacterSkeleton skeleton,
            ref double scale,
            DropItemsList lootDroplist)
        {
            skeleton = GetProtoEntity<SkeletonSnakeGreen>();

            // primary loot
            lootDroplist
                .Add<ItemToxin>(count: 1);
        }

        protected override void ServerInitializeCharacterMob(ServerInitializeData data)
        {
            base.ServerInitializeCharacterMob(data);

            var weaponProto = GetProtoEntity<ItemWeaponMobSnakeBiteWeak>();
            data.PrivateState.WeaponState.SharedSetWeaponProtoOnly(weaponProto);
            data.PublicState.SharedSetCurrentWeaponProtoOnly(weaponProto);
        }





        //AtomicTorch.CBND.CoreMod.ConsoleCommands.Debug.ConsoleDebugTestNotification debug = new ConsoleCommands.Debug.ConsoleDebugTestNotification();
        sccspathfind pathfindscript;
        int startpathfindmainswtc = 0;
        sccsvec2float initialpathfindstartpos = new sccsvec2float();

        sccsvec2float initialpathfindtargetpos = new sccsvec2float();


        sccsvec2float lastinitialpathfindtargetpos = new sccsvec2float();

        int swtcdebug = 0;

        float distnpctoplayerlast = 0;
        System.Collections.Generic.List<sccsvec2int> listofobstaclesinit = new System.Collections.Generic.List<sccsvec2int>();
        ITempList<TestResult> obstacles;

        System.Collections.Generic.List<sccsvec2int> listofobstaclesontheway = new System.Collections.Generic.List<sccsvec2int>();
        ITempList<TestResult> obstaclesontheway;
        int swtcobstaclesontheway = 0;

        sccsvec2float npcposlast = new sccsvec2float();

        float lastdistsquared = 0;
        Vector2F directionnpctopathfindnodef = new Vector2F(0,0);
        ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
        float distsquared = 0;
        sccsvec2float playerpos;
        sccsvec2float npcpos;

        ICharacter playercharacter;

        float disttonode0last = 0;
        Vector2D playercharactercenter;
        Vector2D npcCharacterCenter;

        protected override void ServerUpdateMob(ServerUpdateData data)
        {
            if (startpathfindmainswtc == 0)
            {
                pathfindscript = new sccspathfind();
                pathfindscript.pathfindoptionhgf = 1;
                pathfindscript.retracepathiterationadder = 1;
                pathfindscript.debugtoconsolemsg = 0;
                pathfindscript.pathfindimax = 9; //loops the pathfind 3 times per frame.
                pathfindscript.framecounterpathfindmax = 0;
                pathfindscript.createpathfindvisuals = 0;
                pathfindscript.retracedpathlistcountermax = 0;
                pathfindscript.startpathfind = 1;

                startpathfindmainswtc = 1;
            }
         

            var npccharacter = data.GameObject;

            if (npccharacter != null)
            {
                if (npccharacter.PhysicsBody != null)
                {
                    npcCharacterCenter = npccharacter.Position + npccharacter.PhysicsBody.CenterOffset;

                    playercharacter = ServerCharacterAiHelper.GetClosestTargetPlayer(npccharacter);

                    if (playercharacter != null)
                    {
                        if (playercharacter.PhysicsBody != null)
                        {
                            playercharactercenter = playercharacter.Position + playercharacter.PhysicsBody.CenterOffset;

                            playerpos = new sccsvec2float();
                            playerpos.x = (float)playercharactercenter.X;
                            playerpos.y = (float)playercharactercenter.Y;

                            npcpos = new sccsvec2float();
                            npcpos.x = (float)npcCharacterCenter.X;
                            npcpos.y = (float)npcCharacterCenter.Y;

                            if (pathfindscript != null)
                            {


                                distsquared = pathfindscript.GetDistancefloat2d(playerpos, npcpos);




                                //if (pathfindscript.startpathfind == 0 || pathfindscript.startpathfind == 1 || pathfindscript.startpathfind == 2 || pathfindscript.startpathfind == 3)
                                //{
                                if (distsquared < 75)
                                {
                                    var physicsSpace = npccharacter.PhysicsBody.PhysicsSpace;
                                    //var npcCharacterCenter = npccharacter.Position + npccharacter.PhysicsBody.CenterOffset;
                                    //var playerCharacterCenter = playercharacter.Position + playercharacter.PhysicsBody.CenterOffset;

                                    //ConsoleAdminNotifyPlayer adminnotify0 = new ConsoleAdminNotifyPlayer();
                                    //adminnotify0.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind + "/id:" + npccharacter.Id);
                                    //initialpathfindstartpos = 


                                    /*if (lastinitialpathfindtargetpos.x != playerpos.x || lastinitialpathfindtargetpos.y != playerpos.y)
                                    {
                                        pathfindscript.startpathfind = 1;
                                    }*/

                                    if (pathfindscript.startpathfind == 1)
                                    {
                                        swtcobstaclesontheway = 0;

                                        //pathfindscript = new sccspathfind();
                                        /*pathfindscript.pathfindoptionhgf = 1;
                                        pathfindscript.retracepathiterationadder = 1;
                                        pathfindscript.debugtoconsolemsg = 0;
                                        pathfindscript.pathfindimax = 6; //loops the pathfind 3 times per frame.
                                        pathfindscript.framecounterpathfindmax = 0;
                                        pathfindscript.createpathfindvisuals = 0;
                                        pathfindscript.retracedpathlistcountermax = 0;*/
                                        //pathfindscript.startpathfind = 1;

                                        obstacles = physicsSpace.TestLine(
                                          npcCharacterCenter,
                                          playercharactercenter,
                                          CollisionGroup.Default,
                                          sendDebugEvent: true);

                                        if (listofobstaclesinit != null)
                                        {
                                            listofobstaclesinit.Clear();
                                        }
                                        else
                                        {
                                            listofobstaclesinit = new List<sccsvec2int>();
                                        }


                                        if (obstacles != null)
                                        {
                                            if (obstacles.Count > 0)
                                            {
                                                var isTraversableTile = true;
                                                foreach (var result in obstacles.AsList())
                                                {
                                                    var body = result.PhysicsBody;
                                                    if (body.AssociatedProtoTile is not null)
                                                    {
                                                        // untraversable tile - a cliff or water
                                                        isTraversableTile = false;
                                                        //break;
                                                    }

                                                    if (body.AssociatedWorldObject is not null)
                                                    {
                                                        // an obstacle - a world object
                                                        isTraversableTile = false;
                                                        //break;
                                                    }

                                                    if (isTraversableTile == false)
                                                    {
                                                        Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                                        sccsvec2int posofobstacle = new sccsvec2int();
                                                        posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                                                        posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                                                        listofobstaclesinit.Add(posofobstacle);
                                                    }
                                                }





                                                /*
                                                foreach (var test in obstacles.AsList())
                                                {
                                                    var gameobjecttype = test.PhysicsBody.AssociatedWorldObject.GameObjectType;

                                                    var testPhysicsBody = test.PhysicsBody;

                                                    //if (testPhysicsBody.AssociatedProtoTile is null)
                                                    //{
                                                    //    continue;
                                                    //}

                                                    Vector2Ushort vec = testPhysicsBody.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                                    sccsvec2int posofobstacle = new sccsvec2int();
                                                    posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)testPhysicsBody.CenterOffset.X);
                                                    posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)testPhysicsBody.CenterOffset.Y);

                                                    listofobstaclesinit.Add(posofobstacle);

                                                    //var tile = ServerWorldService.GetTile(testPhysicsBody.Position.ToVector2Ushort());
                                                    //if (!tile.IsSlope)
                                                    //{
                                                    //    // cliff tile on the way
                                                    //    //return true;
                                                    //}
                                                }*/
                                            }
                                        }

                                        initialpathfindstartpos = npcpos;
                                        initialpathfindtargetpos = playerpos;
                                    }
                                    else
                                    {

                                        
                                    }



                                    /*
                                    if (pathfindscript.startpathfind != 4)
                                    {

                                        pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);
                                        //ConsolePlayerGetPosition
                                        //debug.Execute("sccsmsgpathfind", "startpathfind:" + pathfindscript.startpathfind);
                                    }
                                    else
                                    {

                                        pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);                 
                                    }*/

                                    pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);
                                }
                                else
                                {

                                    var character = data.GameObject;
                                    var currentStats = data.PublicState.CurrentStats;

                                    ServerCharacterAiHelper.ProcessAggressiveAi(
                                        character,
                                        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                        isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                        distanceRetreat: 7,
                                        distanceEnemyTooClose: 1,
                                        distanceEnemyTooFar: 1.5,
                                        movementDirection: out var movementDirection,
                                        rotationAngleRad: out var rotationAngleRad);

                                    this.ServerSetMobInput(character, movementDirection, rotationAngleRad);

                                    pathfindscript.startpathfind = 1;
                                }
                                //}













                                if (pathfindscript.startpathfind == 4)//pathfindscript.startpathfind != 0 && pathfindscript.startpathfind != 1 && pathfindscript.startpathfind != 2 && pathfindscript.startpathfind != 3
                                {
                                    if (pathfindscript.retracedpathlist != null)
                                    {
                                        if (pathfindscript.retracedpathlist.Count - 1 > 0)
                                        {
                                            //adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind);

                                            sccsvec2float thenodepos = new sccsvec2float();
                                            thenodepos.x = pathfindscript.retracedpathlist[0].worldpositionx;
                                            thenodepos.y = pathfindscript.retracedpathlist[0].worldpositiony;

                                            sccsvec2float dirtonpc = new sccsvec2float(); // new Vector3(targetobjingridpos.x, targetobjingridpos.y, 0) 
                                            dirtonpc.x = initialpathfindstartpos.x - 0;
                                            dirtonpc.y = initialpathfindstartpos.y - 0;

                                            sccsvec2float movethepoint = new sccsvec2float();// thenodepos + (dirtoplayernpc);
                                            movethepoint.x = thenodepos.x + dirtonpc.x;
                                            movethepoint.y = thenodepos.y + dirtonpc.y;

                                            var disttonode = pathfindscript.GetDistancefloat2dsqrt(initialpathfindstartpos, movethepoint);

                                            //var distnpctoplayer = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

                                            sccsvec2float dirnodetoinitpos = new sccsvec2float();
                                            dirnodetoinitpos.x = initialpathfindstartpos.x - movethepoint.x; //-thenodepos.x;//
                                            dirnodetoinitpos.y = initialpathfindstartpos.y - movethepoint.y; //-thenodepos.y;//

                                            float hypothenuse = disttonode;
                                            float opposite = dirnodetoinitpos.y;
                                            float adjacent = dirnodetoinitpos.x;
                                            float rotationangledeg = 0;

                                            dirnodetoinitpos.x /= disttonode;
                                            dirnodetoinitpos.y /= disttonode;

                                            dirnodetoinitpos.x *= -1;
                                            dirnodetoinitpos.y *= -1;

                                            /*sccsvec2float dirright = new sccsvec2float();
                                            dirright.x = 1.0f;
                                            dirright.y = 0.0f;

                                            float anglerad = Vector2F.AngleDeg(new Vector2F(dirnodetoinitpos.x, dirnodetoinitpos.y), new Vector2F(dirright.x, dirright.y));

                                            anglerad = normalizeradiansfromradians(anglerad);
                                            anglerad *= -1;

                                            float thedot = Dot(dirright.x, dirright.y, dirnodetoinitpos.x, dirnodetoinitpos.y);
                                            */
                                            //adminnotify.Execute(playercharacter, "thedot:" + thedot + "/dist:" + distnpctoplayer + "/disttonode:" + disttonode + "/dirx:" + dirnodetoinitpos.x + "/diry:" + dirnodetoinitpos.y + "/nodex:" + pathfindscript.retracedpathlist[0].worldpositionx + "/nodey:" + pathfindscript.retracedpathlist[0].worldpositiony);//

                                            if ((pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x) == initialpathfindstartpos.x &&
                                                (pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y) == initialpathfindstartpos.y)
                                            {
                                                pathfindscript.retracedpathlist.RemoveAt(0);
                                                //adminnotify.Execute(playercharacter, "npc reached first node already. remove first node.");
                                            }




                                            /*
                                            if (pathfindscript.retracedpathlist.Count > 0)
                                            {
                                                if (thedot == float.NaN)
                                                {
                                                    pathfindscript.retracedpathlist.RemoveAt(0);
                                                    //adminnotify.Execute(playercharacter, "thedot == nan. remove first node");
                                                }
                                            }*/



                                            sccsvec2float dirnpc = new sccsvec2float();
                                            dirnpc.x = npcpos.x - npcposlast.x;
                                            dirnpc.y = npcpos.y - npcposlast.y;

                                            dirnpc.x /= disttonode;
                                            dirnpc.y /= disttonode;

                                            //dirnpc.x *= -1;
                                            //dirnpc.y *= -1;

                                            sccsvec2float dirnpcplayer = new sccsvec2float();
                                            dirnpcplayer.x = playerpos.x - npcpos.x;
                                            dirnpcplayer.y = playerpos.y - npcpos.y;

                                            //normalizing
                                            dirnpcplayer.x /= distsquared;
                                            dirnpcplayer.y /= distsquared;


                                            float thedotplayernpc = Dot(dirnpc.x, dirnpc.y, dirnpcplayer.x, dirnpcplayer.y);


                                            if (thedotplayernpc > 0.07f)
                                            {
                                            }

                                            //adminnotify.Execute(playercharacter, "thedotplayernpc:" + thedotplayernpc);


                                            directionnpctopathfindnodef = new Vector2F(dirnodetoinitpos.x, dirnodetoinitpos.y);

                                            //float rotationanglerad = Vector2F.AngleRad(new Vector2F(nodepos.x, nodepos.y), new Vector2F(initialpathfindstartpos.x, initialpathfindstartpos.y));
                                            //float rotationangledeg1 = RadianToDegree(anglerad);
                                            //ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
                                            //adminnotify.Execute(playercharacter, "nodedx:" + directionnpctopathfindnodef.X + "/nodedy:" + directionnpctopathfindnodef.Y + "/nodex:" + pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x + "/nodey:" + pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x + "/npcx:" + (int)Math.Round((decimal)npcpos.x) + "/npcy:" + (int)Math.Round((decimal)npcpos.y) + "/" + "rotationangledeg:" + rotationangledeg1 + "/listofobstaclesinit:" + listofobstaclesinit.Count);

                                            //adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg1 + "/listofobstaclesinit:" + listofobstaclesinit.Count);




                                        }
                                        else
                                        {
                                            var character = data.GameObject;
                                            var currentStats = data.PublicState.CurrentStats;


                                            float distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);


                                            ServerCharacterAiHelper.ProcessAggressiveAi(
                                                character,
                                                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                                isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                distanceRetreat: distsqrt,
                                                distanceEnemyTooClose: distsqrt,
                                                distanceEnemyTooFar: distsqrt,
                                                movementDirection: out var movementDirection0,
                                                rotationAngleRad: out var rotationAngleRad0);

                                            this.ServerSetMobInput(character, movementDirection0, rotationAngleRad0);

                                            pathfindscript.startpathfind = 1;
                                        }
                                    }
                                    else
                                    {
                                        var character = data.GameObject;
                                        var currentStats = data.PublicState.CurrentStats;


                                        float distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);


                                        ServerCharacterAiHelper.ProcessAggressiveAi(
                                            character,
                                            targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                            isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                            isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                            distanceRetreat: distsqrt,
                                            distanceEnemyTooClose: distsqrt,
                                            distanceEnemyTooFar: distsqrt,
                                            movementDirection: out var movementDirection0,
                                            rotationAngleRad: out var rotationAngleRad0);

                                        this.ServerSetMobInput(character, movementDirection0, rotationAngleRad0);
                                        pathfindscript.startpathfind = 1;
                                    }
                                }












                                if (pathfindscript.startpathfind == 4)
                                {
                                    if (lastdistsquared < distsquared)
                                    {
                                        /*var character = data.GameObject;
                                        var currentStats = data.PublicState.CurrentStats;

                                        ServerCharacterAiHelper.ProcessAggressiveAi(
                                            character,
                                            targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                            isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                            isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                            distanceRetreat: 7,
                                            distanceEnemyTooClose: 1,
                                            distanceEnemyTooFar: 1.5,
                                            movementDirection: out var movementDirection,
                                            rotationAngleRad: out var rotationAngleRad);

                                        this.ServerSetMobInput(character, movementDirection, rotationAngleRad);*/

                                        //pathfindscript.startpathfind = 1;
                                    }
                                    else
                                    {
                                        if (distsquared > 0.99f) //0.99f
                                        {
                                            sccsvec2float dirright = new sccsvec2float();
                                            dirright.x = 1.0f;
                                            dirright.y = 0.0f;

                                            float anglerad = Vector2F.AngleDeg(new Vector2F(directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y), new Vector2F(dirright.x, dirright.y));

                                            anglerad = normalizeradiansfromradians(anglerad);
                                            anglerad *= -1;

                                            float thedot = Dot(dirright.x, dirright.y, directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y);

                                            //adminnotify.Execute(playercharacter, "thedot:" + pathfindscript.startpathfind + "/id:" + npccharacter.Id);

                                            //pathfindscript.startpathfind = 1;
                                            var character = data.GameObject;
                                            var currentStats = data.PublicState.CurrentStats;

                                            /*ServerCharacterAiHelper.ProcessAggressiveAi(
                                                character,
                                                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                                isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                distanceRetreat: 7,
                                                distanceEnemyTooClose: 1,
                                                distanceEnemyTooFar: 3,
                                                movementDirection: out var movementDirection,
                                                rotationAngleRad: out var rotationAngleRad);*/

                                            this.ServerSetMobInput(character, directionnpctopathfindnodef, anglerad);
                                            
                                            /*if (initialpathfindtargetpos.x != playerpos.x || initialpathfindtargetpos.y != playerpos.y)
                                            {
                                                character = data.GameObject;
                                                currentStats = data.PublicState.CurrentStats;


                                                float distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);


                                                ServerCharacterAiHelper.ProcessAggressiveAi(
                                                    character,
                                                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                                    isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                    distanceRetreat: distsqrt,
                                                    distanceEnemyTooClose: distsqrt,
                                                    distanceEnemyTooFar: distsqrt,
                                                    movementDirection: out var movementDirection0,
                                                    rotationAngleRad: out var rotationAngleRad0);

                                                this.ServerSetMobInput(character, movementDirection0, rotationAngleRad0);

                                                pathfindscript.startpathfind = 1;
                                            }
                                            else
                                            {
                                                
                                            }*/
                                        }
                                        else
                                        {
                                            var character = data.GameObject;
                                            var currentStats = data.PublicState.CurrentStats;

                                            ServerCharacterAiHelper.ProcessAggressiveAi(
                                                character,
                                                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                                isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                distanceRetreat: 7,
                                                distanceEnemyTooClose: 1,
                                                distanceEnemyTooFar: 1.5,
                                                movementDirection: out var movementDirection,
                                                rotationAngleRad: out var rotationAngleRad);

                                            this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
                                        }
                                    }
                                }
                                else
                                {

                                }



                                lastdistsquared = distsquared;
                            }
                            else
                            {


                            }

                            npcposlast = npcpos;
                            





                        }
                    }
                }
            }






    

            if (pathfindscript.startpathfind == 4)
            {
                if (pathfindscript.retracedpathlist.Count > 0)
                {
                    sccsvec2float thenodepos0 = new sccsvec2float();
                    thenodepos0.x = pathfindscript.retracedpathlist[0].worldpositionx;
                    thenodepos0.y = pathfindscript.retracedpathlist[0].worldpositiony;

                    sccsvec2float dirtonpc0 = new sccsvec2float(); // new Vector3(targetobjingridpos.x, targetobjingridpos.y, 0) 
                    dirtonpc0.x = initialpathfindstartpos.x - 0;
                    dirtonpc0.y = initialpathfindstartpos.y - 0;

                    sccsvec2float movethepoint0 = new sccsvec2float();// thenodepos + (dirtoplayernpc);
                    movethepoint0.x = thenodepos0.x + dirtonpc0.x;
                    movethepoint0.y = thenodepos0.y + dirtonpc0.y;




                    var disttonode0 = pathfindscript.GetDistancefloat2dsqrt(initialpathfindstartpos, movethepoint0);


                    if ((int)Math.Round((decimal)npcpos.x) == pathfindscript.retracedpathlist[0].worldpositionx + (int)Math.Round((decimal)initialpathfindstartpos.x) &&
                        (int)Math.Round((decimal)npcpos.y) == pathfindscript.retracedpathlist[0].worldpositiony + (int)Math.Round((decimal)initialpathfindstartpos.y) || disttonode0 <= 0.75f || disttonode0last <= disttonode0)//|| lastdistsquared < distsquared
                    {

                        pathfindscript.retracedpathlist.RemoveAt(0);
                        adminnotify.Execute(playercharacter, "removed node:" + pathfindscript.retracedpathlist.Count + "/disttonode0:" + disttonode0 +"/obstaclescount:" +listofobstaclesinit.Count);





                        //npc or charactger is moving
                        if (distsquared != lastdistsquared && pathfindscript.startpathfind == 4)
                        {
                            if (swtcobstaclesontheway == 0)
                            {

                                var physicsSpace0 = npccharacter.PhysicsBody.PhysicsSpace;

                                obstaclesontheway = physicsSpace0.TestLine(
                                      npcCharacterCenter,
                                      playercharactercenter,
                                      CollisionGroup.Default,
                                      sendDebugEvent: true);

                                if (listofobstaclesontheway != null)
                                {
                                    listofobstaclesontheway.Clear();
                                }
                                else
                                {
                                    listofobstaclesontheway = new List<sccsvec2int>();
                                }

                                if (obstaclesontheway != null)
                                {
                                    if (obstaclesontheway.Count > 0)
                                    {
                                        var isTraversableTile = true;
                                        foreach (var result in obstaclesontheway.AsList())
                                        {
                                            var body = result.PhysicsBody;
                                            if (body.AssociatedProtoTile is not null)
                                            {
                                                // untraversable tile - a cliff or water
                                                isTraversableTile = false;
                                                //break;
                                            }

                                            if (body.AssociatedWorldObject is not null)
                                            {
                                                // an obstacle - a world object
                                                isTraversableTile = false;
                                                //break;
                                            }

                                            if (isTraversableTile == false)
                                            {
                                                Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                                sccsvec2int posofobstacle = new sccsvec2int();
                                                posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                                                posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                                                listofobstaclesontheway.Add(posofobstacle);
                                            }
                                        }
                                    }
                                }

                                for (int i = 0; i < listofobstaclesontheway.Count; i++)
                                {
                                    for (int j = 0; j < listofobstaclesinit.Count; j++)
                                    {
                                        if (listofobstaclesontheway[i].x != listofobstaclesinit[j].x || listofobstaclesontheway[i].y != listofobstaclesinit[j].y)
                                        {
                                            var character = data.GameObject;
                                            var currentStats = data.PublicState.CurrentStats;


                                            float distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);


                                            ServerCharacterAiHelper.ProcessAggressiveAi(
                                                character,
                                                targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                                isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                                isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                distanceRetreat: distsqrt,
                                                distanceEnemyTooClose: distsqrt,
                                                distanceEnemyTooFar: distsqrt,
                                                movementDirection: out var movementDirection0,
                                                rotationAngleRad: out var rotationAngleRad0);

                                            this.ServerSetMobInput(character, movementDirection0, rotationAngleRad0);

                                            pathfindscript.startpathfind = 1;
                                        }
                                    }
                                }

                                swtcobstaclesontheway = 1;

                            }
                        }




                    }





                    if (initialpathfindtargetpos.x != playerpos.x || initialpathfindtargetpos.y != playerpos.y)
                    {
                        swtcobstaclesontheway = 0;
                        var character = data.GameObject;
                        var currentStats = data.PublicState.CurrentStats;


                        float distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);


                        ServerCharacterAiHelper.ProcessAggressiveAi(
                            character,
                            targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                            isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                            isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                            distanceRetreat: distsqrt,
                            distanceEnemyTooClose: distsqrt,
                            distanceEnemyTooFar: distsqrt,
                            movementDirection: out var movementDirection0,
                            rotationAngleRad: out var rotationAngleRad0);

                        this.ServerSetMobInput(character, movementDirection0, rotationAngleRad0);

                        pathfindscript.startpathfind = 1;
                    }
                    else
                    {

                    }



                    disttonode0last = disttonode0;



                    //adminnotify.Execute(playercharacter, "removed node:" + disttonode0);

                }
                else
                {
                    var character = data.GameObject;
                    var currentStats = data.PublicState.CurrentStats;


                    float distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);


                    ServerCharacterAiHelper.ProcessAggressiveAi(
                        character,
                        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                        isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                        distanceRetreat: distsqrt,
                        distanceEnemyTooClose: distsqrt,
                        distanceEnemyTooFar: distsqrt,
                        movementDirection: out var movementDirection0,
                        rotationAngleRad: out var rotationAngleRad0);

                    this.ServerSetMobInput(character, movementDirection0, rotationAngleRad0);

                    pathfindscript.startpathfind = 1;
                }
            }




            if (pathfindscript.startpathfind != 4)
            {
                /*var character = data.GameObject;
                var currentStats = data.PublicState.CurrentStats;

                ServerCharacterAiHelper.ProcessAggressiveAi(
                    character,
                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                    isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                    distanceRetreat: 7,
                    distanceEnemyTooClose: 1,
                    distanceEnemyTooFar: 3.5,
                    movementDirection: out var movementDirection,
                    rotationAngleRad: out var rotationAngleRad);

                this.ServerSetMobInput(character, movementDirection, rotationAngleRad);*/
            }


        }


        public static float DegreeToRadian(float angle)
        {
            return (float)(Math.PI * angle / 180.0f);
        }

        public static float RadianToDegree(float angle)
        {
            return (float)(angle * (180.0f / Math.PI));
        }

        public static float Dot(float aX, float aY, float bX, float bY)
        {
            return (aX * bX) + (aY * bY);
        }


        public static float normalizeradiansfromradians(float radians)
        {
            float degrees = RadianToDegree(radians);
            degrees = degrees % 180;
            if (degrees < 0)
            {
                degrees += 180;
            }
            return DegreeToRadian(degrees);  //DegreeToRadian(degrees);
        }

        public static float normalizedegreesfromdegrees(float degrees)
        {
            //float degrees = RadianToDegree(radians);
            degrees = degrees % 180;
            if (degrees < 0)
            {
                degrees += 180;
            }
            return degrees;  //DegreeToRadian(degrees);
        }
    }
}
















/*
sccsvec2float nodepos = new sccsvec2float();
nodepos.x = pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x;
nodepos.y = pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y;

var disttonode = pathfindscript.GetDistancefloat2d(initialpathfindstartpos, nodepos);

sccsvec2float directionnpctopathfindnode = new sccsvec2float();
directionnpctopathfindnode.x = ((pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x) - initialpathfindstartpos.x);
directionnpctopathfindnode.y = ((pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y) - initialpathfindstartpos.y);
*/

/*
if ((pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x) == initialpathfindstartpos.x &&
    (pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y) == initialpathfindstartpos.y)
{
    pathfindscript.retracedpathlist.RemoveAt(0);

    adminnotify.Execute(playercharacter, "npc reached first node already. remove first node.");

}*/


/*
directionnpctopathfindnode.x /= disttonode;
directionnpctopathfindnode.y /= disttonode;
*/
/*sccsvec2float directionnpctopathfindnode = new sccsvec2float();
directionnpctopathfindnode.x = ((pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x) - npcpos.x);
directionnpctopathfindnode.y = ((pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y) - npcpos.y);

directionnpctopathfindnode.x /= disttonode;
directionnpctopathfindnode.y /= disttonode;

directionnpctopathfindnode.x = (int)Math.Round((decimal)directionnpctopathfindnode.x);
directionnpctopathfindnode.y = (int)Math.Round((decimal)directionnpctopathfindnode.y);

Vector2F directionnpctopathfindnodef = new Vector2F(directionnpctopathfindnode.x, directionnpctopathfindnode.y);*/

/*
var rotationAngleRad = npccharacter.GetPublicState<CharacterMobPublicState>()
   .AppliedInput
   .RotationAngleRad;*/

//this.ServerSetMobInput(npccharacter, directionnpctopathfindnodef, rotationAngleRad);

//Vector2F.AngleDeg();



//c2 = a2 + b2

//hypothenuse

//a = nodepos.x //adjacent
//b = nodepos.y //opposite
//c = disttonode

//sin(angle) = opposite/hypothenuse;

/*var distsquared = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

sccsvec2float dirnodetoinitpos = new sccsvec2float();
dirnodetoinitpos.x = initialpathfindstartpos.x - nodepos.x;
dirnodetoinitpos.y = initialpathfindstartpos.y - nodepos.y;

float hypothenuse = disttonode;
float opposite = dirnodetoinitpos.y;
float adjacent = dirnodetoinitpos.x;
float rotationangledeg = 0;


sccsvec2float dirright = new sccsvec2float();
dirright.x = 1.0f;
dirright.y = 0.0f;
*/
/*float thedot = Dot(dirright.x, dirright.y, directionnpctopathfindnode.x, directionnpctopathfindnode.y);

//adminnotify.Execute(playercharacter, "thedot:" + thedot + "/dist:" + distsquared + "/disttonode:" + disttonode + "/dirx:" + directionnpctopathfindnode.x + "/diry:" + directionnpctopathfindnode.y + "/nodex:" + pathfindscript.retracedpathlist[0].x + "/nodey:" + pathfindscript.retracedpathlist[0].y);//

if (thedot == float.NaN)
{
    pathfindscript.retracedpathlist.RemoveAt(0);
    adminnotify.Execute(playercharacter, "thedot == nan. remove first node");
}*/



//adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared + "/nodex:" + pathfindscript.retracedpathlist[0].x + "/nodey:" + pathfindscript.retracedpathlist[0].y);



/*
if (swtcdebug == 0)
{
    for (int i = 0;i < pathfindscript.retracedpathlist.Count;i++)
    {
        adminnotify.Execute(playercharacter, "pathx:" + pathfindscript.retracedpathlist[i].worldpositionx + "/pathy:" + pathfindscript.retracedpathlist[i].worldpositiony);

    }

    swtcdebug = 1;
}*/






















/*
float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

rotationangledeg = -RadianToDegree(rotationanglerad);

adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
*/



//directionnpctopathfindnode.x = (int)Math.Round((decimal)directionnpctopathfindnode.x);
//directionnpctopathfindnode.y = (int)Math.Round((decimal)directionnpctopathfindnode.y);










//ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
//adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);

/*
if (Math.Abs(opposite) >= Math.Abs(adjacent))
{
    if (dirnodetoinitpos.y >= 0)
    {
        if (dirnodetoinitpos.x >= 0)
        {
            float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
        else
        {
            float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
    }
    else
    {
        if (dirnodetoinitpos.x >= 0)
        {
            float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
        else
        {
            float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
    }
}
else //if (Math.Abs(opposite) < Math.Abs(adjacent))
{
    if (dirnodetoinitpos.y >= 0)
    {
        if (dirnodetoinitpos.x >= 0)
        {
            float rotationanglerad = (float)Math.Acos(adjacent / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
        else
        {
            float rotationanglerad = (float)Math.Acos(adjacent / hypothenuse);

            rotationangledeg = RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
    }
    else
    {
        if (dirnodetoinitpos.x >= 0)
        {
            float rotationanglerad = (float)Math.Acos(adjacent / hypothenuse);

            rotationangledeg = RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
        else
        {
            float rotationanglerad = (float)Math.Acos(adjacent / hypothenuse);

            rotationangledeg = RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
    }
}*/




