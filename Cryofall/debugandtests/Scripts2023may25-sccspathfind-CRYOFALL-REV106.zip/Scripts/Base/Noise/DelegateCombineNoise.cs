﻿namespace AtomicTorch.CBND.CoreMod.Noise
{
    public delegate double DelegateCombineNoise(double current, double value);
}