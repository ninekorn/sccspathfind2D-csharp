﻿namespace AtomicTorch.CBND.CoreMod.Stats
{
    using System;

    [AttributeUsage(AttributeTargets.Field)]
    public class StatBuffAttribute : Attribute
    {
    }
}