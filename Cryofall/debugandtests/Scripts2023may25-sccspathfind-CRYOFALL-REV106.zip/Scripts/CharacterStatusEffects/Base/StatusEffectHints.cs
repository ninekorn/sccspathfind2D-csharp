﻿namespace AtomicTorch.CBND.CoreMod.CharacterStatusEffects
{
    public static class StatusEffectHints
    {
        public const string CanBeRemediedWith_Format = "Can be remedied with {0}.";
    }
}