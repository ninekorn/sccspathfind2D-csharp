﻿namespace AtomicTorch.CBND.CoreMod.CharacterStatusEffects
{
    public delegate bool DelegeteEffectActionCondition(EffectActionContext context);
}