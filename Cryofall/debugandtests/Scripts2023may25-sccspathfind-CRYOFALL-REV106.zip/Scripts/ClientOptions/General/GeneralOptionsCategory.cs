﻿namespace AtomicTorch.CBND.CoreMod.ClientOptions.General
{
    public class GeneralOptionsCategory : ProtoOptionsCategory
    {
        public override string Name => "General";

        protected override void OnApply()
        {
        }

        protected override void OnReset()
        {
        }
    }
}