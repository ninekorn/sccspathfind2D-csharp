﻿namespace AtomicTorch.CBND.CoreMod.ClientComponents.Misc
{
    using System;
    using AtomicTorch.CBND.CoreMod.Helpers.Client;
    using AtomicTorch.CBND.CoreMod.StaticObjects.Structures.LandClaim;
    using AtomicTorch.CBND.CoreMod.Systems.LandClaim;
    using AtomicTorch.CBND.CoreMod.Systems.Notifications;
    using AtomicTorch.CBND.CoreMod.UI.Controls.Game.HUD.Notifications;
    using AtomicTorch.CBND.GameApi.Scripting;
    using AtomicTorch.GameEngine.Common.Primitives;
    using JetBrains.Annotations;

    [UsedImplicitly]
    public class ClientRaidblockWatcher
    {
        public const string Notification_Message_Format =
            @"Repair and building actions are restricted.
              [br]Raid block will expire in: {0}.";

        public const string Notification_Title =
            "This base is under raid block";

        private static HudNotificationControl currentNotification;

        public static bool IsNearOrInsideBaseUnderRaidblock => currentNotification is not null;

        private static string GetNotificationText(double timeRemains)
        {
            if (timeRemains < 1)
            {
                timeRemains = 1;
            }

            return string.Format(Notification_Message_Format,
                                 ClientTimeFormatHelper.FormatTimeDuration(timeRemains));
        }

        private static void Refresh()
        {
            var position = ClientCurrentCharacterHelper.Character?.TilePosition ?? Vector2Ushort.Zero;
            var areasGroup = LandClaimSystem.SharedGetLandClaimAreasGroup(position,    addGracePadding: false)
                             ?? LandClaimSystem.SharedGetLandClaimAreasGroup(position, addGracePadding: true);

            var lastRaidTime = areasGroup is not null
                                   ? LandClaimAreasGroup.GetPublicState(areasGroup).LastRaidTime ?? double.MinValue
                                   : double.MinValue;

            var time = Api.Client.CurrentGame.ServerFrameTimeRounded;
            var timeSinceRaidStart = time - lastRaidTime;
            var timeRemainsToRaidEnd = LandClaimSystemConstants.SharedRaidBlockDurationSeconds - timeSinceRaidStart;
            timeRemainsToRaidEnd = Math.Max(timeRemainsToRaidEnd, 0);

            if (timeRemainsToRaidEnd <= 0)
            {
                // no raid here - hide notification
                currentNotification?.Hide(quick: true);
                currentNotification = null;
                return;
            }

            // raid here, display/update notification
            var text = GetNotificationText(timeRemainsToRaidEnd);
            if (currentNotification is not null
                && !currentNotification.IsHiding)
            {
                currentNotification.Message = text;
                return;
            }

            currentNotification = NotificationSystem.ClientShowNotification(
                title: Notification_Title,
                message: text,
                autoHide: false,
                icon: ClientCurrentBaseUnderRaidWatcher.TextureIconRaidNotification,
                playSound: false);
        }

        private static void Update()
        {
            // schedule next update
            ClientTimersSystem.AddAction(delaySeconds: 0.2, Update);
            Refresh();
        }

        private class Bootstrapper : BaseBootstrapper
        {
            public override void ClientInitialize()
            {
                ClientTimersSystem.AddAction(delaySeconds: 1, Update);
            }
        }
    }
}