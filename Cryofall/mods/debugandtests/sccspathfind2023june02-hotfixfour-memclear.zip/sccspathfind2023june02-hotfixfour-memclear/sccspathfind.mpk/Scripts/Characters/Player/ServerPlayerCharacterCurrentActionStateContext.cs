﻿namespace AtomicTorch.CBND.CoreMod.Characters.Player
{
    using AtomicTorch.CBND.GameApi.Data.Characters;

    public class ServerPlayerCharacterCurrentActionStateContext
    {
        public static ICharacter CurrentCharacter { get; set; }
    }
}