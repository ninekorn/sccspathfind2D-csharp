using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sccsplayer : MonoBehaviour
{




    // Start is called before the first frame update
    void Start()
    {
        rigidbody2d = this.GetComponent<Rigidbody2D>();
    }

    Rigidbody2D rigidbody2d;

    float trust = 0.15f;

    // Update is called once per frame
    void Update()
    {
        if (rigidbody2d != null)
        {
            //Debug.Log("test");

            if (Input.GetKey(KeyCode.W))
            {
                rigidbody2d.AddForce(transform.up * trust, ForceMode2D.Impulse);
            }
            if (Input.GetKey(KeyCode.S))
            {

                rigidbody2d.AddForce(-transform.up * trust, ForceMode2D.Impulse);
            }
            if (Input.GetKey(KeyCode.A))
            {

                rigidbody2d.AddForce(-transform.right * trust, ForceMode2D.Impulse);
            }
            if (Input.GetKey(KeyCode.D))
            {

                rigidbody2d.AddForce(transform.right * trust, ForceMode2D.Impulse);
            }
            if (Input.GetKey(KeyCode.Space))
            {

                rigidbody2d.velocity = new Vector2(0,0);

            }
        }
        else
        {
            rigidbody2d = this.GetComponent<Rigidbody2D>();
        }


    }
}
