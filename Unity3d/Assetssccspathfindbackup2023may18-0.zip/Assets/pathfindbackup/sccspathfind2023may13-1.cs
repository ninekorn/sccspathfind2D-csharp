﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.Experimental.AI;
using static UnityEditor.PlayerSettings;

public class sccspathfind2 : MonoBehaviour
{
    public GameObject tilegreen;
    public GameObject tilered;
    public GameObject tileblue;

    sccsvec2int targetpositioningrid = new sccsvec2int();
    sccspathfindnode theseekernode = new sccspathfindnode();
    sccsvec2int initialpathfindstartpos = new sccsvec2int();
    int noderadius = 1;
    int gridxl = 1;
    int gridxr = 1;
    int gridyb = 1;
    int gridyt = 1;
    /*
    int gridxl = 2;
    int gridxr = 2;
    int gridyb = 2;
    int gridyt = 2;*/

    int gcost = 0;
    int hcost = 0;
    int fcost = 0;

    int xx;
    int yy;
    sccspathfindgridWorldSize gridworldsize = new sccspathfindgridWorldSize();

    sccspathfindgridworldindex gridworldstartlast;

    private static int CompareNodesByFcost(sccspathfindnode x, sccspathfindnode y)
    {
        if (x.nodeinitswtc == 0)
        {
            if (y.nodeinitswtc == 0)
            {
                // If x is null and y is null, they're
                // equal.
                return 0;
            }
            else
            {
                // If x is null and y is not null, y
                // is greater.
                return -1;
            }
        }
        else
        {
            // If x is not null...
            //
            if (y.nodeinitswtc == 0)
            // ...and y is null, x is greater.
            {
                return 1;
            }
            else
            {
                // ...and y is not null, compare the
                // lengths of the two strings.
                //
                int retval = x.fcost.CompareTo(y.fcost);

                if (retval != 0)
                {
                    // If the strings are not of equal length,
                    // the longer string is greater.
                    //
                    return retval;
                }
                else
                {
                    // If the strings are of equal length,
                    // sort them with ordinary string comparison.
                    //
                    return x.fcost.CompareTo(y);
                }
            }
        }
    }


    //sccspathfindnode[] thegrid;
    public struct sccspathfindneighboortile //: MonoBehaviour
    {
        public int swtc;
        public sccspathfindnode node; //
        public sccsvec2int sgp; // start grid pos
        public int iot; // index of tile
        public int iog; // indes of grid
    }

    public struct sccspathfindextraTiles //: MonoBehaviour
    {
        public int x;
        public int y;
        public int worldpositionx;
        public int worldpositiony;

        public int iog; //index of grid
        public sccsvec2int sgp; // start grid pos
        public int iot; // index of tile
        public sccspathfindgriddatafinal docg; //data of current grid
    }

    public class sccspathfindcombineddata
    {
        /*public int hasUnwalkableTiles;
        public sccsvec2int ltp; // last target pos maybe
        public sccsvec2int cFWP; // current formation waypoint
        public sccsvec2int stCoord; // station coordinates
        public sccsvec2int lip; // last init pos
        public sccsvec2int glip; // grid last init pos
        public sccsvec2int lsp; // last seeker post

        public int iop; // index of player
        public float stRot; // station rotation
        public int sSwtc; // switch
        public sccspathfindplayerdata pData; // player data
        public sccspathfindnpcdata nData; // npc data*/


        //public sccspathfindnode[] dataofgrid;// dog;//
        //public List<sccspathfindnode> dog;//data of grid
        //public List<sccspathfindnode[]> log;//list of grids
        //public List<List<sccspathfindnode>> log;//list of grids
        public List<sccspathfindnode[]> log;//list of grids

        public List<sccspathfindnode> openset;
        public List<sccspathfindnode> closedset;
    }

    public struct sccspathfindcheckallsidesdata
    {
        public List<sccspathfindneighboortile> neighboors;
        public List<sccspathfindextraTiles> extraTiles;
    }
    public struct sccspathfindgridWorldSize //: MonoBehaviour
    {
        public int xL; //x axis grid left
        public int xR; //x axis grid right
        public int yT; //y axis grid top
        public int yB; //y axis grid bottom
    }

    public struct sccspathfindnodefinal //: MonoBehaviour
    {
        public sccspathfindnode[] nodelist;

        //public List<sccspathfindnode> nodelist;
        public int pushaddindex;
    }


    public struct sccspathfindnode
    {
        public int open;
        
        public int closed;

        public int nodeinitswtc;

        public int x;
        public int y;
        public int index;
        public int walkable;
        public int isgridlink;
        public int gridindex;
        public int worldpositionx; //meaning the loop from 0 to 9 in a grid 3x3y added to the last initpos of the connected grid
        public int worldpositiony; //meaning the loop from 0 to 9 in a grid 3x3y added to the last initpos of the connected grid

        public int nodelinkedtox;
        public int nodelinkedtoy;
        public int nodelinkedtoindex;
        public int nodelinkedtowalkable;
        public int nodelinkedtoisgridlink;
        public int nodelinkedtogridindex;

        public int gcost;
        public int hcost;
        public int fcost;

        public int gridposx;
        public int gridposy;

        public int gridtilex;
        public int gridtiley;

    }
    public struct sccspathfindgridworldindex //: MonoBehaviour
    {
        public int pushaddindex;
        public int flatindex;

        public int x;
        public int y;
        public int gridX;
        public int gridY;
    }
    public struct sccspathfindgriddatafinal //: MonoBehaviour
    {
        public sccspathfindgridworldindex gridData;
        public int index;
    }

    public struct sccsvec2int //? c# 10.0 //: MonoBehaviour
    {
        public int x;
        public int y;
    }

    private void Start()
    {

    }


    //, sccsvec2int seekerpositioningrid
    //sccspathfindnode[]
    // Start is called before the first frame update
    sccspathfindnodefinal startcreategrid(sccspathfindnode thegridlinknode, sccsvec2int initialpositioningrid, sccsvec2int targetpositioningrid, sccspathfindgridworldindex sccspathfindgridworldindex, out sccspathfindgriddatafinal gridinfo, int pathfinditeration) //sccspathfindnode thegridlinknode //sccsvec2int seekerpositioningrid, //, sccsvec2int gridlastinitpos
    {

        gridinfo = new sccspathfindgriddatafinal();


        sccspathfindnode[] thegrid = new sccspathfindnode[(gridxl + gridxr + 1) * (gridyb + gridyt + 1)];


        //List<sccspathfindnode> thegrid = new List<sccspathfindnode>();

        //sccspathfindnode[] thegrid = new sccspathfindnode[(gridxl + gridxr + 1) * (gridyb + gridyt + 1)];

        //sccspathfindcombineddatavar.dataofgrid = thegrid;



        //int lastworldpositionx = 0;
        //int lastworldpositiony = 0;


        sccsvec2int gridlastinitpos = new sccsvec2int();
        gridlastinitpos.x = sccspathfindgridworldindex.x;// thegridlinknode.gridposx;
        gridlastinitpos.y = sccspathfindgridworldindex.y;//thegridlinknode.gridposy;

        sccsvec2int seekerpositioningrid = new sccsvec2int();
        seekerpositioningrid.x = thegridlinknode.x;
        seekerpositioningrid.y = thegridlinknode.y;


        /*if (pathfinditeration == 1)
        {
            Debug.Log("thegridlinknode.x:" + thegridlinknode.x + "/y:" + thegridlinknode.y);
        }*/

        //if (pathfinditeration == 1)
        {
            Debug.Log("thegridlinknode.x:" + gridlastinitpos.x + "/y:" + gridlastinitpos.y);
        }



        /*sccsvec2int gridlastinitpos = new sccsvec2int();
        gridlastinitpos.x = 0;
        gridlastinitpos.y = 0;*/

        /*sccsvec2int seekerpositioningrid = new sccsvec2int();
        seekerpositioningrid.x = 0;
        seekerpositioningrid.y = 0;

        sccsvec2int initialpositioningrid = new sccsvec2int();
        initialpositioningrid.x = 0;
        initialpositioningrid.y = 0;*/


        /*
        if (thegridlinknode.nodeinitswtc == 0)
        {
            //the starting node link is invalid or the node has no parent. it must be the start position.
            initialpositioningrid.x = thegridlinknode.x;
            initialpositioningrid.y = thegridlinknode.y;
            thegridlinknode.nodeinitswtc = 1;
        }
        */



        //Debug.Log("thegridlinknode.nodeinitswtc:" + thegridlinknode.nodeinitswtc);

        //var gridWorldSize = { xL: 1, xR: 0, yB: 1, yT: 0 }; //{ xL: 5, xR: 4, yB: 5, yT: 4};

        //Debug.Log("/x:" + targetpositioningrid.x + "/y:" + targetpositioningrid.y);

        xx = 0;
        yy = 0;

        for (int x = -gridxl; x <= gridxr; x++)
        {
            for (int y = -gridyb; y <= gridyt; y++)
            {
                xx = x;
                yy = y;

                //i use grids where the starting point is the middle of the grids, so we have to use negative and positive digits. i better understood during development how to fetch the index
                //of a list (array of objects in javascript ecmascript5) when pushing the value inside of the list. How i visualized it is as if each additional items in the list, is a node that
                //adds up to 0 in a spiral:      

                //-----------------------------------------------------------------------------------------------------------

                //  a grid of 3x3y visualized on how the count/length of the list increases when i add a new item and we visualize it in spiral.
                //  |06|07|08|  //>>> //→→→ //different unicode for the arrows characters causes visual studio 2022 to popup a different script encoding. applied to all scripts.
                //  |05|00|01|  //^>v //↑→↓
                //  |04|03|02|  //^<< //↑←←

                //  the grid positions are for a small grid
                //  |-01, 01|00, 01|01, 01|
                //  |-01, 00|00, 00|01, 00|
                //  |-01,-01|00,-01|01,-01|

                //  the position between 0 to 8 in a negative loop 3x3y that have to be set as grid left -1 to grid right 1
                // total values is looping the x and y. (var index = xx * (gridxl + gridxr + 1) + yy;) vs the the flat index of the nodes negatives vs the flat index positive.

                //  how the loop loops x then y         negative/positive indexes       positive indexes only
                //      | 06| 07| 08|                   | 02| 03| 04|                   | 05| 03| 04| 
                //      | 03| 04| 05|                   |-01| 00| 01|                   | 02| 00| 01| 
                //      | 00| 01| 02|                   |-04|-03|-02|                   | 08| 06| 07| 
                //                                                      
                //-----------------------------------------------------------------------------------------------------------

                //  or a big grid of 5x5
                //  |20|21|22|23|24|    →→→→→ 
                //  |19|06|07|08|09|    ↑→→→↓
                //  |18|05|00|01|10|    ↑↑→↓↓  
                //  |17|04|03|02|11|    ↑↑←←↓ 
                //  |16|15|14|13|12|    ↑←←←←

                //  the grid positions for a big grid
                //  |-02, 02|-01, 02|00, 02|01, 02|02, 02|
                //  |-02, 01|-01, 01|00, 01|01, 01|02, 01|
                //  |-02, 00|-01, 00|00, 00|01, 00|02, 00|
                //  |-02,-01|-01,-01|00,-01|01,-01|02,-01|
                //  |-02,-02|-01,-02|00,-02|01,-02|02,-02|

                // the flat index of the nodes vs the position between 0 to 8 in a negative loop in a grid of 5x5y that have to be set as grid left -2 to grid right 2
                // total values is looping the x and y. var index = xx * (gridxl + gridxr + 1) + yy; <= to get the index

                //  | 20| 21| 22| 23| 24|       |  08|  09|  10|  11|  12|        | 14| 13| 10| 11| 12|
                //  | 15| 16| 17| 18| 19|       |  03|  04|  05|  06|  07|        | 09| 08| 05| 06| 07|
                //  | 10| 11| 12| 13| 14|       | -02| -01|  00|  01|  02|        | 04| 03| 00| 01| 02|
                //  | 05| 06| 07| 08| 09|       | -07| -06| -05| -04| -03|        | 19| 18| 15| 16| 17|
                //  | 00| 01| 02| 03| 04|       | -12| -11| -10| -09| -08|        | 24| 23| 20| 21| 22|

                //-----------------------------------------------------------------------------------------------------------

                //to use the index x and y, we cannot use negative integers, so we have to make an array of the proper size, and then we can multiply by -1 the value and add the right
                //size of the array to get the positive index; as long as we always use the same way to fetch the indexes, the indexes won't change.

                if (xx < 0)
                {
                    xx *= -1;
                    xx = (gridxr) + xx;
                }

                if (yy < 0)
                {
                    yy *= -1;
                    yy = (gridyt) + yy;
                }

                //var index = xux * (gridWorldSize.xL + gridWorldSize.xR + 1) + yuy;
                //var index = x * (gridxl + gridxr + 1) + y;
                var index = xx * (gridxl + gridxr + 1) + yy; //y * height + x 

                //Debug.Log(index);
                //Debug.Log("/x:" + x + "/y:" + y + "/gcost:" + gcost + "/hcost:" + hcost + "/fcost:" + fcost);

                sccspathfindnode thecurrentnode = new sccspathfindnode();

                thecurrentnode.nodeinitswtc = 1;

                thecurrentnode.x = x;
                thecurrentnode.y = y;

             


                //TO WORK ON
                thecurrentnode.worldpositionx = gridlastinitpos.x + x;
                thecurrentnode.worldpositiony = gridlastinitpos.y + y;
                //TO WORK ON

                sccsvec2int currentnode = new sccsvec2int();
                currentnode.x = thecurrentnode.worldpositionx;
                currentnode.y = thecurrentnode.worldpositiony;



                //var gcost1 = checknodedistancefloat(seekerpositioningrid, currentnode);
                //var hcost1 = checknodedistancefloat(targetpositioningrid, currentnode);

                //Debug.Log("gcost:" + gcost1 + "/hcost:" + hcost1);

                gcost = (int)checknodedistancefloat(seekerpositioningrid, currentnode);
                hcost = (int)checknodedistancefloat(targetpositioningrid, currentnode);
                fcost = gcost + hcost;


                thecurrentnode.gcost = gcost;
                thecurrentnode.hcost = hcost;
                thecurrentnode.fcost = fcost;

                thecurrentnode.gridtilex = x;
                thecurrentnode.gridtiley = y;


                thecurrentnode.gridposx = gridinfo.gridData.x;
                thecurrentnode.gridposy = gridinfo.gridData.y;

                //Debug.Log("currentnodepos:" + "/x:" + currentnode.x + "/y:" + currentnode.y);



                //TO WORK ON
                gridinfo = getNewGridIndex(initialpositioningrid, currentnode, gridworldsize);
                //TO WORK ON
                //gridinfo.gridData = sccspathfindgridworldindex;

                GameObject cubeobj = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
                cubeobj.transform.position = new Vector3(thecurrentnode.worldpositionx, thecurrentnode.worldpositiony, 0);
                cubeobj.transform.rotation = Quaternion.identity;
                cubeobj.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);


                

                thecurrentnode.gridindex = gridinfo.index;

                //Debug.Log("gridindex:" + thecurrentnode.gridindex);

                thecurrentnode.index = index;



                if (initialpositioningrid.x == currentnode.x && initialpositioningrid.y == currentnode.y)
                //if (initialpositioningrid.x == thegridlinknode.x && initialpositioningrid.y == thegridlinknode.y)
                {

                    Debug.Log("this should fire once");
                    //Debug.Log("gcost:" + thecurrentnode.gcost + "/hcost:" + thecurrentnode.fcost);
                    //Debug.Log("gcost:" + thecurrentnode.gcost + "/hcost:" + thecurrentnode.fcost);

                    //TO WORK ON
                    //thecurrentnode.walkable = 1;
                    //TO WORK ON
                    //thecurrentnode.isgridlink = 0;

                    sccspathfindcombineddatavar.openset.Add(thecurrentnode);
                    heapSort(sccspathfindcombineddatavar.openset, sccspathfindcombineddatavar.openset.Count - 1, "fcost");
                    theseekernode = sccspathfindcombineddatavar.openset.First();
                    //this is the start node of the pathfind.
                    //thegridlinknode.nodeinitswtc = 0;
                }
                else
                {
                    //TO WORK ON
                    //thecurrentnode.walkable = 1;
                    //TO WORK ON
                    //TO WORK ON
                    //thecurrentnode.isgridlink = 1;
                    //TO WORK ON
                }






                //thegridlinknode.nodeinitswtc = 1;

                thecurrentnode.walkable = 1;
                //thecurrentnode.isgridlink = 0;
                thecurrentnode.closed = 0;
                thecurrentnode.open = 0;

                //TO WORK ON
                /*if (thegridlinknode.nodeinitswtc == 1)
                {
                    thecurrentnode.nodelinkedtowalkable = thegridlinknode.walkable;
                    thecurrentnode.nodelinkedtogridindex = thegridlinknode.gridindex;
                    thecurrentnode.nodelinkedtoindex = thegridlinknode.index;
                    thecurrentnode.nodelinkedtoisgridlink = thegridlinknode.isgridlink;
                    thecurrentnode.nodelinkedtox = thegridlinknode.x;
                    thecurrentnode.nodelinkedtoy = thegridlinknode.y;
                }
                else
                {

                }*/
                //TO WORK ON



                //thegrid.Add(thecurrentnode);
                thegrid[index] = thecurrentnode;
    
            }
        }








        if (sccspathfindcombineddatavar.log.Count == 0)
        {
            for (int g = 0; g < (gridxl + gridxr + 1) * (gridyb + gridyt + 1); g++)
            {
                sccspathfindcombineddatavar.log.Add(null);
            }
            //sccspathfindcombineddatavar.log.Add(finalnodelist.nodelist);
            sccspathfindcombineddatavar.log[gridinfo.index] = thegrid;
        }
        else
        {
            var diff0 = gridinfo.index - sccspathfindcombineddatavar.log.Count;
            for (int g = 0; g < diff0; g++)
            {
                sccspathfindcombineddatavar.log.Add(null);
            }
            sccspathfindcombineddatavar.log[gridinfo.index] = thegrid;
        }




        sccspathfindnodefinal finalnodelist = new sccspathfindnodefinal();
        finalnodelist.nodelist = thegrid;











        return finalnodelist;
    }


    sccspathfindcombineddata sccspathfindcombineddatavar = new sccspathfindcombineddata();

    public int startpathfind = 0;
    int isgridcreated = 0;
    // Update is called once per frame
    void Update()
    {
        if (startpathfind == 1)
        {

            gridworldsize.xL = gridxl;
            gridworldsize.xR = gridxr;
            gridworldsize.yB = gridyb;
            gridworldsize.yT = gridyt;


            sccsvec2int playerpos = new sccsvec2int();
            playerpos.x = 0;
            playerpos.y = 0;


            initialpathfindstartpos.x = playerpos.x;
            initialpathfindstartpos.y = playerpos.y;

            /*
            int randposx = (int)getSomeRandNumThousandDecimal(-gridxl, gridxr + 1, 1, 0, 0);
            int randposy = (int)getSomeRandNumThousandDecimal(-gridyb, gridyt + 1, 1, 0, 0);

            sccsvec2int targetpositioningrid = new sccsvec2int();
            targetpositioningrid.x = randposx;
            targetpositioningrid.y = randposy;*/
            /*
            int randposx =  (int)getSomeRandNumThousandDecimal(-10, 10, 1, 0, 0);
            int randposy = (int)getSomeRandNumThousandDecimal(-10, 10, 1, 0, 0);
            */
            /*
            int randposx = (int)getSomeRandNumThousandDecimal(-gridxl, gridxr + 1, 1, 0, 0);
            int randposy = (int)getSomeRandNumThousandDecimal(-gridyb, gridyt + 1, 1, 0, 0);*/

            int randposx = 9;
            int randposy = 9;


            Debug.Log("/playerposx" + randposx + "/playerposy:" + randposy);

            targetpositioningrid.x = randposx;
            targetpositioningrid.y = randposy;


            theseekernode.x = initialpathfindstartpos.x;
            theseekernode.y = initialpathfindstartpos.y;
            theseekernode.index = 0;
            theseekernode.gridtilex = 0;
            theseekernode.gridtiley = 0;
            theseekernode.walkable = 1;
            theseekernode.worldpositionx = 0;
            theseekernode.worldpositiony = 0;

            




            if (sccspathfindcombineddatavar.openset == null)
            {
                sccspathfindcombineddatavar.openset = new List<sccspathfindnode>();
            }


            if (sccspathfindcombineddatavar.closedset == null)
            {
                sccspathfindcombineddatavar.closedset = new List<sccspathfindnode>();
            }


            if (sccspathfindcombineddatavar.log == null)
            {
                //sccspathfindcombineddatavar.log = new List<List<sccspathfindnode>>();
                sccspathfindcombineddatavar.log = new List<sccspathfindnode[]>();

            }


            /*if (sccspathfindcombineddatavar.log != null)
            {
                sccspathfindcombineddatavar.log.Clear();
            }
            else
            {
                sccspathfindcombineddatavar.log = new List<List<sccspathfindnode>>();
            }*/

            /*
            if (sccspathfindcombineddatavar.openset != null)
            {
                sccspathfindcombineddatavar.openset.Clear();
            }
            else
            {
                sccspathfindcombineddatavar.openset = new List<sccspathfindnode>();
            }

            if (sccspathfindcombineddatavar.closedset != null)
            {
                sccspathfindcombineddatavar.closedset.Clear();
            }
            else
            {
                sccspathfindcombineddatavar.closedset = new List<sccspathfindnode>();
            }*/

            //sccspathfindcombineddatavar.openset.Add(thegridlinknode);


            //Debug.Log(sccspathfindcombineddatavar.openset.Count);


            startpathfind = 2;
            isgridcreated = 1;
            //startpathfind = 2;
        }

        try
        {


            if (startpathfind == 2)
            {
                if (isgridcreated == 1)
                {
                    int pathfinditeration = 6;

                    for (int p = 0; p < pathfinditeration; p++)
                    {
                        Debug.Log("CURRENT PATHFIND ITERATION: " + p);


                        /*
                        if (p != 0)
                        {
                            thegridlinknode.x = initialpathfindstartpos.x;
                            thegridlinknode.y = initialpathfindstartpos.y;
                            thegridlinknode.index = 0;
                            thegridlinknode.gridtilex = 0;
                            thegridlinknode.gridtiley = 0;
                            thegridlinknode.walkable = 1;
                        }
                        */

                        //Instantiate(tilegreen, new Vector3(thegridlinknode.worldpositionx, thegridlinknode.worldpositiony), Quaternion.identity);

                        /*
                        GameObject cubeobj = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
                        cubeobj.transform.position = new Vector3(thegridlinknode.worldpositionx, thegridlinknode.worldpositiony,0);
                        cubeobj.transform.rotation = Quaternion.identity;
                        cubeobj.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                        */


                        sccsvec2int initposnewgrid0 = new sccsvec2int();
                        initposnewgrid0.x = theseekernode.worldpositionx;
                        initposnewgrid0.y = theseekernode.worldpositiony;
                        
                        //Debug.Log("/x:" + initposnewgrid0.x + "/y:" + initposnewgrid0.y);

                        var gridData00 = getNewGridIndex(initialpathfindstartpos, initposnewgrid0, gridworldsize);

                        sccspathfindgridworldindex gridworldstart = new sccspathfindgridworldindex();
                        gridworldstart.x = gridData00.gridData.x;
                        gridworldstart.y = gridData00.gridData.y;

                        gridworldstart.gridX = gridData00.gridData.gridX;
                        gridworldstart.gridY = gridData00.gridData.gridY;
                        //gridworldstart.pushaddindex = gridData00.gridData.pushaddindex;
                        //gridworldstart.flatindex = gridData00.gridData.flatindex;

                        //  or a big grid of 5x5
                        //  |20|21|22|23|24|    →→→→→ 
                        //  |19|06|07|08|09|    ↑→→→↓
                        //  |18|05|00|01|10|    ↑↑→↓↓  
                        //  |17|04|03|02|11|    ↑↑←←↓ 
                        //  |16|15|14|13|12|    ↑←←←←
                        


                        sccspathfindgriddatafinal gridData0;

                        var diff0 = theseekernode.gridindex - (sccspathfindcombineddatavar.log.Count);

                        for (int g = 0; g < diff0 + 1; g++)
                        {
                            sccspathfindcombineddatavar.log.Add(null);
                        }

                        //Debug.Log("***log.count***:" + sccspathfindcombineddatavar.log.Count + "/iog:" + theseekernode.gridindex);

                        if (sccspathfindcombineddatavar.log[theseekernode.gridindex] == null)
                        {
                            startcreategrid(theseekernode, initialpathfindstartpos, targetpositioningrid, gridworldstart, out gridData0, p);
                        }




                        Debug.Log("gridData00: " + gridData00.index);


                        /*
                        if (gridData0.index == gridData00.index)
                        {
                            Debug.Log("same grids. that result is perfect.");
                            startpathfind = 3;
                        }*/

                        //finalnodelist.pushaddindex = sccspathfindcombineddatavar.log.Count;

                        //Debug.Log("pathfinditeration:" + p + "openset.count:" + sccspathfindcombineddatavar.openset.Count);
                        //if (sccspathfindcombineddatavar.openset.Count >= 1)
                        {
                            //Debug.Log(sccspathfindcombineddatavar.openset.Count);
                            //sort openset for lowest fcost
                            //sccspathfindcombineddatavar.openset = heapSort(sccspathfindcombineddatavar.openset, sccspathfindcombineddatavar.openset.Count, "fcost");
                            /*heapSort(sccspathfindcombineddatavar.openset, sccspathfindcombineddatavar.openset.Count - 1, "fcost");

                            //Debug.Log("/fcost:" + sccspathfindcombineddatavar.openset[0].fcost);



                            thegridlinknode = sccspathfindcombineddatavar.openset.First();*/


                            //sccspathfindcombineddatavar.openset.Remove(thegridlinknode);
                            //Debug.Log(sccspathfindcombineddatavar.openset.Count);
                            //sccspathfindcombineddatavar.openset.RemoveAt(0);
                            //Debug.Log(sccspathfindcombineddatavar.openset.Count);

                            //sccspathfindnode node = sccspathfindcombineddatavar.openset[0];




                            /*for (int i = 1; i < sccspathfindcombineddatavar.openset.Count; i++)
                            {
                                if (sccspathfindcombineddatavar.openset[i].fcost < thegridlinknode.fcost || sccspathfindcombineddatavar.openset[i].fcost == thegridlinknode.fcost)
                                {
                                    if (sccspathfindcombineddatavar.openset[i].hcost < thegridlinknode.hcost)
                                        thegridlinknode = sccspathfindcombineddatavar.openset[i];
                                }
                            }*/

                            //thegridlinknode.nodelinkedtoisgridlink = 1;



                            GameObject cubeobj1 = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
                            cubeobj1.transform.position = new Vector3(theseekernode.worldpositionx, theseekernode.worldpositiony, 0);
                            cubeobj1.transform.rotation = Quaternion.identity;
                            cubeobj1.transform.localScale = new Vector3(0.1f, 1.15f, 0.1f);

                            //thegridlinknode.closed = 1;
                            //sccspathfindcombineddatavar.closedset.Add(thegridlinknode);

                            if (theseekernode.worldpositionx == targetpositioningrid.x && theseekernode.worldpositiony == targetpositioningrid.y)
                            {
                                Debug.Log("found target node");
                                startpathfind = 3;
                                return;
                            }

                            //when reaching the end of a grid and finding null nodes, instead, i am assigning values to the nodes and adding them in the extratiles if the grid where
                            //those tiles are isn't built yet.

                            //discovered grid       undiscovered grid
                            //678                   678
                            //501                   501  
                            //432                   432

                            //let's say we are checking the neighboors for the tile #1 of the discovered grid, this is going to output the tiles 6/5/4 of the adjacent grid which is 
                            //undiscovered so it is null, hence the tiles wouldn't exist, but instead i add the position to a new list extra tiles and deal with them separately.

                            //678       8 678
                            //501      01 501
                            //432       2 432





                            var neighboorandextratiles = checkAllSidesGridIndex(theseekernode, gridworldsize, sccspathfindcombineddatavar, initialpathfindstartpos, gridData00.gridData);//cData.lip //, gridData00.gridData

                            //var neighboortiles = neighboorandextratiles.neighboors;
                            //var extratiles = neighboorandextratiles.extraTiles;

                            Debug.Log("extratilescount:" + neighboorandextratiles.extraTiles.Count);

                            if (neighboorandextratiles.extraTiles != null)
                            {
                                if (neighboorandextratiles.extraTiles.Count > 0)
                                {
                                    for (var i = 0; i < neighboorandextratiles.extraTiles.Count; i++)
                                    {
                                        /*
                                        GameObject cubeobj = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        cubeobj.transform.position = new Vector3(neighboorandextratiles.extraTiles[i].worldpositionx, neighboorandextratiles.extraTiles[i].worldpositiony,0 );
                                        cubeobj.transform.rotation = Quaternion.identity;
                                        cubeobj.transform.localScale = new Vector3(0.5f, 0.5f, 1.0f);
                                        */

                                        //Debug.Log("test");

                                        sccsvec2int initposnewgrid = new sccsvec2int();

                                        initposnewgrid.x = neighboorandextratiles.extraTiles[i].worldpositionx;
                                        initposnewgrid.y = neighboorandextratiles.extraTiles[i].worldpositiony;
                                        //Debug.Log("/x:" + initposnewgrid.x + "/y:" + initposnewgrid.y);

                                        var gridData = getNewGridIndex(initialpathfindstartpos, initposnewgrid, gridworldsize); //, cData.objt.sid

                                        //var gridIndex = neighboorandextratiles.extraTiles[i].iog; //.docg.index;

                                        if (gridData.index == neighboorandextratiles.extraTiles[i].iog)
                                        {
                                            //Debug.Log("THE INDEX IS THE SAME");
                                        }




                                        //Debug.Log("/sccspathfindcombineddatavar.log.Count:0" + sccspathfindcombineddatavar.log.Count);

                                        var diff = neighboorandextratiles.extraTiles[i].iog - sccspathfindcombineddatavar.log.Count;

                                        for (int g = 0; g < diff; g++)
                                        {
                                            sccspathfindcombineddatavar.log.Add(null);
                                        }







                                        //Debug.Log("/sccspathfindcombineddatavar.log.Count:1" + sccspathfindcombineddatavar.log.Count);




                                        //int xpos = Mathf.RoundToInt(node.worldpositionx + x);
                                        //int ypos = Mathf.RoundToInt(node.worldpositiony + y);
                                        //var pos = new sccsvec2int { x = xpos, y = ypos };
                                        //var gridData = getNewGridIndex(initialPos, pos, gridWorldSize); //, cData.objt.sid


                                        /*
                                        if (p == pathfinditeration -1)
                                        {
                                            Debug.Log("gindex:" + gridData.index + "/x:" + gridData.gridData.gridX + "/y:" + gridData.gridData.gridY);
                                        }*/
                      



                                        sccsvec2int posofgrid = new sccsvec2int();
                                        posofgrid.x = gridData.gridData.gridX;
                                        posofgrid.y = gridData.gridData.gridY;

                                        //Debug.Log("gindex:" + gridData.index + "/x:" + gridData.gridData.gridX + "/y:" + gridData.gridData.gridY);




                                        sccspathfindgridworldindex gridworldlink = new sccspathfindgridworldindex();
                                        gridworldlink.x = gridData.gridData.x;
                                        gridworldlink.y = gridData.gridData.y;
                                        gridworldlink.gridX = gridData.gridData.gridX;
                                        gridworldlink.gridY = gridData.gridData.gridY;




                                        if (sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog] != null)//gridData.index == gridData00.index)
                                        {

                                        }
                                        else
                                        {
                                            Debug.Log("the grid is null. creating new grid.");

                                            var result = startcreategrid(theseekernode, initialpathfindstartpos, targetpositioningrid, gridworldlink, out gridData0, p); //posofgrid//var finalnodelist1 = 
                           
                                        }

                                        var pos0 = new sccsvec2int();
                                        pos0.x = theseekernode.worldpositionx;
                                        pos0.y = theseekernode.worldpositiony;


                                        //var pos1 = new sccsvec2int();
                                        // pos1.x = neighboorandextratiles.neighboors[j].node.worldpositionx;
                                        //pos1.y = neighboorandextratiles.neighboors[j].node.worldpositiony;

                                        var pos1 = new sccsvec2int();
                                        pos1.x = neighboorandextratiles.extraTiles[i].worldpositionx;
                                        pos1.y = neighboorandextratiles.extraTiles[i].worldpositiony;



                                        var gcost = theseekernode.gcost + checknodedistanceint(pos0, pos1);



                                        sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].gcost = gcost;
                                        sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].hcost = checknodedistanceint(pos1, targetpositioningrid);
                                        sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].fcost = sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].gcost + sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].hcost;


                                        Debug.Log("END OF EXTRA TILES");
                                        var emptygridvec = new sccsvec2int();
                                        emptygridvec.x = 0;
                                        emptygridvec.y = 0;
                                        //neighboorandextratiles.neighboors.Add(new sccspathfindneighboortile { swtc = 0, node = sccspathfindcombineddatavar.log[gridData0.index][gn], sgp = emptygridvec, iot = sccspathfindcombineddatavar.log[gridData0.index][gn].index, iog = gridData0.index });

                                        //neighboorandextratiles.neighboors.Add(new sccspathfindneighboortile { swtc = 0, node = sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot], sgp = emptygridvec, iot = sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].index, iog = sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].gridindex });
                                        neighboorandextratiles.neighboors.Add(new sccspathfindneighboortile { swtc = 0, node = sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot], sgp = emptygridvec, iot = sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].index, iog = sccspathfindcombineddatavar.log[neighboorandextratiles.extraTiles[i].iog][neighboorandextratiles.extraTiles[i].iot].gridindex });


                                        GameObject cubeobj = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        cubeobj.transform.position = new Vector3(neighboorandextratiles.extraTiles[i].worldpositionx, neighboorandextratiles.extraTiles[i].worldpositiony, 0);//thegridlinknode.worldpositionx, thegridlinknode.worldpositiony, 0);
                                        cubeobj.transform.rotation = Quaternion.identity;
                                        cubeobj.transform.localScale = new Vector3(0.1f, 0.1f, 1.0f);

                                    }
                                }
                            }


                            //Debug.Log("frame arrives here");





                            if (neighboorandextratiles.neighboors.Count > 0)
                            {
                                for (var j = 0; j < neighboorandextratiles.neighboors.Count; j++)
                                {
                                    //if (neighboorandextratiles.neighboors[j].node.nodeinitswtc == 1)
                                    {
                                        //Debug.Log("coming here0");
                                        if (sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].closed == 1 ||
                                            sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].walkable == 0)
                                        {
                                            continue;
                                        }

                                        var pos0 = new sccsvec2int();
                                        pos0.x = theseekernode.worldpositionx;
                                        pos0.y = theseekernode.worldpositiony;

                                        //var pos1 = new sccsvec2int();
                                        // pos1.x = neighboorandextratiles.neighboors[j].node.worldpositionx;
                                        //pos1.y = neighboorandextratiles.neighboors[j].node.worldpositiony;

                                        var pos1 = new sccsvec2int();
                                        pos1.x = neighboorandextratiles.neighboors[j].node.worldpositionx;
                                        pos1.y = neighboorandextratiles.neighboors[j].node.worldpositiony;



                                        var gcost = theseekernode.gcost + checknodedistanceint(pos0, pos1);


                                        /*GameObject cubeobj2 = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        cubeobj2.transform.position = new Vector3(thegridlinknode.worldpositionx, thegridlinknode.worldpositiony, 0);
                                        cubeobj2.transform.rotation = Quaternion.identity;
                                        cubeobj2.transform.localScale = new Vector3(2.5f, 0.5f, 2.5f);

                                        GameObject cubeobj2 = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
                                        cubeobj2.transform.position = new Vector3(neighboorandextratiles.neighboors[j].node.worldpositionx, neighboorandextratiles.neighboors[j].node.worldpositiony, 0);
                                        cubeobj2.transform.rotation = Quaternion.identity;
                                        cubeobj2.transform.localScale = new Vector3(0.5f, 0.5f, 1.0f);

                                        */





                                        //Debug.Log("coming here1 " + " gcost:" + gcost + "/gcostneighboor:" + neighboorandextratiles.neighboors[j].node.gcost);

                                        if (gcost < neighboorandextratiles.neighboors[j].node.gcost || sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].open == 0) // || sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].open == 0
                                        {
                                            //Debug.Log("coming here2");

                                            var neighboortile = neighboorandextratiles.neighboors[j];
                                            neighboortile.node.gcost = gcost;
                                            neighboortile.node.hcost = checknodedistanceint(pos1, targetpositioningrid);
                                            neighboortile.node.fcost = neighboorandextratiles.neighboors[j].node.gcost + neighboorandextratiles.neighboors[j].node.hcost;

                                            //neighboortile.node.nodelinkedtowalkable = thegridlinknode.walkable;
                                            /*neighboortile.node.nodelinkedtogridindex = thegridlinknode.gridindex;
                                            neighboortile.node.nodelinkedtoindex = thegridlinknode.index;
                                            neighboortile.node.nodelinkedtoisgridlink = thegridlinknode.isgridlink;
                                            neighboortile.node.nodelinkedtox = thegridlinknode.x;
                                            neighboortile.node.nodelinkedtoy = thegridlinknode.y;*/

                                            neighboorandextratiles.neighboors[j] = neighboortile;
                                            sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].gcost = neighboortile.node.gcost;
                                            sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].hcost = neighboortile.node.hcost;
                                            sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].fcost = neighboortile.node.fcost;


                                            if (sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].open == 0)
                                            {
                                                //Debug.Log("coming here3");
                                                sccspathfindcombineddatavar.openset.Add(neighboorandextratiles.neighboors[j].node);

                                                //sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].open = 1;
                                                //var atile = sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index];
                                                //atile.open = 1;
                                                //sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index] = atile;
                                                sccspathfindcombineddatavar.log[neighboorandextratiles.neighboors[j].node.gridindex][neighboorandextratiles.neighboors[j].node.index].open = 1;

                                                /*GameObject cubeobj3 = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
                                                cubeobj3.transform.position = new Vector3(pos1.x, pos1.y,0);// new Vector3(thegridlinknode.worldpositionx, thegridlinknode.worldpositiony, 0);
                                                cubeobj3.transform.rotation = Quaternion.identity;
                                                cubeobj3.transform.localScale = new Vector3(2.5f, 0.5f, 2.5f);*/


                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {

                            }








                            Debug.Log("openset.count:" + sccspathfindcombineddatavar.openset.Count);

                            if (sccspathfindcombineddatavar.openset.Count > 0)
                            {

                                //Debug.Log("COUNT0 " + sccspathfindcombineddatavar.openset.Count);
                                sccspathfindcombineddatavar.openset.RemoveAt(0);
                                //Debug.Log("COUNT1: " + sccspathfindcombineddatavar.openset.Count);

                                /*
                                sccspathfindcombineddatavar.openset.RemoveAt(sccspathfindcombineddatavar.openset.Count-1);
                                */
                                //sccspathfindcombineddatavar.openset.Remove(theseekernode);

                                heapSort(sccspathfindcombineddatavar.openset, sccspathfindcombineddatavar.openset.Count, "fcost");
                                //Debug.Log("/m0gcost:" + theseekernode.gcost + "/m0hcost:" + theseekernode.hcost + "/m0fcost:" + theseekernode.fcost);

                                /*for (int i = 1; i < sccspathfindcombineddatavar.openset.Count; i++)
                                {
                                    if (sccspathfindcombineddatavar.openset[i].fcost < theseekernode.fcost || sccspathfindcombineddatavar.openset[i].fcost == theseekernode.fcost)
                                    {
                                        if (sccspathfindcombineddatavar.openset[i].hcost < theseekernode.hcost)
                                        {
                                            //if (sccspathfindcombineddatavar.openset[i].gcost < theseekernode.gcost)
                                            theseekernode = sccspathfindcombineddatavar.openset[i];
                                        }
                                    }
                                }*/



                                //Debug.Log("/m1gcost:" + theseekernode.gcost + "/m1hcost:" + theseekernode.hcost + "/m1fcost:" + theseekernode.fcost);

                                for (int i = 0; i < sccspathfindcombineddatavar.openset.Count; i++)
                                {
                                    if (sccspathfindcombineddatavar.openset[i].index == 0)
                                    {
                                        Debug.Log("the first tile wasn't removed from the array");
                                    }
                                    Debug.Log("/gcost:" + sccspathfindcombineddatavar.openset[i].gcost + "/hcost:" + sccspathfindcombineddatavar.openset[i].hcost + "/fcost:" + sccspathfindcombineddatavar.openset[i].fcost);
                                    //Instantiate(tilegreen, new Vector3(sccspathfindcombineddatavar.openset[i].worldpositionx, sccspathfindcombineddatavar.openset[i].worldpositiony), Quaternion.identity);
                                }

                                Instantiate(tilegreen, new Vector3(sccspathfindcombineddatavar.openset[0].worldpositionx, sccspathfindcombineddatavar.openset[0].worldpositiony), Quaternion.identity);


                                //theseekernode = sccspathfindcombineddatavar.openset.First();
                                //sccspathfindcombineddatavar.openset.RemoveAt(0);

                                theseekernode = sccspathfindcombineddatavar.openset.First();

                                //sccspathfindcombineddatavar.openset.RemoveAt(0);
                                theseekernode.closed = 1;
                                sccspathfindcombineddatavar.closedset.Add(theseekernode);

                                sccspathfindcombineddatavar.log[theseekernode.gridindex][theseekernode.index].open = 0;
                                sccspathfindcombineddatavar.log[theseekernode.gridindex][theseekernode.index].closed = 1;
                            }
                        }
                        //else
                        {
                            //Debug.Log("openset is empty");
                            //startpathfind = 3;
                        }


                        
                        /*Debug.Log("/fcost:" + sccspathfindcombineddatavar.openset[0].fcost);



                        thegridlinknode = sccspathfindcombineddatavar.openset.First();

                        //Debug.Log(sccspathfindcombineddatavar.openset.Count);
                        sccspathfindcombineddatavar.openset.RemoveAt(0);
                        thegridlinknode.closed = 1;
                        sccspathfindcombineddatavar.closedset.Add(thegridlinknode);*/




                        /*
                        for (int i = 1; i < sccspathfindcombineddatavar.openset.Count; i++)
                        {
                            if (sccspathfindcombineddatavar.openset[i].fcost < thegridlinknode.fcost || sccspathfindcombineddatavar.openset[i].fcost == thegridlinknode.fcost)
                            {
                                if (sccspathfindcombineddatavar.openset[i].hcost < thegridlinknode.hcost)
                                    thegridlinknode = sccspathfindcombineddatavar.openset[i];
                            }
                        }*/


                        /*
                        for (int l = 0;l < sccspathfindcombineddatavar.openset.Count;l++)
                        {
                            Debug.Log(sccspathfindcombineddatavar.openset[l].fcost);
                        }*/










                        //Debug.Log(sccspathfindcombineddatavar.openset.Count);


                        //Debug.Log("/x:" + sccspathfindcombineddatavar.openset[0].x + "/y:" + sccspathfindcombineddatavar.openset[0].y);









                        /*
                        sccspathfindcombineddatavar.openset.RemoveAt(0);


                        //thegridlinknode = sccspathfindcombineddatavar.openset.First();

                        //Debug.Log(sccspathfindcombineddatavar.openset.Count);
                        //sccspathfindcombineddatavar.openset.RemoveAt(0);
                        //Debug.Log(sccspathfindcombineddatavar.openset.Count);
                        thegridlinknode.closed = 1;
                        sccspathfindcombineddatavar.closedset.Add(thegridlinknode);

                        //Debug.Log(sccspathfindcombineddatavar.openset.Count);
                        if (sccspathfindcombineddatavar.openset.Count > 1)
                        {
                            //Debug.Log(sccspathfindcombineddatavar.openset.Count);
                            //sort openset for lowest fcost
                            //sccspathfindcombineddatavar.openset = heapSort(sccspathfindcombineddatavar.openset, sccspathfindcombineddatavar.openset.Count, "fcost");
                            heapSort(sccspathfindcombineddatavar.openset, sccspathfindcombineddatavar.openset.Count, "fcost");
                        }*/
                        /*
                        thegridlinknode = sccspathfindcombineddatavar.openset.First();

                        //Debug.Log(sccspathfindcombineddatavar.openset.Count);
                        sccspathfindcombineddatavar.openset.RemoveAt(0);
                        //Debug.Log(sccspathfindcombineddatavar.openset.Count);

                        thegridlinknode.nodelinkedtoisgridlink = 1;*/



















                        /*
                        var someExtratiles = new List<sccspathfindextraTiles>();

                        if (neighboorandextratiles.extraTiles != null)
                        {
                            if (neighboorandextratiles.extraTiles.Count > 0)
                            {
                                someExtratiles = neighboorandextratiles.extraTiles;

                                var someTempNeighboorArray = new List<sccspathfindnode>(); //[];
                                for (var i = 0; i < someExtratiles.Count; i++)
                                {
                                    //cData.lsp = { x: (someExtratiles[i].sgp.x), y: (someExtratiles[i].sgp.y) };
                                    //cData.glip = { x: someExtratiles[i].docg.gridData.x, y: someExtratiles[i].docg.gridData.y };


                                    var gridIndex = someExtratiles[i].docg.index;

                                    if (sccspathfindcombineddatavar.log[gridIndex] == null)
                                    {


                                        var pathData = startcreategrid(gridworldsize, noderadius, gridIndex, sccspathfindcombineddatavar, node, 0);

                                        if (pathData.fSwtch == 1)
                                        {

                                        }
                                        else if (pathData.fSwtch == 2)
                                        {

                                        }
                                        else if (pathData.fSwtch == -2)
                                        {
                                            unwalkableTargetTile = 1;

                                            var data = { openSet: sccspathfindcombineddatavar.dog.openSet, currentCommand: 3, grid: sccspathfindcombineddatavar.log[node.gridIndex].grid, path: path, node: node, iot: null, PathfindCounter: pathfindCounter, PathfindCounterSwtch: pathfindCounterSwtch  };
                                        pathfindCounter++;
                                        return data;
                                    }
                                    else
                                    {

                                    }


                                    var data = pathData.openSet;

                                    sccspathfindcombineddatavar.dog.grid = pathData.grid;

                                    var neighboorandextratilesOfGrid = { grid: sccspathfindcombineddatavar.dog.grid };
                                sccspathfindcombineddatavar.log[gridIndex] = neighboorandextratilesOfGrid;
                                someTempNeighboorArray.push(data[0]);


                                continue;
                            }
                            else
                            {
                                someTempNeighboorArray.push(sccspathfindcombineddatavar.log[gridIndex].grid[someExtratiles[i].iot]);
                            }
                        }



                        for (var i = 0; i < someTempNeighboorArray.length; i++)
                        {
                            var neighboorTile =  { swtc: 0, node: someTempNeighboorArray[i], sgp: null, iot: null, iog: null };
                        neighboorandextratiles.neighboors.push(neighboorTile);*/














                        //LOOP the current grid, with the lowest fcost
                        //remove current from open.
                        //add current to closed

                        //if current is the target node
                        //return






                        //WE ARE VISUALIZING IN A SPIRAL FORM THE LIST WITH THE CURRENT CREATED GRID WITH CALCULATED GCOST/HCOST/FCOST NODES            
                        /*xx = 0;
                        yy = 0;

                        for (int x = -gridxl; x <= gridxr; x++)
                        {
                            for (int y = -gridyb; y <= gridyt; y++)
                            {
                                xx = x;
                                yy = y;

                                if (xx < 0)
                                {
                                    xx *= -1;
                                    xx = (gridxr) + xx;
                                }

                                if (yy < 0)
                                {
                                    yy *= -1;
                                    yy = (gridyt) + yy;
                                }

                                //var index = xux * (gridWorldSize.xL + gridWorldSize.xR + 1) + yuy;
                                //var index = x * (gridxl + gridxr + 1) + y;
                                var index = xx * (gridxl + gridxr + 1) + yy;

                                //if (thegrid[index].fcost)
                                //{
                                //
                                //}

                            } 
                        }*/


                        //gridworldstartlast = gridworldstart;
                    }
                }



                startpathfind = 3;
            }












        }
        catch (UnityException ex)
        {
            Debug.Log(ex.ToString());
        }
    }















    public sccspathfindcheckallsidesdata checkAllSidesGridIndex(sccspathfindnode node, sccspathfindgridWorldSize gridWorldSize, sccspathfindcombineddata cData, sccsvec2int initialPos, sccspathfindgridworldindex nodegriddata)
    {
        var neighboors = new List<sccspathfindneighboortile>();
        var extraTiles = new List<sccspathfindextraTiles>(); //[]

        for (var x = -1; x <= 1; x++)
        {
            for (var y = -1; y <= 1; y++)
            {
                if (x == 0 && y == 0)
                {
                    continue;
                }



                int xpos = (node.worldpositionx + x);
                int ypos = (node.worldpositiony + y);

                var pos = new sccsvec2int { x = xpos, y = ypos };

                var gridData = getNewGridIndex(initialPos, pos, gridWorldSize); //, cData.objt.sid
                var indexOfGrid = gridData.index;

                if (nodegriddata.gridX != gridData.gridData.gridX || nodegriddata.gridY != gridData.gridData.gridY)
                {
                    indexOfGrid = gridData.index;

                    var diffX = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(pos.x) - Mathf.Abs(gridData.gridData.x)));
                    var diffY = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(pos.y) - Mathf.Abs(gridData.gridData.y)));

                    var starterGriderPos = new sccsvec2int { x = gridData.gridData.x, y = gridData.gridData.y };

                    if (pos.x < starterGriderPos.x)
                    {
                        diffX = (gridWorldSize.xR) + diffX;
                    }
                    else if (pos.x > starterGriderPos.x)
                    {
                        //console.PrintError("testing");
                        diffX = diffX;
                    }
                    else
                    {
                        diffX = 0;
                    }

                    if (pos.y < starterGriderPos.y)
                    {
                        diffY = (gridWorldSize.yT) + diffY;
                    }
                    else if (pos.y > starterGriderPos.y)
                    {
                        diffY = diffY;
                    }
                    else
                    {
                        diffY = 0;
                    }

                    var indexer = diffX * (gridWorldSize.xL + gridWorldSize.xR + 1) + diffY;


                    if (indexOfGrid > cData.log.Count)
                    {
                        //Debug.Log("******************THERE IS A PROBLEM HERE******************");

                        var diff = indexOfGrid - cData.log.Count;

                        for (int i = 0; i < diff + 1; i++)
                        {
                            cData.log.Add(null);
                        }

                    }



                    if (cData.log[indexOfGrid] == null)
                    {
                        Debug.Log("found extra tile");
                        //neighboors.push({ swtc: 1, node: null, sgp: pos, iot: indexer, iog: indexOfGrid});
                        extraTiles.Add(new sccspathfindextraTiles { worldpositionx = xpos, worldpositiony = ypos, sgp = pos, iot = indexer, docg = gridData, iog = indexOfGrid });// sgp = pos, iot = indexer, docg = gridData });
                    }
                    else
                    {
                        var emptygridvec = new sccsvec2int();
                        emptygridvec.x = 0;
                        emptygridvec.y = 0;
                        neighboors.Add(new sccspathfindneighboortile { swtc = 0, node = cData.log[indexOfGrid][indexer], sgp = emptygridvec, iot = indexer, iog = indexOfGrid });
                    }
                }
                else
                {
                    var gridTileX = node.gridtilex + x;
                    var gridTileY = node.gridtiley + y;

                    if (gridTileX < 0)
                    {
                        gridTileX = (gridWorldSize.xR) + (gridTileX * -1);
                    }

                    if (gridTileY < 0)
                    {
                        gridTileY = (gridWorldSize.yT) + (gridTileY * -1);
                    }
                    var index = ((gridTileX) * (gridWorldSize.xL + gridWorldSize.xR + 1)) + (gridTileY);

                    var emptygridvec = new sccsvec2int();
                    emptygridvec.x = 0;
                    emptygridvec.y = 0;


                    ///neighboors.push({ swtc: 0, node: cData.log[node.gridIndex].grid[index], sgp: null, iot: null, iog: null});
                    neighboors.Add(
                        new sccspathfindneighboortile
                        {
                            swtc = 0,
                            node = cData.log[node.gridindex][index],
                            sgp = emptygridvec,
                            iot = index,
                            iog = indexOfGrid
                        }
                        );
                }



















                /*
                int xpos = Mathf.RoundToInt(node.worldpositionx + x);
                int ypos = Mathf.RoundToInt(node.worldpositiony + y);

                var pos = new sccsvec2int { x = xpos, y = ypos };

                var gridData = getNewGridIndex(initialPos, pos, gridWorldSize); //, cData.objt.sid
                var indexOfGrid = gridData.index;

                xpos = Mathf.RoundToInt(node.worldpositionx + x);
                ypos = Mathf.RoundToInt(node.worldpositiony + y);
                pos = new sccsvec2int { x = xpos, y = ypos };
                if (xpos >= node.gridposx - gridWorldSize.xL && xpos <= node.gridposx + gridWorldSize.xR &&
                    ypos >= node.gridposy - gridWorldSize.yB && ypos <= node.gridposy + gridWorldSize.yT)
                {
                    var gridTileX = node.gridtilex + x;
                    var gridTileY = node.gridtiley + y;

                    if (gridTileX < 0)
                    {
                        gridTileX = (gridWorldSize.xR) + (gridTileX * -1);
                    }

                    if (gridTileY < 0)
                    {
                        gridTileY = (gridWorldSize.yT) + (gridTileY * -1);
                    }
                    var index = ((gridTileX) * (gridWorldSize.xL + gridWorldSize.xR + 1)) + (gridTileY);


                    var emptygridvec = new sccsvec2int();
                    emptygridvec.x = 0;
                    emptygridvec.y = 0;


                    ///neighboors.push({ swtc: 0, node: cData.log[node.gridIndex].grid[index], sgp: null, iot: null, iog: null});
                    neighboors.Add(
                        new sccspathfindneighboortile
                        {
                            swtc = 0,
                            node = cData.log[node.gridindex][index],
                            sgp = emptygridvec,
                            iot = -1,
                            iog = -1
                        }
                        );
                }
                else
                {
                    gridData = getNewGridIndex(initialPos, pos, gridWorldSize); //, cData.objt.sid

                    indexOfGrid = gridData.index;

                    var diffX = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(pos.x) - Mathf.Abs(gridData.gridData.x)));
                    var diffY = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(pos.y) - Mathf.Abs(gridData.gridData.y)));

                    var starterGriderPos = new sccsvec2int { x = gridData.gridData.x, y = gridData.gridData.y };

                    if (pos.x < starterGriderPos.x)
                    {
                        diffX = (gridWorldSize.xR) + diffX;
                    }
                    else if (pos.x > starterGriderPos.x)
                    {
                        //console.PrintError("testing");
                        diffX = diffX;
                    }
                    else
                    {
                        diffX = 0;
                    }

                    if (pos.y < starterGriderPos.y)
                    {
                        diffY = (gridWorldSize.yT) + diffY;
                    }
                    else if (pos.y > starterGriderPos.y)
                    {
                        diffY = diffY;
                    }
                    else
                    {
                        diffY = 0;
                    }

                    var indexer = diffX * (gridWorldSize.xL + gridWorldSize.xR + 1) + diffY;


                    if (indexOfGrid > cData.log.Count)
                    {
                        //Debug.Log("******************THERE IS A PROBLEM HERE******************");

                        var diff = indexOfGrid - cData.log.Count;

                        for (int i = 0;i < diff+1;i++)
                        {
                            cData.log.Add(null);
                        }

                    }



                    if (cData.log[indexOfGrid] == null)
                    {
                        //Debug.Log();
                        //neighboors.push({ swtc: 1, node: null, sgp: pos, iot: indexer, iog: indexOfGrid});
                        extraTiles.Add(new sccspathfindextraTiles { worldpositionx = xpos, worldpositiony = ypos, sgp = pos, iot = indexer, docg = gridData, iog = indexOfGrid });// sgp = pos, iot = indexer, docg = gridData });
                    }
                    else
                    {
                        var emptygridvec = new sccsvec2int();
                        emptygridvec.x = 0;
                        emptygridvec.y = 0;
                        neighboors.Add(new sccspathfindneighboortile { swtc = 0, node = cData.log[indexOfGrid][indexer], sgp = emptygridvec, iot = indexer, iog = indexOfGrid });
                    }
                }*/
            }
        }
        return new sccspathfindcheckallsidesdata { neighboors = neighboors, extraTiles = extraTiles };
    }




    /*

    public sccspathfindcheckallsidesdata checkAllSidesGridIndex(sccspathfindnode node, sccspathfindgridWorldSize gridWorldSize, sccspathfindcombineddata cData, sccsvec2int initialPos, sccspathfindgridworldindex griddata)
    {
        var neighboors = new List<sccspathfindneighboortile>();
        var extraTiles = new List<sccspathfindextraTiles>(); //[]

        for (var x = -1; x <= 1; x++)
        {
            for (var y = -1; y <= 1; y++)
            {
                if (x == 0 && y == 0)
                {
                    continue;
                }
                /*
                int xpos = Mathf.RoundToInt(node.worldpositionx + x);
                int ypos = Mathf.RoundToInt(node.worldpositiony + y);

                var pos = new sccsvec2int { x = xpos, y = ypos };

                var gridData = getNewGridIndex(initialPos, pos, gridWorldSize); //, cData.objt.sid
                var indexOfGrid = gridData.index;

                xpos = Mathf.RoundToInt(node.worldpositionx + x);
                ypos = Mathf.RoundToInt(node.worldpositiony + y);

                pos = new sccsvec2int { x = xpos, y = ypos };


                var gridTileX = node.gridtilex + x;
                var gridTileY = node.gridtiley + y;

                if (gridTileX < 0)
                {
                    gridTileX = (gridWorldSize.xR) + (gridTileX * -1);
                }

                if (gridTileY < 0)
                {
                    gridTileY = (gridWorldSize.yT) + (gridTileY * -1);
                }
                var index = ((gridTileX) * (gridWorldSize.xL + gridWorldSize.xR + 1)) + (gridTileY);


                var emptygridvec = new sccsvec2int();
                emptygridvec.x = 0;
                emptygridvec.y = 0;


                ///neighboors.push({ swtc: 0, node: cData.log[node.gridIndex].grid[index], sgp: null, iot: null, iog: null});
                neighboors.Add(
                    new sccspathfindneighboortile
                    {
                        swtc = 0,
                        node = cData.log[node.gridindex][index],
                        sgp = emptygridvec,
                        iot = index,
                        iog = indexOfGrid //- 1
                    }
                    );
                */


    /*


    gridData = getNewGridIndex(initialPos, pos, gridWorldSize); //, cData.objt.sid

    indexOfGrid = gridData.index;

    var diffX = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(pos.x) - Mathf.Abs(gridData.gridData.x)));
    var diffY = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(pos.y) - Mathf.Abs(gridData.gridData.y)));

    var starterGriderPos = new sccsvec2int { x = gridData.gridData.x, y = gridData.gridData.y };

    if (pos.x < starterGriderPos.x)
    {
        diffX = (gridWorldSize.xR) + diffX;
    }
    else if (pos.x > starterGriderPos.x)
    {
        //console.PrintError("testing");
        diffX = diffX;
    }
    else
    {
        diffX = 0;
    }

    if (pos.y < starterGriderPos.y)
    {
        diffY = (gridWorldSize.yT) + diffY;
    }
    else if (pos.y > starterGriderPos.y)
    {
        diffY = diffY;
    }
    else
    {
        diffY = 0;
    }

    var indexer = diffX * (gridWorldSize.xL + gridWorldSize.xR + 1) + diffY;


    if (indexOfGrid > cData.log.Count)
    {
        var diff = indexOfGrid - cData.log.Count;

        for (int i = 0; i < diff + 1; i++)
        {
            cData.log.Add(null);

        }
    }











    if(xpos >= node.gridposx || ypos >= node.gridposy)
    //if (xpos >= node.gridposx - gridWorldSize.xL && xpos <= node.gridposx + gridWorldSize.xR &&
    //   ypos >= node.gridposy - gridWorldSize.yB && ypos <= node.gridposy + gridWorldSize.yT)
    {

        gridData = getNewGridIndex(initialPos, pos, gridWorldSize); //, cData.objt.sid

        indexOfGrid = gridData.index;

        var diffX = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(pos.x) - Mathf.Abs(gridData.gridData.x)));
        var diffY = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(pos.y) - Mathf.Abs(gridData.gridData.y)));

        var starterGriderPos = new sccsvec2int { x = gridData.gridData.x, y = gridData.gridData.y };

        if (pos.x < starterGriderPos.x)
        {
            diffX = (gridWorldSize.xR) + diffX;
        }
        else if (pos.x > starterGriderPos.x)
        {
            //console.PrintError("testing");
            diffX = diffX;
        }
        else
        {
            diffX = 0;
        }

        if (pos.y < starterGriderPos.y)
        {
            diffY = (gridWorldSize.yT) + diffY;
        }
        else if (pos.y > starterGriderPos.y)
        {
            diffY = diffY;
        }
        else
        {
            diffY = 0;
        }

        var indexer = diffX * (gridWorldSize.xL + gridWorldSize.xR + 1) + diffY;


        if (indexOfGrid > cData.log.Count)
        {
            var diff = indexOfGrid - cData.log.Count;

            for (int i = 0; i < diff + 1; i++)
            {
                cData.log.Add(null);

            }
        }

        Debug.Log("found extra tile0");
        //Instantiate(tile, new Vector3(xpos, ypos), Quaternion.identity);


        if (cData.log[indexOfGrid] == null)//indexOfGrid > cData.log.Count-1)//cData.log[indexOfGrid] == null)
        {

            Debug.Log("found extra tile1");

            //Debug.Log("null tile");

            /*GameObject cubeobj1 = UnityEngine.GameObject.CreatePrimitive(PrimitiveType.Cube);
            cubeobj1.transform.position = new Vector3(xpos, ypos, 0);
            cubeobj1.transform.rotation = Quaternion.identity;
            cubeobj1.transform.localScale = new Vector3(0.75f,0.1f, 0.1f);

            //neighboors.push({ swtc: 1, node: null, sgp: pos, iot: indexer, iog: indexOfGrid});
            extraTiles.Add(new sccspathfindextraTiles { worldpositionx = xpos, worldpositiony = ypos, sgp = pos, iot = indexer, docg = gridData, iog = indexOfGrid });
            //var thegrid = startcreategrid(thegridlinknode, initialpathfindstartpos, targetpositioningrid);
        }
        else
        {
            Debug.Log("found extra tile2");

            if (cData.log[indexOfGrid] == null)
            {
                Debug.Log("need to create a new grid");
            }
            else
            {
                var emptygridvec = new sccsvec2int();
                emptygridvec.x = 0;
                emptygridvec.y = 0;
                var test = cData.log[indexOfGrid];

                if (test != null)
                {
                    //Debug.Log(indexer);
                }


                //Debug.Log(cData.log[indexOfGrid].Count);

                neighboors.Add(new sccspathfindneighboortile { swtc = 0, node = cData.log[indexOfGrid][indexer], sgp = emptygridvec, iot = indexer, iog = indexOfGrid });
            }
        }
    }
    else
    {
        var gridTileX = node.gridtilex + x;
        var gridTileY = node.gridtiley + y;

        if (gridTileX < 0)
        {
            gridTileX = (gridWorldSize.xR) + (gridTileX * -1);
        }

        if (gridTileY < 0)
        {
            gridTileY = (gridWorldSize.yT) + (gridTileY * -1);
        }
        var index = ((gridTileX) * (gridWorldSize.xL + gridWorldSize.xR + 1)) + (gridTileY);


        var emptygridvec = new sccsvec2int();
        emptygridvec.x = 0;
        emptygridvec.y = 0;


        ///neighboors.push({ swtc: 0, node: cData.log[node.gridIndex].grid[index], sgp: null, iot: null, iog: null});
        neighboors.Add(
            new sccspathfindneighboortile
            {
                swtc = 0,
                node = cData.log[node.gridindex][index],
                sgp = emptygridvec,
                iot = index,
                iog = indexOfGrid //- 1
            }
            );



    }
}
}

return new sccspathfindcheckallsidesdata { neighboors = neighboors, extraTiles = extraTiles };
}*/

    /*
    public static sccspathfindgriddatafinal getNewGridIndex(sccsvec2int initialPos, sccsvec2int seekerPos, sccspathfindgridWorldSize gridWorldSize) // , sid
    {
        //var gridData = getGridWorldPosition(initialPos, seekerPos, gridWorldSize);// , sid
        int diffX = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(seekerPos.x) - Mathf.Abs(initialPos.x)));
        int diffY = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(seekerPos.y) - Mathf.Abs(initialPos.y)));
    }*/

    /*
    public static sccspathfindgridworldindex getGridWorldPosition(sccsvec2int initialPos, sccsvec2int seekerPos, sccspathfindgridWorldSize gridWorldSize)  //yep still fail. yep. yeah... godamnit. ,int sid
    {

    }*/























    public static sccspathfindgridworldindex getGridWorldPosition(sccsvec2int initialPos, sccsvec2int seekerPos, sccspathfindgridWorldSize gridWorldSize)  //yep still fail. yep. yeah... godamnit. ,int sid
        {
            int diffX = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(seekerPos.x) - Mathf.Abs(initialPos.x)));
            int diffY = Mathf.RoundToInt(Mathf.Abs(Mathf.Abs(seekerPos.y) - Mathf.Abs(initialPos.y)));

            int currentGridPosX = 0;
            int currentGridPosY = 0;
            float dividerDecimal = 0;

            if ((gridWorldSize.xL + gridWorldSize.xR + 1) == 2)
            {

                dividerDecimal = 0.5f; //doesn't work yet as of 06th april 2021 - ninekorn => widthL = 1 and widthR = 0
            }
            else if ((gridWorldSize.xL + gridWorldSize.xR + 1) == 5)
            {

                dividerDecimal = 0.2f;
            }
            else if ((gridWorldSize.xL + gridWorldSize.xR + 1) == 10)
            {
                dividerDecimal = 0.1f;
            }
            else if ((gridWorldSize.xL + gridWorldSize.xR + 1) == 20)
            {
                dividerDecimal = 0.05f;
            }
            else if ((gridWorldSize.xL + gridWorldSize.xR + 1) == 8)
            {
                dividerDecimal = 0.125f;
            }
            else if ((gridWorldSize.xL + gridWorldSize.xR + 1) == 6)
            {
                dividerDecimal = 0.16666666666666666666666666666667f;
            }
            else if ((gridWorldSize.xL + gridWorldSize.xR + 1) == 4)
            {
                dividerDecimal = 0.25f;
            }


            var totalRemainsDivX = (diffX * dividerDecimal);
            var flooredRemainsDivX = Mathf.FloorToInt(totalRemainsDivX);
            var lastRemainsDivX = totalRemainsDivX - flooredRemainsDivX;

            var testX00 = diffX - gridWorldSize.xL - (flooredRemainsDivX * (gridWorldSize.xL + gridWorldSize.xR + 1));
            var testX01 = diffX - gridWorldSize.xR - (flooredRemainsDivX * (gridWorldSize.xL + gridWorldSize.xR + 1));

            if (seekerPos.x < initialPos.x)
            {
                if (testX00 > 0)
                {
                    flooredRemainsDivX = flooredRemainsDivX + 1;
                }
                currentGridPosX = Mathf.RoundToInt(initialPos.x - ((gridWorldSize.xL + gridWorldSize.xR + 1) * flooredRemainsDivX));
            }
            else if (seekerPos.x > initialPos.x)
            {
                if (testX01 > 0)
                {
                    flooredRemainsDivX = flooredRemainsDivX + 1;
                }
                currentGridPosX = Mathf.RoundToInt(initialPos.x + ((gridWorldSize.xL + gridWorldSize.xR + 1) * flooredRemainsDivX));
            }
            else
            {
                currentGridPosX = Mathf.RoundToInt(initialPos.x);
            }







            var totalRemainsDivY = (diffY * dividerDecimal);
            var flooredRemainsDivY = Mathf.FloorToInt(totalRemainsDivY);
            var lastRemainsDivY = totalRemainsDivY - flooredRemainsDivY;

            var testY00 = diffY - gridWorldSize.yB - (flooredRemainsDivY * (gridWorldSize.xL + gridWorldSize.xR + 1));
            var testY01 = diffY - gridWorldSize.yT - (flooredRemainsDivY * (gridWorldSize.xL + gridWorldSize.xR + 1));

            if (seekerPos.y < initialPos.y)
            {
                if (testY00 > 0)
                {
                    flooredRemainsDivY = flooredRemainsDivY + 1;
                }
                currentGridPosY = Mathf.RoundToInt(initialPos.y - ((gridWorldSize.yB + gridWorldSize.yT + 1) * flooredRemainsDivY));
            }
            else if (seekerPos.y > initialPos.y)
            {
                if (testY01 > 0)
                {
                    flooredRemainsDivY = flooredRemainsDivY + 1;
                }
                currentGridPosY = Mathf.RoundToInt(initialPos.y + ((gridWorldSize.yB + gridWorldSize.yT + 1) * flooredRemainsDivY));
            }
            else
            {
                currentGridPosY = Mathf.RoundToInt(initialPos.y);
            }



            return new sccspathfindgridworldindex { x = currentGridPosX, y = currentGridPosY, gridX = flooredRemainsDivX, gridY = flooredRemainsDivY }; // 
        }

        public static sccspathfindgriddatafinal getNewGridIndex(sccsvec2int initialPos, sccsvec2int seekerPos, sccspathfindgridWorldSize gridWorldSize) // , sid
        {
            var gridData = getGridWorldPosition(initialPos, seekerPos, gridWorldSize);// , sid

            var testX = 0;
            var testY = 0;
            var minY = 0;
            var maxY = 0;

            var minX = 0;
            var maxX = 0;

            var index = 0;

            if (gridData.x < initialPos.x)
            {
                testX = -gridData.gridX;
            }
            else
            {
                testX = gridData.gridX;
            }

            if (gridData.y < initialPos.y)
            {
                testY = -gridData.gridY;
            }
            else
            {
                testY = gridData.gridY;
            }

            var someAdder = 0;

            if (gridData.gridX >= gridData.gridY)
            {
                if (testX <= 0)
                {
                    minX = gridData.gridX; //2
                    maxX = gridData.gridX; //2

                    maxY = maxX; //2
                    minY = maxY - 1; //1


                    var currentContainedGrids = (minX + maxX) * (minY + maxY + 1); //2+2*2+1+1=4*4=16

                    if (testY >= 0) // REVISED
                    {
                        //61
                        //someAdder = (minY + gridData.gridY + 1); //4+1+1 = 6
                        //index = currentContainedGrids - (minY + maxY+1) + someAdder;//63-8 +6 = 55+6 = 61

                        //index 3
                        someAdder = (minY + gridData.gridY + 1); //
                        var tot = minY + maxY + 1;
                        index = currentContainedGrids - (tot) + someAdder;

                        //index 14
                        someAdder = (minY + gridData.gridY + 1); //1+0+1 = 2
                        tot = minY + maxY + 1; // 
                        index = currentContainedGrids - (tot) + someAdder; // 16 -

                    }
                    else // REVISED
                    {
                        //index 2
                        //someAdder = (minY - gridData.gridY + 1); //0-1+1 = 0
                        //var tot = minY + maxY + 1;
                        //index = currentContainedGrids - (tot) + someAdder;// 4 - 2 + 0 = 2

                        //index 59
                        someAdder = (minY - gridData.gridY + 1); //3-1+1 = 3

                        var tot = minY + maxY + 1;
                        index = currentContainedGrids - (tot) + someAdder;
                    }
                }
                else
                {
                    minX = gridData.gridX; //3
                    maxX = gridData.gridX; //3

                    minY = minX; //3
                    maxY = maxX; //3

                    var currentContainedGrids = (minX + maxX + 1) * (minY + maxY); // 42

                    if (testY >= 0)
                    {
                        // index 7 
                        someAdder = (minY + gridData.gridY + 1);

                        var tot = minY + maxY + 1;
                        index = currentContainedGrids + (tot) - someAdder;
                    }
                    else
                    {
                        //index47
                        someAdder = (minY - gridData.gridY + 1); // 3-2+1 = 2
                        var tot = minY + maxY + 1;
                        index = currentContainedGrids + (tot) - someAdder; //42+7 = 49 - 2 = 47
                    }
                }
            }
            else if (gridData.gridX < gridData.gridY)
            {
                if (testY <= 0)
                {
                    minY = gridData.gridY;//4
                    maxY = gridData.gridY;//4

                    minX = minY; //4
                    maxX = minX - 1; //3

                    var currentContainedGrids = (minX + maxX) * (minY + maxY);//8*7 = 56

                    someAdder = 0;
                    if (testX >= 0)
                    {
                        //index 25  => totalGrids 
                        someAdder = (minX - gridData.gridX + 1); //3-2+1 = 2
                        var tot = minY + maxY + 1;
                        index = currentContainedGrids - (tot) + someAdder; //30-7 + 2 = 25

                        //index 1  => totalGrids 
                        //someAdder = (minX - gridData.gridX+1); //1-0+1  = 2
                        //index = currentContainedGrids - (minY + maxY + 1) + someAdder; //2-1-1-1 + 2
                    }
                    else
                    {
                        //index 28 =>
                        someAdder = (minX + gridData.gridX + 1); //3+1+1 = 5
                        var tot = minY + maxY + 1; // 3+3+1 = 7
                        index = currentContainedGrids - (tot) + someAdder; //30-7 = 23 + 5 = 28

                        //index 53 =>
                        //someAdder = (minX + gridData.gridX + 1); // 4+1+1 = 6
                        //var tot = minY + maxY + 1; // 4*4*1 = 9
                        //index = currentContainedGrids - (tot) + someAdder;//56-9 = 47 + 6 = 53

                        //index 54 =>
                        //someAdder = (minX + gridData.gridX + 1); //
                        //var tot = minY + maxY + 1; //
                        //index = currentContainedGrids - (tot) + someAdder;//
                    }
                }
                else //if (testY > 0) 
                {
                    //test with index 41
                    //minY = gridData.gridY + 1;

                    minY = gridData.gridY; // 3
                    maxY = gridData.gridY; // 3

                    minX = minY; // 3
                    maxX = maxY; // 3 

                    var currentContainedGrids = (minX + maxX) * (minY + maxY); // 36 total grids.... meaning index 35 is the biggest

                    someAdder = 0;
                    if (testX >= 0)
                    {
                        //index 41
                        someAdder = (minX + gridData.gridX); // 3+2
                        index = currentContainedGrids + someAdder; // 36+5 = 41
                    }
                    else
                    {
                        //index 38 
                        someAdder = (maxX - gridData.gridX); // 3-2
                        index = currentContainedGrids + someAdder;
                    }
                }
            }

            return new sccspathfindgriddatafinal { gridData = gridData, index = index };

            //return index;
        }












        static System.Random randomer = new System.Random();
    //UnityEngine.Random randomer = new UnityEngine.Random();
    static float getSomeRandNumThousandDecimal(int minNum, int maxNum, float _decimal, int autonegative, int dontfloor)
    {
        float num = 0;

        if (dontfloor == -1)
        {
            num = (float)((randomer.NextDouble() * maxNum) + minNum); // this will get a number between 1 and 999;

            if (autonegative == 1)
            {
                num *= (randomer.NextDouble() * 2) == 1 ? 1 : -1; // this will add minus sign in 50% of cases
            }
        }
        else
        {
            num = (float)(Math.Floor(randomer.NextDouble() * maxNum) + minNum); // this will get a number between 1 and 999;

            if (autonegative == 1)
            {
                num *= Math.Floor(randomer.NextDouble() * 2) == 1 ? 1 : -1; // this will add minus sign in 50% of cases
            }
        }

        if (dontfloor == -1)
        {
            return (float)(num);
        }
        else
        {
            return (float)(num * _decimal);

        }
    }




    //steve chassé note 2021-jan-21
    //it's still a shitty way of doing it. sebastian lague probably doesn't show us all what he can do anyway and the same goes for craig perko and holistic3d and the atomic torch studios even... My whole program, i am trying to make it work for massive instancing of objects in
    //one scene and even different jitter scenes if i can bring the simple JitterDemo Scene instancing inside of this custom C# engine. But learning from those youtuber teachers was the best experience i could've gotten and not having a sebastian lague 3d pathfinding, i had to
    //start with my own strategy. To learn how to do it in 2d in Void Expanse first as the ninekorn modder. So i incorporated what i learned from sebastian lagues tutorial in Unity3d with his old pathfinding tutorial series and i had to understand how to make a per frame 
    //pathfinding solution for javascript ecma5 of void expanse. But then, trying to make covid19 objects to proove i can do close to something that can look like that, i mean someone might like a voxel cubic artist also. Sebastian Lague has the marching cubes and marching
    //squares superioty and i think craig perko and holistic3d can also use marching cubes and marching squares but i still don't want to yet. I am not done with cubic voxels. I am barely trying.

    //and i am trying to 
    //MODIFIED 2D TO 3D VERSION OF SEBASTIEN LAGUE WITH SOME MODS SIMPLY FOR VISUALLY BEING ABLE TO MODIFY TO ELLIPSOID AND OTHER GEOMETRY FORMS - it kinda works but ive got a hard time getting a perfect sphere. im not a mathematician
    //and i am a lazy programmer.
    public static float sc_check_distance_node_3d_geometry(Vector3 nodeA, Vector3 nodeB, float minx, float miny, float minz, float maxx, float maxy, float maxz) // i was thinking about using the index instead and then was like well i need the distance man.
    {
        //var pointFrontX = (1 * Math.cos(radToDeg * Math.PI / 180));
        //var pointFrontY = (1 * Math.sin(radToDeg * Math.PI / 180));

        //SEBASTIEN LAGUE 2D BLUEPRINT FOR NODE DIAGONAL OR NOT DISTANCE.
        /*var dstX = Math.Abs((nodeA.X) - (nodeB.X));
        var dstZ = Math.Abs((nodeA.Y) - (nodeB.Y));

        if (dstX > dstZ)
        {
            return 14 * dstZ + 10 * (dstX - dstZ);
        }
        return 14 * dstX + 10 * (dstZ - dstX);*/

        var dstX = Math.Abs((nodeA.x) - (nodeB.x));
        var dstY = Math.Abs((nodeA.y) - (nodeB.y));
        var dstZ = Math.Abs((nodeA.z) - (nodeB.z));

        float dstX_vs_dstZ = 0;
        float dstX_vs_dstY = 0;
        float dstY_vs_dstZ = 0;

        if (dstX > dstZ)
        {
            dstX_vs_dstZ = maxx * dstZ + minx * (dstX - dstZ);
        }
        else
        {
            dstX_vs_dstZ = maxx * dstX + minx * (dstZ - dstX);
        }

        if (dstX > dstY)
        {
            dstX_vs_dstY = maxy * dstY + miny * (dstX - dstY);
        }
        else
        {
            dstX_vs_dstY = maxy * dstX + miny * (dstY - dstX);
        }

        if (dstY > dstZ)
        {
            dstY_vs_dstZ = maxz * dstZ + minz * (dstY - dstZ);
        }
        else
        {
            dstY_vs_dstZ = maxz * dstY + minz * (dstZ - dstY);
        }

        return dstX_vs_dstY + dstX_vs_dstZ + dstY_vs_dstZ;
    }



    //MODIFIED 2D TO 3D VERSION OF SEBASTIEN LAGUE WITH SOME MODS SIMPLY FOR VISUALLY BEING ABLE TO MODIFY TO ELLIPSOID AND OTHER GEOMETRY FORMS - it kinda works but ive got a hard time getting a perfect sphere. im not a mathematician
    //and i am a lazy programmer.
    public static float sc_check_distance_node_3d(Vector3 nodeA, Vector3 nodeB, float minx, float miny, float minz, float diagmaxx, float diagmaxy, float diagmaxz, float diagminx, float diagminy, float diagminz) // i was thinking about using the index instead and then was like well i need the distance man.
    {
        //var pointFrontX = (1 * cos(radToDeg * Math.PI / 180));
        //var pointFrontY = (1 * sin(radToDeg * Math.PI / 180));

        //steve chassé's notes: 2021-jan-21
        //SEBASTIEN LAGUE 2D BLUEPRINT FOR NODE DIAGONAL. It works in void expanse too. i am so jealous of those youtubers and how good their tutorials are on youtube and i am barely even to make a decent one. i am barely even able to remove what can be portrayed as 
        //despicable comments in my scripts but that is just my inner anger of not being able to have a 3d blueprint of how to do the same thing. But i think i was able to solve the problem for my planet chunk script. it's really cool but it still lags.
        //var pointFrontX = (1 * Math.cos(radToDeg * Math.PI / 180));
        //var pointFrontY = (1 * Math.sin(radToDeg * Math.PI / 180));

        //SEBASTIEN LAGUE 2D BLUEPRINT FOR NODE DIAGONAL OR NOT DISTANCE.
        /*var dstX = Math.Abs((nodeA.X) - (nodeB.X));
        var dstZ = Math.Abs((nodeA.Y) - (nodeB.Y));

        if (dstX > dstZ)
        {
            return 14 * dstZ + 10 * (dstX - dstZ);
        }
        return 14 * dstX + 10 * (dstZ - dstX);*/

        var dstX = Math.Abs((nodeA.x) - (nodeB.x));
        var dstY = Math.Abs((nodeA.y) - (nodeB.y));
        var dstZ = Math.Abs((nodeA.z) - (nodeB.z));

        float dstX_vs_dstZ = 0;
        float dstX_vs_dstY = 0;
        float dstY_vs_dstZ = 0;

        if (dstX > dstZ)
        {
            dstX_vs_dstZ = diagmaxx * dstZ + minx * (dstX - dstZ);
        }
        else
        {
            dstX_vs_dstZ = diagminx * dstX + minx * (dstZ - dstX);
        }

        if (dstX > dstY)
        {
            dstX_vs_dstY = diagmaxy * dstY + miny * (dstX - dstY);
        }
        else
        {
            dstX_vs_dstY = diagminy * dstX + miny * (dstY - dstX);
        }

        if (dstY > dstZ)
        {
            dstY_vs_dstZ = diagmaxz * dstZ + minz * (dstY - dstZ);
        }
        else
        {
            dstY_vs_dstZ = diagminz * dstY + minz * (dstZ - dstY);
        }

        return dstX_vs_dstY + dstX_vs_dstZ + dstY_vs_dstZ;
    }

    public static float trying_ellipsoid_with_sc_sebastian_lague_check_distanceconvertedto3dkinda(Vector3 nodeA, Vector3 nodeB)
    {
        //SEBASTIEN LAGUE 2D BLUEPRINT FOR NODE DIAGONAL OR NOT DISTANCE.
        /*var dstX = Math.Abs((nodeA.X) - (nodeB.X));
        var dstZ = Math.Abs((nodeA.Y) - (nodeB.Y));

        if (dstX > dstZ)
        {
            return 14 * dstZ + 10 * (dstX - dstZ);
        }
        return 14 * dstX + 10 * (dstZ - dstX);*/


        var dstX = Math.Abs((nodeA.x) - (nodeB.x));
        var dstY = Math.Abs((nodeA.y) - (nodeB.y));
        var dstZ = Math.Abs((nodeA.z) - (nodeB.z));

        float dstX_vs_dstZ = 0;
        float dstX_vs_dstY = 0;

        if (dstX > dstZ)
        {
            dstX_vs_dstZ = 14 * dstZ + 10 * (dstX - dstZ);
        }
        else
        {
            dstX_vs_dstZ = 14 * dstX + 10 * (dstZ - dstX);
        }

        if (dstX > dstY)
        {
            dstX_vs_dstY = 14 * dstY + 10 * (dstX - dstY);
        }
        else
        {
            dstX_vs_dstY = 14 * dstX + 10 * (dstY - dstX);
        }

        /*if (dstX_vs_dstY > dstX_vs_dstZ)
        {
            return dstX_vs_dstY;
        }
        else
        {
            return dstX_vs_dstZ;
        }*/

        return dstX_vs_dstY + dstX_vs_dstZ;
    }




    /*
    public float sc_check_distance_sebastian_lague_node_3d()
    {
        if (dstX > dstZ)
        {
            if (dstX > dstY)
            {
                return 14 * dstY + 14 * dstZ + 10 * (dstX - dstZ) + 10 * (dstX - dstY);
            }
            else
            {
                return 14 * dstX + 14 * dstZ + 10 * (dstX - dstZ) + 10 * (dstY - dstX);
            }
        }

        //calculating x
        if (dstX > dstY && dstX > dstZ)
        {
            var part_00 = 14 * dstY + 10 * (dstX - dstY);
            var part_01 = 14 * dstZ + 10 * (dstX - dstZ);
            return part_00 + part_01;
        }
        else if (dstX > dstY && dstX < dstZ)
        {
            var part_00 = 14 * dstY + 10 * (dstX - dstY);
            var part_01 = 14 * dstX + 10 * (dstZ - dstX);
            return part_00 + part_01;
        }
        else if (dstX < dstY && dstX < dstZ)
        {
            var part_00 = 14 * dstX + 10 * (dstY - dstX);
            var part_01 = 14 * dstX + 10 * (dstZ - dstX);
            return part_00 + part_01;
        }
        else if (dstX < dstY && dstX > dstZ)
        {
            var part_00 = 14 * dstX + 10 * (dstY - dstX);
            var part_01 = 14 * dstZ + 10 * (dstX - dstZ);
            return part_00 + part_01;
        }
        //calculating y
        else if (dstY > dstX && dstY > dstZ)
        {
            var part_00 = 14 * dstX + 10 * (dstY - dstX);
            var part_01 = 14 * dstZ + 10 * (dstY - dstZ);
            return part_00 + part_01;
        }
        else if (dstY > dstX && dstY < dstZ)
        {
            var part_00 = 14 * dstX + 10 * (dstY - dstX);
            var part_01 = 14 * dstY + 10 * (dstZ - dstY);
            return part_00 + part_01;
        }
        else if (dstY < dstX && dstY < dstZ)
        {
            var part_00 = 14 * dstY + 10 * (dstX - dstY);
            var part_01 = 14 * dstY + 10 * (dstZ - dstY);
            return part_00 + part_01;
        }
        else if (dstY < dstX && dstY > dstZ)
        {
            var part_00 = 14 * dstY + 10 * (dstX - dstY);
            var part_01 = 14 * dstZ + 10 * (dstY - dstZ);
            return part_00 + part_01;
        }

        //calculating z
        else if (dstZ > dstX && dstZ > dstY)
        {
            var part_00 = 14 * dstX + 10 * (dstZ - dstX);
            var part_01 = 14 * dstY + 10 * (dstZ - dstY);
            return part_00 + part_01;
        }
        else if (dstZ > dstX && dstZ < dstY)
        {
            var part_00 = 14 * dstX + 10 * (dstZ - dstX);
            var part_01 = 14 * dstZ + 10 * (dstY - dstZ);
            return part_00 + part_01;
        }
        else if (dstZ < dstX && dstZ < dstY)
        {
            var part_00 = 14 * dstZ + 10 * (dstX - dstZ);
            var part_01 = 14 * dstZ + 10 * (dstY - dstZ);
            return part_00 + part_01;
        }
        else if (dstZ < dstX && dstZ > dstY)
        {
            var part_00 = 14 * dstZ + 10 * (dstX - dstZ);
            var part_01 = 14 * dstY + 10 * (dstZ - dstY);
            return part_00 + part_01;
        }*/
    //calculating diagonals ? not sure that covers them all. and it doesnt work
    /*else
    {
        var part_00 = 10 * dstX; //14
        var part_01 = 10 * dstY; //14
        var part_02 = 10 * dstZ; //14
        return 10; //part_00 + part_01 + part_02
    }
}*/


    public static float checknodedistancefloat(sccsvec2int nodea, sccsvec2int nodeb)
    {
        var dstX = Mathf.Abs((nodea.x) - (nodeb.x));
        var dstZ = Mathf.Abs((nodea.y) - (nodeb.y));

        if (dstX > dstZ)
            return 14 * dstZ + 10 * (dstX - dstZ);
        return 14 * dstX + 10 * (dstZ - dstX);
    }

    public static int checknodedistanceint(sccsvec2int nodea, sccsvec2int nodeb)
    {
        var dstX = Mathf.Abs((nodea.x) - (nodeb.x));
        var dstZ = Mathf.Abs((nodea.y) - (nodeb.y));

        if (dstX > dstZ)
        {

            return Mathf.RoundToInt(14 * dstZ + 10 * (dstX - dstZ));
        }
        return Mathf.RoundToInt(14 * dstX + 10 * (dstZ - dstX));
    }


    public static float GetDistance(sccsvec2int a, sccsvec2int b)
    {
        return Mathf.Sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
    }



    //https://www.tutorialspoint.com/heap-sort-in-chash


    static void heapSort(List<sccspathfindnode> arr, int n, string typeOfSort)// int[] arr
    {
        for (int i = n / 2 - 1; i >= 0; i--)
            heapify(arr, n, i, typeOfSort);
        for (int i = n - 1; i >= 0; i--)
        {
            sccspathfindnode temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;
            heapify(arr, i, 0, typeOfSort);
        }
    }
    static void heapify(List<sccspathfindnode> arr , int n, int i, string typeOfSort) //int[] arr
    {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        /*if (left < n && arr[left] > arr[largest])
            largest = left;
        if (right < n && arr[right] > arr[largest])
            largest = right;*/

        if (left < n && arr[left].fcost > arr[largest].fcost)
        {
            largest = left;
        }
        if (right < n && arr[right].fcost > arr[largest].fcost)
        {
            largest = right;
        }

        if (largest != i)
        {
            sccspathfindnode swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;
            heapify(arr, n, largest, typeOfSort);
        }
    }

    /*

    List<sccspathfindnode> heapSort(List<sccspathfindnode> arr, int n, string typeOfSort)
    {

        for (var i = n / 2 - 1; i >= 0; i--)
        {
            i = Mathf.FloorToInt(i);
            heapify(arr, n, i, typeOfSort);
            //console.PrintError(i);
        }
        for (var i = n - 1; i >= 0; i--)
        {
            i = Mathf.FloorToInt(i);
            //console.PrintError(i);
            var temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;
            heapify(arr, i, 0, typeOfSort);
        }
        return arr;
    }


    void heapify(List<sccspathfindnode> arr, int n, int i, string typeOfSort)
    {

        int largest;
        int left;
        int right;
        sccspathfindnode swap;

        largest = i;
        left = 2 * i + 1;
        right = 2 * i + 2;

        if (typeOfSort == "fcost")
        {
            if (left < n && arr[left].fcost > arr[largest].fcost)
            {
                largest = left;
            }
            if (right < n && arr[right].fcost > arr[largest].fcost)
            {
                largest = right;
            }

            /*if (left > n && arr[left].gcost > arr[largest].gcost) {
                largest = left;
            }
            */
            //works
            /*if (right > n && arr[right].gcost > arr[largest].gcost) {
                largest = right;
            }*/
            //works



            /*if (left < n && arr[left].gcost > arr[largest].gcost) {
                largest = left;
            }
            if (right < n && arr[right].gcost > arr[largest].gcost) {
                largest = right;
            }
        }

        if (largest != i)
        {
            swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;
            heapify(arr, n, largest, typeOfSort);
        }
    }*/

}
