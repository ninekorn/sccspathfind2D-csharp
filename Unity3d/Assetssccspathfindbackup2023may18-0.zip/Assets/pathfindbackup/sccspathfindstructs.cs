using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sccspathfindstructs : MonoBehaviour
{

    public struct sccspathfindneighboortile
    {
        public int swtc;
        public sccspathfindnode node; //
        public sccsvec2int sgp; // start grid pos
        public int iot; // index of tile
        public int iog; // indes of grid
    }

    public struct sccspathfindextraTiles
    {
        public int x;
        public int y;
        public int worldpositionx;
        public int worldpositiony;
        public int iog; //index of grid
        public sccsvec2int sgp; // start grid pos
        public int iot; // index of tile
        public sccspathfindgriddatafinal docg; //data of current grid
    }

    public class sccspathfindcombineddata
    {
        public List<sccspathfindnode> betterroutechecklist;
        public List<sccspathfindnode[]> log;
        public List<sccspathfindnode> openset;
        public List<sccspathfindnode> closedset;
        public List<sccspathfindnode> finalset;
    }

    public struct sccspathfindcheckallsidesdata
    {
        public List<sccspathfindneighboortile> neighboors;
        public List<sccspathfindextraTiles> extraTiles;
    }
    public struct sccspathfindgridWorldSize
    {
        public int xL; //x axis grid left
        public int xR; //x axis grid right
        public int yT; //y axis grid top
        public int yB; //y axis grid bottom
    }

    public struct sccspathfindnodefinal
    {
        public sccspathfindnode[] nodelist;
        public int pushaddindex;
    }



    public struct sccspathfindstationnode
    {
        public int thebyte;
        public int x;
        public int y;
        public int index;
        public int gridindex;
        public int worldpositionx;
        public int worldpositiony;
        public int gridposx;
        public int gridposy;
        public int gridtilex;
        public int gridtiley;
    }


    public struct sccspathfindnode
    {
        public int parentiog;
        public int parentiot;
        public int open;
        public int closed;
        public int nodeinitswtc;
        public int x;
        public int y;
        public int index;
        public int walkable;
        public int gridindex;
        public int worldpositionx;
        public int worldpositiony;
        public float gcost;
        public float hcost;
        public float fcost;
        public float toinitcost;


        public int gridposx;
        public int gridposy;
        public int gridtilex;
        public int gridtiley;
    }
    public struct sccspathfindgridworldindex
    {
        public int pushaddindex;
        public int flatindex;

        public int x;
        public int y;
        public int gridX;
        public int gridY;
    }
    public struct sccspathfindgriddatafinal
    {
        public sccspathfindgridworldindex gridData;
        public int index;
    }

    public struct sccsvec2int //? c# 10.0 
    {
        public int x;
        public int y;
    }

}
