﻿namespace AtomicTorch.CBND.CoreMod.Characters.Mobs
{
    using AtomicTorch.CBND.CoreMod.Characters;
    using AtomicTorch.CBND.CoreMod.CharacterSkeletons;
    using AtomicTorch.CBND.CoreMod.ConsoleCommands.Admin;
    using AtomicTorch.CBND.CoreMod.Items.Generic;
    using AtomicTorch.CBND.CoreMod.Items.Weapons.MobWeapons;
    using AtomicTorch.CBND.CoreMod.SoundPresets;
    using AtomicTorch.CBND.CoreMod.Systems.Droplists;
    using AtomicTorch.CBND.GameApi.Data.Characters;
    using AtomicTorch.CBND.GameApi.Data.Physics;
    using AtomicTorch.CBND.GameApi.Scripting;
    using AtomicTorch.CBND.GameApi.ServicesServer;
    using AtomicTorch.GameEngine.Common.DataStructures;
    using AtomicTorch.GameEngine.Common.Primitives;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using static sccspathfindstructs;
    using sccsvec2int = sccspathfindstructs.sccsvec2int;

    public class MobSnakeGreen : ProtoCharacterMob
    {

        private static readonly IWorldServerService ServerWorldService
            = Api.IsServer
                  ? Api.Server.World
                  : null;
        public override bool AiIsRunAwayFromHeavyVehicles => true;

        public override float CharacterWorldHeight => 0.8f;

        public override double MobKillExperienceMultiplier => 1.0;

        public override string Name => "Green snake";

        public override ObjectMaterial ObjectMaterial => ObjectMaterial.SoftTissues;

        public override double StatDefaultHealthMax => 50;

        public override double StatMoveSpeed => 1.65;

        protected override void PrepareProtoCharacterMob(
            out ProtoCharacterSkeleton skeleton,
            ref double scale,
            DropItemsList lootDroplist)
        {
            skeleton = GetProtoEntity<SkeletonSnakeGreen>();

            // primary loot
            lootDroplist
                .Add<ItemToxin>(count: 1);
        }

        protected override void ServerInitializeCharacterMob(ServerInitializeData data)
        {
            base.ServerInitializeCharacterMob(data);

            var weaponProto = GetProtoEntity<ItemWeaponMobSnakeBiteWeak>();
            data.PrivateState.WeaponState.SharedSetWeaponProtoOnly(weaponProto);
            data.PublicState.SharedSetCurrentWeaponProtoOnly(weaponProto);
        }






        //AtomicTorch.CBND.CoreMod.ConsoleCommands.Debug.ConsoleDebugTestNotification debug = new ConsoleCommands.Debug.ConsoleDebugTestNotification();
        sccspathfind pathfindscript;
        int startpathfindmainswtc = 0;
        sccsvec2float initialpathfindstartpos = new sccsvec2float();

        sccsvec2float initialpathfindtargetpos = new sccsvec2float();


        sccsvec2float lastinitialpathfindtargetpos = new sccsvec2float();

        int swtcdebug = 0;

        float distnpctoplayerlast = 0;
        System.Collections.Generic.List<sccsvec2int> listofobstaclesinit = new System.Collections.Generic.List<sccsvec2int>();
        ITempList<TestResult> obstacles;

        System.Collections.Generic.List<sccsvec2int> listofobstaclesontheway = new System.Collections.Generic.List<sccsvec2int>();
        ITempList<TestResult> obstaclesontheway;
        int swtcobstaclesontheway = 0;

        sccsvec2float npcposlast = new sccsvec2float();

        float lastdistsquared = 0;
        Vector2F directionnpctopathfindnodef = new Vector2F(0,0);
        ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
        float distsquared = 0;
        sccsvec2float playerpos;
        sccsvec2float npcpos;

        ICharacter playercharacter;

        float disttonode0last = 0;
        Vector2D playercharactercenter;
        Vector2D npcCharacterCenter;

        int npcmovementtype = 0;
        float disttonode = 0;



        //List<sccspathfindnode> pathfindretracedpath = new List<sccspathfindnode>();
        int pathfindretracedpathswtc = 0;
        sccspathfindnode poppednode;
        bool haspopped = false;
        bool lasthaspopped = false;
        int haspoppedcounter = 0;



        protected override void ServerUpdateMob(ServerUpdateData data)
        {
            var npccharacter = data.GameObject;
            npcmovementtype = 0;
            //haspopped = false;

            if (startpathfindmainswtc == 0)
            {
                pathfindscript = new sccspathfind();
                pathfindscript.pathfindoptionhgf = 1;//0FCOST//1HCOST//2MISCFCOSTISH
                pathfindscript.retracepathiterationadder = 1;
                pathfindscript.debugtoconsolemsg = 1;
                pathfindscript.pathfindimax = 3; //loops the pathfind 3 times per frame. //9. //PUT AT 1 MINIMUM
                pathfindscript.framecounterpathfindmax = 0;
                pathfindscript.createpathfindvisuals = 0;
                pathfindscript.retracedpathlistcountermax = 0;
                pathfindscript.startpathfind = 1;
                pathfindscript.maxRetracePath = 35;

                if (npccharacter != null)
                {
                    if (npccharacter.PhysicsBody != null)
                    {
                        npcCharacterCenter = npccharacter.Position + npccharacter.PhysicsBody.CenterOffset;

                        playercharacter = ServerCharacterAiHelper.GetClosestTargetPlayer(npccharacter);

                        if (playercharacter != null)
                        {
                            if (playercharacter.PhysicsBody != null)
                            {
                                playercharactercenter = playercharacter.Position + playercharacter.PhysicsBody.CenterOffset;

                                playerpos = new sccsvec2float();
                                playerpos.x = (float)playercharactercenter.X;
                                playerpos.y = (float)playercharactercenter.Y;

                                npcpos = new sccsvec2float();
                                npcpos.x = (float)npcCharacterCenter.X;
                                npcpos.y = (float)npcCharacterCenter.Y;

                                if (pathfindscript != null)
                                {
                                    distsquared = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

                                    lastdistsquared = distsquared;
                                }
                            }
                        }
                    }
                }
                startpathfindmainswtc = 1;
            }



            if (npccharacter != null)
            {
                if (npccharacter.PhysicsBody != null)
                {
                    npcCharacterCenter = npccharacter.Position + npccharacter.PhysicsBody.CenterOffset;

                    playercharacter = ServerCharacterAiHelper.GetClosestTargetPlayer(npccharacter);

                    if (playercharacter != null)
                    {
                        if (playercharacter.PhysicsBody != null)
                        {
                            playercharactercenter = playercharacter.Position + playercharacter.PhysicsBody.CenterOffset;

                            playerpos = new sccsvec2float();
                            playerpos.x = (float)playercharactercenter.X;
                            playerpos.y = (float)playercharactercenter.Y;

                            npcpos = new sccsvec2float();
                            npcpos.x = (float)npcCharacterCenter.X;
                            npcpos.y = (float)npcCharacterCenter.Y;

                            if (pathfindscript != null)
                            {
                                distsquared = pathfindscript.GetDistancefloat2d(playerpos, npcpos);
                                //lastdistsquared = distsquared;

                                if (distsquared < 75)
                                {



                                    //INITIALIZING PATHFIND UNWALKABLE TILES... ONLY WHEN THE PATHFIND IS IN STATUS #1
                                    //INITIALIZING PATHFIND UNWALKABLE TILES... ONLY WHEN THE PATHFIND IS IN STATUS #1
                                    if (pathfindscript.startpathfind == 1)
                                    {
                                        swtcobstaclesontheway = 0;
                                        pathfindretracedpathswtc = 0;
                                        haspoppedcounter = 0;

                                        var physicsSpace = npccharacter.PhysicsBody.PhysicsSpace;

                                        obstacles = physicsSpace.TestLine(
                                              npcCharacterCenter,
                                              playercharactercenter,
                                              CollisionGroup.Default,
                                              sendDebugEvent: true);

                                        if (listofobstaclesinit != null)
                                        {
                                            listofobstaclesinit.Clear();
                                        }
                                        else
                                        {
                                            listofobstaclesinit = new List<sccsvec2int>();
                                        }


                                        if (obstacles != null)
                                        {
                                            if (obstacles.Count > 0)
                                            {
                                                var isTraversableTile = true;
                                                foreach (var result in obstacles.AsList())
                                                {
                                                    var body = result.PhysicsBody;
                                                    if (body.AssociatedProtoTile is not null)
                                                    {
                                                        // untraversable tile - a cliff or water
                                                        isTraversableTile = false;
                                                        //break;
                                                    }

                                                    if (body.AssociatedWorldObject is not null)
                                                    {
                                                        // an obstacle - a world object
                                                        isTraversableTile = false;
                                                        //break;
                                                    }

                                                    if (isTraversableTile == false)
                                                    {
                                                        Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                                        sccsvec2int posofobstacle = new sccsvec2int();
                                                        posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                                                        posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                                                        listofobstaclesinit.Add(posofobstacle);
                                                    }
                                                }
                                            }
                                        }


                                        initialpathfindstartpos = npcpos;
                                        initialpathfindtargetpos = playerpos;
                                        pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);

                                    }
                                    //INITIALIZING PATHFIND UNWALKABLE TILES... ONLY WHEN THE PATHFIND IS IN STATUS #1
                                    //INITIALIZING PATHFIND UNWALKABLE TILES... ONLY WHEN THE PATHFIND IS IN STATUS #1
                                    else if (pathfindscript.startpathfind == 2 || pathfindscript.startpathfind == 3)
                                    {
                                        pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);
                                    }
                                    //WHILE THE PATHFIND IS NOT IN STATUS #4, LOOP PATHFIND. STATUS 4 IS TARGET POS FOUND AND PATH RETRACED.
                                    //WHILE THE PATHFIND IS NOT IN STATUS #4, LOOP PATHFIND. STATUS 4 IS TARGET POS FOUND AND PATH RETRACED.

                                    else if (pathfindscript.startpathfind == 4)
                                    {
                                        if (pathfindretracedpathswtc == 0)
                                        {

                                            if (pathfindscript.retracedpathlist != null)
                                            {


                                                if (pathfindscript.retracedpathlist.Count > 1)
                                                {
                                                    haspopped = pathfindscript.retracedpathlist.TryPop(out poppednode);
                                                    haspoppedcounter++;


                                                    /*//pathfindretracedpath = new List<sccspathfindnode>();
                                                    //pathfindretracedpath = pathfindscript.retracedpathlist;

                                                    for (int i = 0; i < pathfindscript.retracedpathlist.Count; i++)
                                                    {
                                                        pathfindretracedpath.Add(pathfindscript.retracedpathlist[i]);
                                                    }*/

                                                    adminnotify.Execute(playercharacter, "trying to remove node. result:" + haspopped);


                                                    pathfindretracedpathswtc = 1;
                                                }
                                                else
                                                {
                                                    var character0 = data.GameObject;
                                                    var currentStats0 = data.PublicState.CurrentStats;

                                                    ServerCharacterAiHelper.ProcessAggressiveAi(
                                                        character0,
                                                        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                                        isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                                        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                        distanceRetreat: 7,
                                                        distanceEnemyTooClose: 1,
                                                        distanceEnemyTooFar: 3.5,
                                                        movementDirection: out var movementDirection,
                                                        rotationAngleRad: out var rotationAngleRad);

                                                    this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);
                                                    pathfindscript.startpathfind = 1;
                                                }
                                            }
                                            else
                                            {
                                                var character0 = data.GameObject;
                                                var currentStats0 = data.PublicState.CurrentStats;

                                                ServerCharacterAiHelper.ProcessAggressiveAi(
                                                    character0,
                                                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                                    isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                    distanceRetreat: 7,
                                                    distanceEnemyTooClose: 1,
                                                    distanceEnemyTooFar: 3.5,
                                                    movementDirection: out var movementDirection,
                                                    rotationAngleRad: out var rotationAngleRad);

                                                this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);
                                                pathfindscript.startpathfind = 1;
                                            }

                                        }
















                                        if (haspopped)//pathfindscript.retracedpathlist != null && pathfindretracedpathswtc == 1)
                                        {

                                            //sccsvec2float thefirstnode = new sccsvec2float();
                                            //thefirstnode.x = pathfindretracedpath[0].worldpositionx;
                                            //thefirstnode.y = pathfindretracedpath[0].worldpositiony;


                                            //adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind);





                                            sccsvec2float thenodepos = new sccsvec2float();
                                            thenodepos.x = poppednode.worldpositionx;
                                            thenodepos.y = poppednode.worldpositiony;

                                            //sccsvec2float dirtonpc = new sccsvec2float(); // new Vector3(targetobjingridpos.x, targetobjingridpos.y, 0) 
                                            //dirtonpc.x = initialpathfindstartpos.x - 0;
                                            //dirtonpc.y = initialpathfindstartpos.y - 0;

                                            //sccsvec2float movethepoint = new sccsvec2float();// thenodepos + (dirtoplayernpc);
                                            //movethepoint.x = thenodepos.x + dirtonpc.x;
                                            //movethepoint.y = thenodepos.y + dirtonpc.y;

                                            sccsvec2float npctoinitnpcdiff = new sccsvec2float();
                                            npctoinitnpcdiff.x = (int)Math.Round((double)npcpos.x) - (int)Math.Round((double)initialpathfindstartpos.x);
                                            npctoinitnpcdiff.y = (int)Math.Round((double)npcpos.y) - (int)Math.Round((double)initialpathfindstartpos.y);



                                            //sccsvec2float thenodepos1 = new sccsvec2float();
                                            //thenodepos1.x = pathfindretracedpath[pathfindscript.retracepathlist.Count-1].worldpositionx + (int)Math.Round((double)initialpathfindstartpos.x);
                                            //thenodepos1.y = pathfindretracedpath[pathfindscript.retracepathlist.Count-1].worldpositiony + (int)Math.Round((double)initialpathfindstartpos.y);

                                            //sccsvec2float initpathpos = new sccsvec2float();// thenodepos + (dirtoplayernpc);
                                            //initpathpos.x = (int)Math.Round((double)initialpathfindstartpos.x);
                                            //initpathpos.y = (int)Math.Round((double)initialpathfindstartpos.y);

                                            disttonode = pathfindscript.GetDistancefloat2dsqrt(npctoinitnpcdiff, thenodepos);

                                            //var distnpctoplayer = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

                                            sccsvec2float dirnodetoinitpos = new sccsvec2float();
                                            dirnodetoinitpos.x = thenodepos.x - npctoinitnpcdiff.x; //-thenodepos.x;//
                                            dirnodetoinitpos.y = thenodepos.y - npctoinitnpcdiff.y; //-thenodepos.y;//

                                            //float hypothenuse = disttonode;
                                            //float opposite = dirnodetoinitpos.y;
                                            //float adjacent = dirnodetoinitpos.x;
                                            //float rotationangledeg = 0;

                                            dirnodetoinitpos.x /= disttonode;
                                            dirnodetoinitpos.y /= disttonode;

                                            //dirnodetoinitpos.x *= -1;
                                            //dirnodetoinitpos.y *= -1;

                                            directionnpctopathfindnodef = new Vector2F(dirnodetoinitpos.x, dirnodetoinitpos.y);








                                            if (((int)npctoinitnpcdiff.x == poppednode.worldpositionx && (int)npctoinitnpcdiff.y == poppednode.worldpositiony) ||
                                              (int)Math.Round((decimal)npcpos.x) == poppednode.worldpositionx + (int)Math.Round((decimal)initialpathfindstartpos.x) &&
                                              (int)Math.Round((decimal)npcpos.y) == poppednode.worldpositiony + (int)Math.Round((decimal)initialpathfindstartpos.y))
                                            {

                                                pathfindretracedpathswtc = 0;
                                                //pathfindretracedpath.RemoveAt(pathfindretracedpath.Count - 1);

                                                adminnotify.Execute(playercharacter, "node reached 0");
                                            }
                                            if (disttonode == 0 || disttonode < 1.45f)
                                            {
                                                pathfindretracedpathswtc = 0;
                                                adminnotify.Execute(playercharacter, "node reached 1");
                                            }

                                            try
                                            {



                                            }
                                            catch (Exception ex)
                                            {
                                                adminnotify.Execute(playercharacter, "exception:" + ex.ToString());

                                            }



                                            if (pathfindretracedpathswtc == 0)
                                            {
                                                float distnpctoplayersqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);

                                                if (distnpctoplayersqrt < 1.4f * 1)
                                                {
                                                    var character0 = data.GameObject;
                                                    var currentStats0 = data.PublicState.CurrentStats;

                                                    ServerCharacterAiHelper.ProcessAggressiveAi(
                                                        character0,
                                                        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                                        isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                                        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                        distanceRetreat: 7,
                                                        distanceEnemyTooClose: 1,
                                                        distanceEnemyTooFar: 3.5,
                                                        movementDirection: out var movementDirection,
                                                        rotationAngleRad: out var rotationAngleRad);

                                                    this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);
                                                    //pathfindscript.startpathfind = 1;
                                                }
                                            }
                                            else
                                            {
                                                sccsvec2float dirright = new sccsvec2float();
                                                dirright.x = 1.0f;
                                                dirright.y = 0.0f;

                                                float anglerad = Vector2F.AngleDeg(new Vector2F(directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y), new Vector2F(dirright.x, dirright.y));

                                                //pathfindscript.startpathfind = 1;
                                                var character = data.GameObject;
                                                var currentStats = data.PublicState.CurrentStats;

                                                this.ServerSetMobInput(character, directionnpctopathfindnodef, anglerad);




                                                
                                                if (swtcobstaclesontheway == 0 && haspoppedcounter > 1)
                                                {

                                                    var physicsSpace0 = npccharacter.PhysicsBody.PhysicsSpace;

                                                    obstaclesontheway = physicsSpace0.TestLine(
                                                          npcCharacterCenter,
                                                          playercharactercenter,
                                                          CollisionGroup.Default,
                                                          sendDebugEvent: true);

                                                    if (listofobstaclesontheway != null)
                                                    {
                                                        listofobstaclesontheway.Clear();
                                                    }
                                                    else
                                                    {
                                                        listofobstaclesontheway = new List<sccsvec2int>();
                                                    }

                                                    if (obstaclesontheway != null)
                                                    {
                                                        if (obstaclesontheway.Count > 0)
                                                        {
                                                            var isTraversableTile = true;
                                                            foreach (var result in obstaclesontheway.AsList())
                                                            {
                                                                var body = result.PhysicsBody;
                                                                if (body.AssociatedProtoTile is not null)
                                                                {
                                                                    // untraversable tile - a cliff or water
                                                                    isTraversableTile = false;
                                                                    //break;
                                                                }

                                                                if (body.AssociatedWorldObject is not null)
                                                                {
                                                                    // an obstacle - a world object
                                                                    isTraversableTile = false;
                                                                    //break;
                                                                }

                                                                if (isTraversableTile == false)
                                                                {
                                                                    Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                                                    sccsvec2int posofobstacle = new sccsvec2int();
                                                                    posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                                                                    posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                                                                    listofobstaclesontheway.Add(posofobstacle);
                                                                }
                                                            }



                                                            for (int i = 0; i < listofobstaclesontheway.Count; i++)
                                                            {
                                                                for (int j = 0; j < listofobstaclesinit.Count; j++)
                                                                {





                                                                    if (listofobstaclesontheway[i].x != (int)Math.Round((double)playerpos.x) && listofobstaclesontheway[i].x != (int)Math.Round((double)npcpos.x) &&
                                                                       listofobstaclesontheway[i].y != (int)Math.Round((double)playerpos.y) && listofobstaclesontheway[i].y != (int)Math.Round((double)npcpos.y))
                                                                    //if (listofobstaclesontheway[i].x != listofobstaclesinit[j].x && listofobstaclesontheway[i].x != (int)Math.Round((double)playerpos.x) && listofobstaclesontheway[i].x != (int)Math.Round((double)npcpos.x) || 
                                                                    //    listofobstaclesontheway[i].y != listofobstaclesinit[j].y && listofobstaclesontheway[i].y != (int)Math.Round((double)playerpos.y) && listofobstaclesontheway[i].y != (int)Math.Round((double)npcpos.y))
                                                                    {

                                                                        sccsvec2float dirnpctoobstacle = new sccsvec2float();
                                                                        dirnpctoobstacle.x = listofobstaclesontheway[i].x - npcpos.x;
                                                                        dirnpctoobstacle.y = listofobstaclesontheway[i].y - npcpos.y;

                                                                        sccsvec2float obstacleposition = new sccsvec2float();
                                                                        obstacleposition.x = listofobstaclesontheway[i].x;
                                                                        obstacleposition.y = listofobstaclesontheway[i].y;

                                                                        float distnpctoobstacle = pathfindscript.GetDistancefloat2dsqrt(obstacleposition, npcpos);

                                                                        dirnpctoobstacle.x /= distnpctoobstacle;
                                                                        dirnpctoobstacle.y /= distnpctoobstacle;

                                                                        float thedotnpcdirtonodevsnpctoobstacle = Dot(dirnpctoobstacle.x, dirnpctoobstacle.y, directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y);



                                                                        //adminnotify.Execute(playercharacter, "/dot:" + thedotnpcdirtonodevsnpctoobstacle);



                                                                        float distsqrt0 = pathfindscript.GetDistancefloat2dsqrt(obstacleposition, npcpos);


                                                                        if (thedotnpcdirtonodevsnpctoobstacle > 0.88f && distsqrt0 < 1.4f*3)
                                                                        {
                                                                            var character0 = data.GameObject;
                                                                            var currentStats0 = data.PublicState.CurrentStats;


                                                                            //float distsqrt0 = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);

                                                                            /*ServerCharacterAiHelper.ProcessAggressiveAi(
                                                                               character0,
                                                                               targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                                                               isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                                                               isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                                                               distanceRetreat: 7,
                                                                               distanceEnemyTooClose: 1,
                                                                               distanceEnemyTooFar: 3.5,
                                                                               movementDirection: out var movementDirection,
                                                                               rotationAngleRad: out var rotationAngleRad);
                                                                            
                                                                            this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);*/

                                                                            pathfindscript.startpathfind = 1;
                                                                        }
                                                                        else
                                                                        {
                                                                            continue;
                                                                        }


                                                                        //break;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }



                                                    swtcobstaclesontheway = 1;

                                                }







                                            }
                                        }

                                    }

                                }
                                else
                                {
                                    var character0 = data.GameObject;
                                    var currentStats0 = data.PublicState.CurrentStats;

                                    ServerCharacterAiHelper.ProcessAggressiveAi(
                                        character0,
                                        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                                        isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                                        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                        distanceRetreat: 7,
                                        distanceEnemyTooClose: 1,
                                        distanceEnemyTooFar: 3.5,
                                        movementDirection: out var movementDirection,
                                        rotationAngleRad: out var rotationAngleRad);

                                    this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);
                                    pathfindscript.startpathfind = 1;
                                }






                                                            }
                                                            else
                            {
                                var character = data.GameObject;
                                var currentStats = data.PublicState.CurrentStats;

                                ServerCharacterAiHelper.ProcessAggressiveAi(
                                    character,
                                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                                    isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                                    distanceRetreat: 7,
                                    distanceEnemyTooClose: 1,
                                    distanceEnemyTooFar: 3.5,
                                    movementDirection: out var movementDirection,
                                    rotationAngleRad: out var rotationAngleRad);

                                this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
                                pathfindscript.startpathfind = 1;

                                //npcmovementtype = 1;
                            }
                        }
                    }
                }
            }

            lasthaspopped = haspopped;
        }


        public static float DegreeToRadian(float angle)
        {
            return (float)(Math.PI * angle / 180.0f);
        }

        public static float RadianToDegree(float angle)
        {
            return (float)(angle * (180.0f / Math.PI));
        }

        public static float Dot(float aX, float aY, float bX, float bY)
        {
            return (aX * bX) + (aY * bY);
        }


        public static float normalizeradiansfromradians(float radians)
        {
            float degrees = RadianToDegree(radians);
            degrees = degrees % 180;
            if (degrees < 0)
            {
                degrees += 180;
            }
            return DegreeToRadian(degrees);  //DegreeToRadian(degrees);
        }

        public static float normalizedegreesfromdegrees(float degrees)
        {
            //float degrees = RadianToDegree(radians);
            degrees = degrees % 180;
            if (degrees < 0)
            {
                degrees += 180;
            }
            return degrees;  //DegreeToRadian(degrees);
        }
    }
}









//adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind + "/countingmaxretracepathswtc:" + pathfindscript.countingmaxretracepathswtc + "/id:" + npccharacter.Id + "/disttonode:" + disttonode);












/*
if (pathfindscript.startpathfind == 4)
{
    if (pathfindscript.retracedpathlist != null)
    {
        if (pathfindscript.retracedpathlist.Count - 2 > 0)
        {
            if (pathfindscript.retracedpathlist.Count == 1)
            {

                var character = data.GameObject;
                var currentStats = data.PublicState.CurrentStats;

                ServerCharacterAiHelper.ProcessAggressiveAi(
                    character,
                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                    isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                    distanceRetreat: 7,
                    distanceEnemyTooClose: 1,
                    distanceEnemyTooFar: 3.5,
                    movementDirection: out var movementDirection,
                    rotationAngleRad: out var rotationAngleRad);

                this.ServerSetMobInput(character, movementDirection, rotationAngleRad);



                //var distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);
                //if (distsqrt > 1.5f)
                //{
                //  
                //}
            }
            else
            {

                if (pathfindscript.retracedpathlist.Count > 1)
                {
                    //sccsvec2float thefirstnode = new sccsvec2float();
                    //thefirstnode.x = pathfindscript.retracedpathlist[0].worldpositionx;
                    //thefirstnode.y = pathfindscript.retracedpathlist[0].worldpositiony;


                    //adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind);

                    sccsvec2float thenodepos = new sccsvec2float();
                    thenodepos.x = pathfindscript.retracedpathlist[pathfindscript.retracedpathlist.Count - 1].worldpositionx;
                    thenodepos.y = pathfindscript.retracedpathlist[pathfindscript.retracedpathlist.Count - 1].worldpositiony;

                    //sccsvec2float dirtonpc = new sccsvec2float(); // new Vector3(targetobjingridpos.x, targetobjingridpos.y, 0) 
                    //dirtonpc.x = initialpathfindstartpos.x - 0;
                    //dirtonpc.y = initialpathfindstartpos.y - 0;

                    //sccsvec2float movethepoint = new sccsvec2float();// thenodepos + (dirtoplayernpc);
                    //movethepoint.x = thenodepos.x + dirtonpc.x;
                    //movethepoint.y = thenodepos.y + dirtonpc.y;

                    sccsvec2float npctoinitnpcdiff = new sccsvec2float();
                    npctoinitnpcdiff.x = (int)Math.Round((double)npcpos.x) - (int)Math.Round((double)initialpathfindstartpos.x);
                    npctoinitnpcdiff.y = (int)Math.Round((double)npcpos.y) - (int)Math.Round((double)initialpathfindstartpos.y);

                    //sccsvec2float thenodepos1 = new sccsvec2float();
                    //thenodepos1.x = pathfindscript.retracedpathlist[pathfindscript.retracepathlist.Count-1].worldpositionx + (int)Math.Round((double)initialpathfindstartpos.x);
                    //thenodepos1.y = pathfindscript.retracedpathlist[pathfindscript.retracepathlist.Count-1].worldpositiony + (int)Math.Round((double)initialpathfindstartpos.y);

                    //sccsvec2float initpathpos = new sccsvec2float();// thenodepos + (dirtoplayernpc);
                    //initpathpos.x = (int)Math.Round((double)initialpathfindstartpos.x);
                    //initpathpos.y = (int)Math.Round((double)initialpathfindstartpos.y);

                    var disttonode = pathfindscript.GetDistancefloat2dsqrt(npctoinitnpcdiff, thenodepos);

                    //var distnpctoplayer = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

                    sccsvec2float dirnodetoinitpos = new sccsvec2float();
                    dirnodetoinitpos.x = thenodepos.x - npctoinitnpcdiff.x; //-thenodepos.x;//
                    dirnodetoinitpos.y = thenodepos.y - npctoinitnpcdiff.y; //-thenodepos.y;//

                    //float hypothenuse = disttonode;
                    //float opposite = dirnodetoinitpos.y;
                    //float adjacent = dirnodetoinitpos.x;
                    //float rotationangledeg = 0;

                    dirnodetoinitpos.x /= disttonode;
                    dirnodetoinitpos.y /= disttonode;

                    //dirnodetoinitpos.x *= -1;
                    //dirnodetoinitpos.y *= -1;

                    directionnpctopathfindnodef = new Vector2F(dirnodetoinitpos.x, dirnodetoinitpos.y);

                    sccsvec2float dirright = new sccsvec2float();
                    dirright.x = 1.0f;
                    dirright.y = 0.0f;

                    float anglerad = Vector2F.AngleDeg(new Vector2F(directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y), new Vector2F(dirright.x, dirright.y));

                    //pathfindscript.startpathfind = 1;
                    var character = data.GameObject;
                    var currentStats = data.PublicState.CurrentStats;

                    this.ServerSetMobInput(character, directionnpctopathfindnodef, anglerad);


                    adminnotify.Execute(playercharacter, "disttonode:" + disttonode);




                    if (((int)npctoinitnpcdiff.x == pathfindscript.retracedpathlist[pathfindscript.retracedpathlist.Count - 1].worldpositionx && (int)npctoinitnpcdiff.y == pathfindscript.retracedpathlist[pathfindscript.retracedpathlist.Count - 1].worldpositiony) ||
                  (int)Math.Round((decimal)npcpos.x) == pathfindscript.retracedpathlist[pathfindscript.retracedpathlist.Count - 1].worldpositionx + (int)Math.Round((decimal)initialpathfindstartpos.x) &&
                  (int)Math.Round((decimal)npcpos.y) == pathfindscript.retracedpathlist[pathfindscript.retracedpathlist.Count - 1].worldpositiony + (int)Math.Round((decimal)initialpathfindstartpos.y) || disttonode < 1.45f)
                    {
                        pathfindscript.retracedpathlist.RemoveAt(pathfindscript.retracedpathlist.Count - 1);
                        adminnotify.Execute(playercharacter, "nodesinpath:" + pathfindscript.retracedpathlist.Count);
                    }
                }





                /*if (((int)npctoinitnpcdiff.x == pathfindscript.retracedpathlist[pathfindscript.retracedpathlist.Count - 1].worldpositionx && (int)npctoinitnpcdiff.y == pathfindscript.retracedpathlist[pathfindscript.retracedpathlist.Count - 1].worldpositiony) && pathfindscript.retracedpathlist­.Count == 1 || pathfindscript.retracedpathlist.Count == 1)
                {
                    //pathfindscript.retracedpathlist.RemoveAt(0);
                    //adminnotify.Execute(playercharacter, "nodesinpath:" + pathfindscript.retracedpathlist.Count);

                    character = data.GameObject;
                    currentStats = data.PublicState.CurrentStats;

                    ServerCharacterAiHelper.ProcessAggressiveAi(
                        character,
                        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                        isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                        distanceRetreat: 7,
                        distanceEnemyTooClose: 1,
                        distanceEnemyTooFar: 3.5,
                        movementDirection: out var movementDirection,
                        rotationAngleRad: out var rotationAngleRad);

                    this.ServerSetMobInput(character, movementDirection, rotationAngleRad);

                }*/

/*
if ((int)Math.Round((double)thefirstnode.x) - (int)Math.Round((double)thenodepos.x) == 0.0f && (int)Math.Round((double)thefirstnode.y) - (int)Math.Round((double)thenodepos.y) == 0.0f)
{
    character = data.GameObject;
    currentStats = data.PublicState.CurrentStats;

    ServerCharacterAiHelper.ProcessAggressiveAi(
        character,
        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
        isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
        distanceRetreat: 7,
        distanceEnemyTooClose: 1,
        distanceEnemyTooFar: 3.5,
        movementDirection: out var movementDirection,
        rotationAngleRad: out var rotationAngleRad);

    this.ServerSetMobInput(character, movementDirection, rotationAngleRad);

}



}
}

else
{
var distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);

if (distsqrt > 0.5f)
{
var character = data.GameObject;
var currentStats = data.PublicState.CurrentStats;

ServerCharacterAiHelper.ProcessAggressiveAi(
    character,
    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
    isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
    distanceRetreat: 7,
    distanceEnemyTooClose: 1,
    distanceEnemyTooFar: 3.5,
    movementDirection: out var movementDirection,
    rotationAngleRad: out var rotationAngleRad);

this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
pathfindscript.startpathfind = 1;
}
}
}
}*/






































/*
if (pathfindscript.startpathfind == 4)
{
    if (pathfindscript.retracedpathlist != null)
    {
        if (pathfindscript.retracedpathlist.Count > 0)
        {
            //adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind);

            sccsvec2float thenodepos = new sccsvec2float();
            thenodepos.x = pathfindscript.retracedpathlist[0].worldpositionx;
            thenodepos.y = pathfindscript.retracedpathlist[0].worldpositiony;

            sccsvec2float dirtonpc = new sccsvec2float(); // new Vector3(targetobjingridpos.x, targetobjingridpos.y, 0) 
            dirtonpc.x = initialpathfindstartpos.x - 0;
            dirtonpc.y = initialpathfindstartpos.y - 0;

            sccsvec2float movethepoint = new sccsvec2float();// thenodepos + (dirtoplayernpc);
            movethepoint.x = thenodepos.x + dirtonpc.x;
            movethepoint.y = thenodepos.y + dirtonpc.y;


            sccsvec2float npctoinitnpcdiff = new sccsvec2float();
            npctoinitnpcdiff.x = (int)Math.Round((double)npcpos.x) - (int)Math.Round((double)initialpathfindstartpos.x);
            npctoinitnpcdiff.y = (int)Math.Round((double)npcpos.y) - (int)Math.Round((double)initialpathfindstartpos.y);

            //sccsvec2float thenodepos1 = new sccsvec2float();
            //thenodepos1.x = pathfindscript.retracedpathlist[0].worldpositionx + (int)Math.Round((double)initialpathfindstartpos.x);
            //thenodepos1.y = pathfindscript.retracedpathlist[0].worldpositiony + (int)Math.Round((double)initialpathfindstartpos.y);


            //sccsvec2float initpathpos = new sccsvec2float();// thenodepos + (dirtoplayernpc);
            //initpathpos.x = (int)Math.Round((double)initialpathfindstartpos.x);
            //initpathpos.y = (int)Math.Round((double)initialpathfindstartpos.y);

            var disttonode = pathfindscript.GetDistancefloat2dsqrt(npctoinitnpcdiff, thenodepos);

            //var distnpctoplayer = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

            sccsvec2float dirnodetoinitpos = new sccsvec2float();
            dirnodetoinitpos.x = thenodepos.x - npctoinitnpcdiff.x; //-thenodepos.x;//
            dirnodetoinitpos.y = thenodepos.y - npctoinitnpcdiff.y; //-thenodepos.y;//

            float hypothenuse = disttonode;
            float opposite = dirnodetoinitpos.y;
            float adjacent = dirnodetoinitpos.x;
            float rotationangledeg = 0;

            dirnodetoinitpos.x /= disttonode;
            dirnodetoinitpos.y /= disttonode;

            //dirnodetoinitpos.x *= -1;
            //dirnodetoinitpos.y *= -1;

            directionnpctopathfindnodef = new Vector2F(dirnodetoinitpos.x, dirnodetoinitpos.y);

        }
    }




    if (pathfindscript.retracedpathlist.Count > 0)
    {
        sccsvec2float thenodepos = new sccsvec2float();
        thenodepos.x = pathfindscript.retracedpathlist[0].worldpositionx;
        thenodepos.y = pathfindscript.retracedpathlist[0].worldpositiony;

        sccsvec2float npctoinitnpcdiff = new sccsvec2float();
        npctoinitnpcdiff.x = (int)Math.Round((double)npcpos.x) - (int)Math.Round((double)initialpathfindstartpos.x);
        npctoinitnpcdiff.y = (int)Math.Round((double)npcpos.y) - (int)Math.Round((double)initialpathfindstartpos.y);


        var disttonode = pathfindscript.GetDistancefloat2dsqrt(npctoinitnpcdiff, thenodepos);

        //if the current node is the initial position, remove the current node
        if ((npctoinitnpcdiff.x == pathfindscript.retracedpathlist[0].worldpositionx && npctoinitnpcdiff.y == pathfindscript.retracedpathlist[0].worldpositiony) ||
            (int)Math.Round((decimal)npcpos.x) == pathfindscript.retracedpathlist[0].worldpositionx + (int)Math.Round((decimal)initialpathfindstartpos.x) &&
            (int)Math.Round((decimal)npcpos.y) == pathfindscript.retracedpathlist[0].worldpositiony + (int)Math.Round((decimal)initialpathfindstartpos.y) || disttonode < 1.4f)
        {
            pathfindscript.retracedpathlist.RemoveAt(0);
            adminnotify.Execute(playercharacter, "nodesinpath:" + pathfindscript.retracedpathlist.Count);
        }
    }

    if (pathfindscript.retracedpathlist.Count > 0)
    {
        sccsvec2float npctoinitnpcdiff = new sccsvec2float();
        npctoinitnpcdiff.x = (int)Math.Round((double)npcpos.x) - (int)Math.Round((double)initialpathfindstartpos.x);
        npctoinitnpcdiff.y = (int)Math.Round((double)npcpos.y) - (int)Math.Round((double)initialpathfindstartpos.y);

        sccsvec2float thenodepos = new sccsvec2float();
        thenodepos.x = pathfindscript.retracedpathlist[0].worldpositionx;
        thenodepos.y = pathfindscript.retracedpathlist[0].worldpositiony;

        var disttonode = pathfindscript.GetDistancefloat2dsqrt(npctoinitnpcdiff, thenodepos);
        sccsvec2float dirright = new sccsvec2float();
        dirright.x = 1.0f;
        dirright.y = 0.0f;

        float anglerad = Vector2F.AngleDeg(new Vector2F(directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y), new Vector2F(dirright.x, dirright.y));

        anglerad = normalizeradiansfromradians(anglerad);
        anglerad *= -1;

        float thedot = Dot(dirright.x, dirright.y, directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y);

        adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind + "/id:" + npccharacter.Id + "/thedot:" + thedot + "/dist:" + disttonode);

        //pathfindscript.startpathfind = 1;
        var character = data.GameObject;
        var currentStats = data.PublicState.CurrentStats;


        this.ServerSetMobInput(character, directionnpctopathfindnodef, anglerad);
    }

}
*/





















/*
if (pathfindscript.startpathfind == 4)
{


    if (pathfindscript.retracedpathlist != null)
    {
        if (pathfindscript.retracedpathlist.Count - 1 > 0)
        {
            //adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind);

            sccsvec2float thenodepos = new sccsvec2float();
            thenodepos.x = pathfindscript.retracedpathlist[0].worldpositionx;
            thenodepos.y = pathfindscript.retracedpathlist[0].worldpositiony;

            sccsvec2float dirtonpc = new sccsvec2float(); // new Vector3(targetobjingridpos.x, targetobjingridpos.y, 0) 
            dirtonpc.x = initialpathfindstartpos.x - 0;
            dirtonpc.y = initialpathfindstartpos.y - 0;

            sccsvec2float movethepoint = new sccsvec2float();// thenodepos + (dirtoplayernpc);
            movethepoint.x = thenodepos.x + dirtonpc.x;
            movethepoint.y = thenodepos.y + dirtonpc.y;


            sccsvec2float npctoinitnpcdiff = new sccsvec2float();
            npctoinitnpcdiff.x = (int)Math.Round((double)npcpos.x) - (int)Math.Round((double)initialpathfindstartpos.x);
            npctoinitnpcdiff.y = (int)Math.Round((double)npcpos.y) - (int)Math.Round((double)initialpathfindstartpos.y);

            //sccsvec2float thenodepos1 = new sccsvec2float();
            //thenodepos1.x = pathfindscript.retracedpathlist[0].worldpositionx + (int)Math.Round((double)initialpathfindstartpos.x);
            //thenodepos1.y = pathfindscript.retracedpathlist[0].worldpositiony + (int)Math.Round((double)initialpathfindstartpos.y);


            //sccsvec2float initpathpos = new sccsvec2float();// thenodepos + (dirtoplayernpc);
            //initpathpos.x = (int)Math.Round((double)initialpathfindstartpos.x);
            //initpathpos.y = (int)Math.Round((double)initialpathfindstartpos.y);

            var disttonode = pathfindscript.GetDistancefloat2dsqrt(npctoinitnpcdiff, thenodepos);

            //var distnpctoplayer = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

            sccsvec2float dirnodetoinitpos = new sccsvec2float();
            dirnodetoinitpos.x = thenodepos.x - npctoinitnpcdiff.x; //-thenodepos.x;//
            dirnodetoinitpos.y = thenodepos.y - npctoinitnpcdiff.y; //-thenodepos.y;//

            float hypothenuse = disttonode;
            float opposite = dirnodetoinitpos.y;
            float adjacent = dirnodetoinitpos.x;
            float rotationangledeg = 0;

            dirnodetoinitpos.x /= disttonode;
            dirnodetoinitpos.y /= disttonode;

            //dirnodetoinitpos.x *= -1;
            //dirnodetoinitpos.y *= -1;

            directionnpctopathfindnodef = new Vector2F(dirnodetoinitpos.x, dirnodetoinitpos.y);
            //npcmovementtype = 2;

            // (pathfindscript.retracedpathlist[0].x + (int)Math.Round((decimal)initialpathfindstartpos.x)) == (int)Math.Round((decimal)initialpathfindstartpos.x) &&
            //    (pathfindscript.retracedpathlist[0].y + (int)Math.Round((decimal)initialpathfindstartpos.y)) == (int)Math.Round((decimal)initialpathfindstartpos.y)

            //
            if (pathfindscript.retracedpathlist.Count > 0)
            {
                //if the current node is the initial position, remove the current node
                if ((npctoinitnpcdiff.x == pathfindscript.retracedpathlist[0].worldpositionx && npctoinitnpcdiff.y == pathfindscript.retracedpathlist[0].worldpositiony) ||
                (int)Math.Round((decimal)npcpos.x) == pathfindscript.retracedpathlist[0].worldpositionx + (int)Math.Round((decimal)initialpathfindstartpos.x) &&
                (int)Math.Round((decimal)npcpos.y) == pathfindscript.retracedpathlist[0].worldpositiony + (int)Math.Round((decimal)initialpathfindstartpos.y) || disttonode < 1.4f)
                {
                    pathfindscript.retracedpathlist.RemoveAt(0);
                    adminnotify.Execute(playercharacter, "nodesinpath:" + pathfindscript.retracedpathlist.Count);
                }


                var distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);

                sccsvec2float dirright = new sccsvec2float();
                dirright.x = 1.0f;
                dirright.y = 0.0f;

                float anglerad = Vector2F.AngleDeg(new Vector2F(directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y), new Vector2F(dirright.x, dirright.y));

                anglerad = normalizeradiansfromradians(anglerad);
                anglerad *= -1;

                float thedot = Dot(dirright.x, dirright.y, directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y);

                adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind + "/id:" + npccharacter.Id + "/thedot:" + thedot + "/dist:" + disttonode);

                //pathfindscript.startpathfind = 1;
                var character = data.GameObject;
                var currentStats = data.PublicState.CurrentStats;

                /*ServerCharacterAiHelper.ProcessAggressiveAi(
                    character,
                    targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                    isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                    isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                    distanceRetreat: 7,
                    distanceEnemyTooClose: 1,
                    distanceEnemyTooFar: 3,
                    movementDirection: out var movementDirection,
                    rotationAngleRad: out var rotationAngleRad);

                this.ServerSetMobInput(character, directionnpctopathfindnodef, anglerad);




            }
            else
            {
                var character0 = data.GameObject;
                var currentStats0 = data.PublicState.CurrentStats;

                ServerCharacterAiHelper.ProcessAggressiveAi(
                      character0,
                      targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                      isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                      isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                      distanceRetreat: 7,
                      distanceEnemyTooClose: 1,
                      distanceEnemyTooFar: 3.5,
                      movementDirection: out var movementDirection,
                      rotationAngleRad: out var rotationAngleRad);

                this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);
            }


            //if ( || disttonode0 <= 0.75f || disttonode0last <= disttonode0)//|| lastdistsquared < distsquared



            //if the current node is the initial position, remove the current node
        }
        else
        {
            //npcmovementtype = 1;
        }



    }
    else
    {
        //npcmovementtype = 1;
    }






    /*
    if (swtcobstaclesontheway == 0)
    {

        var physicsSpace0 = npccharacter.PhysicsBody.PhysicsSpace;

        obstaclesontheway = physicsSpace0.TestLine(
              npcCharacterCenter,
              playercharactercenter,
              CollisionGroup.Default,
              sendDebugEvent: true);

        if (listofobstaclesontheway != null)
        {
            listofobstaclesontheway.Clear();
        }
        else
        {
            listofobstaclesontheway = new List<sccsvec2int>();
        }

        if (obstaclesontheway != null)
        {
            if (obstaclesontheway.Count > 0)
            {
                var isTraversableTile = true;
                foreach (var result in obstaclesontheway.AsList())
                {
                    var body = result.PhysicsBody;
                    if (body.AssociatedProtoTile is not null)
                    {
                        // untraversable tile - a cliff or water
                        isTraversableTile = false;
                        //break;
                    }

                    if (body.AssociatedWorldObject is not null)
                    {
                        // an obstacle - a world object
                        isTraversableTile = false;
                        //break;
                    }

                    if (isTraversableTile == false)
                    {
                        Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                        sccsvec2int posofobstacle = new sccsvec2int();
                        posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                        posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                        listofobstaclesontheway.Add(posofobstacle);
                    }
                }
            }
        }

        for (int i = 0; i < listofobstaclesontheway.Count; i++)
        {
            for (int j = 0; j < listofobstaclesinit.Count; j++)
            {
                if (listofobstaclesontheway[i].x != listofobstaclesinit[j].x || listofobstaclesontheway[i].y != listofobstaclesinit[j].y)
                {
                    var character0 = data.GameObject;
                    var currentStats0 = data.PublicState.CurrentStats;


                    //float distsqrt0 = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);


                    /* ServerCharacterAiHelper.ProcessAggressiveAi(
                         character,
                         targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                         isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                         isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                         distanceRetreat: distsqrt,
                         distanceEnemyTooClose: distsqrt,
                         distanceEnemyTooFar: distsqrt,
                         movementDirection: out var movementDirection0,
                         rotationAngleRad: out var rotationAngleRad0);

                     this.ServerSetMobInput(character, movementDirection0, rotationAngleRad0);

                    ServerCharacterAiHelper.ProcessAggressiveAi(
                       character0,
                       targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                       isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                       isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                       distanceRetreat: 7,
                       distanceEnemyTooClose: 1,
                       distanceEnemyTooFar: 3.5,
                       movementDirection: out var movementDirection,
                       rotationAngleRad: out var rotationAngleRad);

                    this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);

                    pathfindscript.startpathfind = 1;
                    //break;
                }
            }
        }

        swtcobstaclesontheway = 1;

    }


    if (swtcobstaclesontheway == 1)
    {

    }*/





/*
if (distsqrt > 0.99f)
{



}
else
{
    var character = data.GameObject;
    var currentStats = data.PublicState.CurrentStats;

    ServerCharacterAiHelper.ProcessAggressiveAi(
        character,
        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
        isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
        distanceRetreat: 7,
        distanceEnemyTooClose: 1,
        distanceEnemyTooFar: 3.5,
        movementDirection: out var movementDirection,
        rotationAngleRad: out var rotationAngleRad);

    this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
}
}
*/


















/*
if (disttonode == 0 )
{
    if (pathfindretracedpath.Count > 0)
    {
        if (pathfindretracedpath.Count - 1 >= 1)
        {
            if (pathfindretracedpath[pathfindretracedpath.Count - 1].nodeinitswtc == 1)
            {
                pathfindretracedpath.RemoveAt(pathfindretracedpath.Count - 1);
                adminnotify.Execute(playercharacter, "nodesinpath:" + pathfindretracedpath.Count);
            }
        }
        else
        {
            pathfindscript.startpathfind = 1;
        }
    }
    else
    {
        pathfindscript.startpathfind = 1;
    }
}





if (pathfindretracedpath!= null)
{

    if (pathfindretracedpath.Count > 1)
    {
        if (disttonode < 1.45f || disttonode == float.NaN || disttonode == 0)
        {

            if (pathfindretracedpath.Count - 1 >= pathfindretracedpath.Count)
            {
                if (pathfindretracedpath[pathfindretracedpath.Count - 1].nodeinitswtc == 1)
                {

                    //pathfindretracedpath.RemoveRange(pathfindretracedpath.Count - 1,1);

                    pathfindretracedpath.RemoveAt(pathfindretracedpath.Count - 1);
                    adminnotify.Execute(playercharacter, "nodesinpath:" + pathfindretracedpath.Count);
                }
            }

        }
    }
}*/










/*
if (startpathfindmainswtc == 1)
{
    if (npccharacter != null)
    {
        if (npccharacter.PhysicsBody != null)
        {
            npcCharacterCenter = npccharacter.Position + npccharacter.PhysicsBody.CenterOffset;

            playercharacter = ServerCharacterAiHelper.GetClosestTargetPlayer(npccharacter);

            if (playercharacter != null)
            {
                if (playercharacter.PhysicsBody != null)
                {
                    playercharactercenter = playercharacter.Position + playercharacter.PhysicsBody.CenterOffset;

                    playerpos = new sccsvec2float();
                    playerpos.x = (float)playercharactercenter.X;
                    playerpos.y = (float)playercharactercenter.Y;

                    npcpos = new sccsvec2float();
                    npcpos.x = (float)npcCharacterCenter.X;
                    npcpos.y = (float)npcCharacterCenter.Y;                    
                }
            }
        }
    }


















    if (pathfindscript != null)
    {
        distsquared = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

        if (distsquared < 75)
        {
            if (pathfindscript.startpathfind == 1)
            {

                swtcobstaclesontheway = 0;

                var physicsSpace = npccharacter.PhysicsBody.PhysicsSpace;

                obstacles = physicsSpace.TestLine(
                      npcCharacterCenter,
                      playercharactercenter,
                      CollisionGroup.Default,
                      sendDebugEvent: true);

                if (listofobstaclesinit != null)
                {
                    listofobstaclesinit.Clear();
                }
                else
                {
                    listofobstaclesinit = new List<sccsvec2int>();
                }


                if (obstacles != null)
                {
                    if (obstacles.Count > 0)
                    {
                        var isTraversableTile = true;
                        foreach (var result in obstacles.AsList())
                        {
                            var body = result.PhysicsBody;
                            if (body.AssociatedProtoTile is not null)
                            {
                                // untraversable tile - a cliff or water
                                isTraversableTile = false;
                                //break;
                            }

                            if (body.AssociatedWorldObject is not null)
                            {
                                // an obstacle - a world object
                                isTraversableTile = false;
                                //break;
                            }

                            if (isTraversableTile == false)
                            {
                                Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                                sccsvec2int posofobstacle = new sccsvec2int();
                                posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                                posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                                listofobstaclesinit.Add(posofobstacle);
                            }
                        }
                    }
                }


                initialpathfindstartpos = npcpos;
                initialpathfindtargetpos = playerpos;
                pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);

                npcmovementtype = 1;
            }





            if (pathfindscript.startpathfind != 4)
            {
                pathfindscript.LoopPathfind(initialpathfindstartpos, initialpathfindtargetpos, listofobstaclesinit, npccharacter, playercharacter);
            }


            if (pathfindscript.startpathfind == 4)
            {
                if (pathfindscript.retracedpathlist != null)
                {
                    if (pathfindscript.retracedpathlist.Count - 1 > 0)
                    {
                        //adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind);

                        sccsvec2float thenodepos = new sccsvec2float();
                        thenodepos.x = pathfindscript.retracedpathlist[0].worldpositionx;
                        thenodepos.y = pathfindscript.retracedpathlist[0].worldpositiony;

                        sccsvec2float dirtonpc = new sccsvec2float(); // new Vector3(targetobjingridpos.x, targetobjingridpos.y, 0) 
                        dirtonpc.x = initialpathfindstartpos.x - 0;
                        dirtonpc.y = initialpathfindstartpos.y - 0;

                        sccsvec2float movethepoint = new sccsvec2float();// thenodepos + (dirtoplayernpc);
                        movethepoint.x = thenodepos.x + dirtonpc.x;
                        movethepoint.y = thenodepos.y + dirtonpc.y;

                        var disttonode = pathfindscript.GetDistancefloat2dsqrt(initialpathfindstartpos, movethepoint);

                        //var distnpctoplayer = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

                        sccsvec2float dirnodetoinitpos = new sccsvec2float();
                        dirnodetoinitpos.x = initialpathfindstartpos.x - movethepoint.x; //-thenodepos.x;//
                        dirnodetoinitpos.y = initialpathfindstartpos.y - movethepoint.y; //-thenodepos.y;//

                        float hypothenuse = disttonode;
                        float opposite = dirnodetoinitpos.y;
                        float adjacent = dirnodetoinitpos.x;
                        float rotationangledeg = 0;

                        dirnodetoinitpos.x /= disttonode;
                        dirnodetoinitpos.y /= disttonode;

                        dirnodetoinitpos.x *= -1;
                        dirnodetoinitpos.y *= -1;

                        directionnpctopathfindnodef = new Vector2F(dirnodetoinitpos.x, dirnodetoinitpos.y);
                        npcmovementtype = 2;

                    }
                }
            }
        }
        else
        {
            npcmovementtype = 1;
        }
    }





    adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind);









    if (pathfindscript.startpathfind == 4)
    {
        if (pathfindscript.retracedpathlist.Count > 0)
        {
            //if the current node is the initial position, remove the current node
            if ((pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x) == initialpathfindstartpos.x &&
                (pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y) == initialpathfindstartpos.y ||
                (int)Math.Round((decimal)npcpos.x) == pathfindscript.retracedpathlist[0].worldpositionx + (int)Math.Round((decimal)initialpathfindstartpos.x) &&
                (int)Math.Round((decimal)npcpos.y) == pathfindscript.retracedpathlist[0].worldpositiony + (int)Math.Round((decimal)initialpathfindstartpos.y))
            {
                pathfindscript.retracedpathlist.RemoveAt(0);
                adminnotify.Execute(playercharacter, "nodesinpath:" + pathfindscript.retracedpathlist.Count);
            }
        }
    }


    if (npcmovementtype == 1)
    {
        var distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);

        var character = data.GameObject;
        var currentStats = data.PublicState.CurrentStats;

        ServerCharacterAiHelper.ProcessAggressiveAi(
            character,
            targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
            isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
            isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
            distanceRetreat: 7,
            distanceEnemyTooClose: 1,
            distanceEnemyTooFar: 3.5,
            movementDirection: out var movementDirection,
            rotationAngleRad: out var rotationAngleRad);

        this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
    }
    else if (npcmovementtype == 2)
    {






        var distsqrt = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);

        sccsvec2float dirright = new sccsvec2float();
        dirright.x = 1.0f;
        dirright.y = 0.0f;

        float anglerad = Vector2F.AngleDeg(new Vector2F(directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y), new Vector2F(dirright.x, dirright.y));

        anglerad = normalizeradiansfromradians(anglerad);
        anglerad *= -1;

        float thedot = Dot(dirright.x, dirright.y, directionnpctopathfindnodef.X, directionnpctopathfindnodef.Y);

        adminnotify.Execute(playercharacter, "startpathfind:" + pathfindscript.startpathfind + "/id:" + npccharacter.Id + "/thedot:" + thedot);

        //pathfindscript.startpathfind = 1;
        var character = data.GameObject;
        var currentStats = data.PublicState.CurrentStats;

        /*ServerCharacterAiHelper.ProcessAggressiveAi(
            character,
            targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
            isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
            isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
            distanceRetreat: 7,
            distanceEnemyTooClose: 1,
            distanceEnemyTooFar: 3,
            movementDirection: out var movementDirection,
            rotationAngleRad: out var rotationAngleRad);

        this.ServerSetMobInput(character, directionnpctopathfindnodef, anglerad);









        if (swtcobstaclesontheway == 0)
        {

            var physicsSpace0 = npccharacter.PhysicsBody.PhysicsSpace;

            obstaclesontheway = physicsSpace0.TestLine(
                  npcCharacterCenter,
                  playercharactercenter,
                  CollisionGroup.Default,
                  sendDebugEvent: true);

            if (listofobstaclesontheway != null)
            {
                listofobstaclesontheway.Clear();
            }
            else
            {
                listofobstaclesontheway = new List<sccsvec2int>();
            }

            if (obstaclesontheway != null)
            {
                if (obstaclesontheway.Count > 0)
                {
                    var isTraversableTile = true;
                    foreach (var result in obstaclesontheway.AsList())
                    {
                        var body = result.PhysicsBody;
                        if (body.AssociatedProtoTile is not null)
                        {
                            // untraversable tile - a cliff or water
                            isTraversableTile = false;
                            //break;
                        }

                        if (body.AssociatedWorldObject is not null)
                        {
                            // an obstacle - a world object
                            isTraversableTile = false;
                            //break;
                        }

                        if (isTraversableTile == false)
                        {
                            Vector2Ushort vec = body.Position.ToVector2Ushort();// + new Vector2Ushort(testPhysicsBody.CenterOffset.X, testPhysicsBody.CenterOffset.Y);

                            sccsvec2int posofobstacle = new sccsvec2int();
                            posofobstacle.x = (int)Math.Round((decimal)vec.X) + (int)Math.Round((decimal)body.CenterOffset.X);
                            posofobstacle.y = (int)Math.Round((decimal)vec.Y) + (int)Math.Round((decimal)body.CenterOffset.Y);

                            listofobstaclesontheway.Add(posofobstacle);
                        }
                    }
                }
            }

            for (int i = 0; i < listofobstaclesontheway.Count; i++)
            {
                for (int j = 0; j < listofobstaclesinit.Count; j++)
                {
                    if (listofobstaclesontheway[i].x != listofobstaclesinit[j].x || listofobstaclesontheway[i].y != listofobstaclesinit[j].y)
                    {
                        var character0 = data.GameObject;
                        var currentStats0 = data.PublicState.CurrentStats;


                        //float distsqrt0 = pathfindscript.GetDistancefloat2dsqrt(playerpos, npcpos);


                        /* ServerCharacterAiHelper.ProcessAggressiveAi(
                             character,
                             targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
                             isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
                             isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                             distanceRetreat: distsqrt,
                             distanceEnemyTooClose: distsqrt,
                             distanceEnemyTooFar: distsqrt,
                             movementDirection: out var movementDirection0,
                             rotationAngleRad: out var rotationAngleRad0);

                         this.ServerSetMobInput(character, movementDirection0, rotationAngleRad0);

                        ServerCharacterAiHelper.ProcessAggressiveAi(
                           character0,
                           targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character0),
                           isRetreating: currentStats0.HealthCurrent < currentStats0.HealthMax / 3,
                           isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
                           distanceRetreat: 7,
                           distanceEnemyTooClose: 1,
                           distanceEnemyTooFar: 3.5,
                           movementDirection: out var movementDirection,
                           rotationAngleRad: out var rotationAngleRad);

                        this.ServerSetMobInput(character0, movementDirection, rotationAngleRad);

                        pathfindscript.startpathfind = 1;
                    }
                }
            }

            swtcobstaclesontheway = 1;

        }

    }




    /*
    if (distsqrt > 0.99f)
    {



    }
    else
    {
        var character = data.GameObject;
        var currentStats = data.PublicState.CurrentStats;

        ServerCharacterAiHelper.ProcessAggressiveAi(
            character,
            targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
            isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
            isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
            distanceRetreat: 7,
            distanceEnemyTooClose: 1,
            distanceEnemyTooFar: 3.5,
            movementDirection: out var movementDirection,
            rotationAngleRad: out var rotationAngleRad);

        this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
    }
}
else
{
    var character = data.GameObject;
    var currentStats = data.PublicState.CurrentStats;

    ServerCharacterAiHelper.ProcessAggressiveAi(
        character,
        targetCharacter: ServerCharacterAiHelper.GetClosestTargetPlayer(character),
        isRetreating: currentStats.HealthCurrent < currentStats.HealthMax / 3,
        isRetreatingForHeavyVehicles: this.AiIsRunAwayFromHeavyVehicles,
        distanceRetreat: 7,
        distanceEnemyTooClose: 1,
        distanceEnemyTooFar: 3.5,
        movementDirection: out var movementDirection,
        rotationAngleRad: out var rotationAngleRad);

    this.ServerSetMobInput(character, movementDirection, rotationAngleRad);
}*/


















/*
sccsvec2float nodepos = new sccsvec2float();
nodepos.x = pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x;
nodepos.y = pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y;

var disttonode = pathfindscript.GetDistancefloat2d(initialpathfindstartpos, nodepos);

sccsvec2float directionnpctopathfindnode = new sccsvec2float();
directionnpctopathfindnode.x = ((pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x) - initialpathfindstartpos.x);
directionnpctopathfindnode.y = ((pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y) - initialpathfindstartpos.y);
*/

/*
if ((pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x) == initialpathfindstartpos.x &&
    (pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y) == initialpathfindstartpos.y)
{
    pathfindscript.retracedpathlist.RemoveAt(0);

    adminnotify.Execute(playercharacter, "npc reached first node already. remove first node.");

}*/


/*
directionnpctopathfindnode.x /= disttonode;
directionnpctopathfindnode.y /= disttonode;
*/
/*sccsvec2float directionnpctopathfindnode = new sccsvec2float();
directionnpctopathfindnode.x = ((pathfindscript.retracedpathlist[0].x + initialpathfindstartpos.x) - npcpos.x);
directionnpctopathfindnode.y = ((pathfindscript.retracedpathlist[0].y + initialpathfindstartpos.y) - npcpos.y);

directionnpctopathfindnode.x /= disttonode;
directionnpctopathfindnode.y /= disttonode;

directionnpctopathfindnode.x = (int)Math.Round((decimal)directionnpctopathfindnode.x);
directionnpctopathfindnode.y = (int)Math.Round((decimal)directionnpctopathfindnode.y);

Vector2F directionnpctopathfindnodef = new Vector2F(directionnpctopathfindnode.x, directionnpctopathfindnode.y);*/

/*
var rotationAngleRad = npccharacter.GetPublicState<CharacterMobPublicState>()
   .AppliedInput
   .RotationAngleRad;*/

//this.ServerSetMobInput(npccharacter, directionnpctopathfindnodef, rotationAngleRad);

//Vector2F.AngleDeg();



//c2 = a2 + b2

//hypothenuse

//a = nodepos.x //adjacent
//b = nodepos.y //opposite
//c = disttonode

//sin(angle) = opposite/hypothenuse;

/*var distsquared = pathfindscript.GetDistancefloat2d(playerpos, npcpos);

sccsvec2float dirnodetoinitpos = new sccsvec2float();
dirnodetoinitpos.x = initialpathfindstartpos.x - nodepos.x;
dirnodetoinitpos.y = initialpathfindstartpos.y - nodepos.y;

float hypothenuse = disttonode;
float opposite = dirnodetoinitpos.y;
float adjacent = dirnodetoinitpos.x;
float rotationangledeg = 0;


sccsvec2float dirright = new sccsvec2float();
dirright.x = 1.0f;
dirright.y = 0.0f;
*/
/*float thedot = Dot(dirright.x, dirright.y, directionnpctopathfindnode.x, directionnpctopathfindnode.y);

//adminnotify.Execute(playercharacter, "thedot:" + thedot + "/dist:" + distsquared + "/disttonode:" + disttonode + "/dirx:" + directionnpctopathfindnode.x + "/diry:" + directionnpctopathfindnode.y + "/nodex:" + pathfindscript.retracedpathlist[0].x + "/nodey:" + pathfindscript.retracedpathlist[0].y);//

if (thedot == float.NaN)
{
    pathfindscript.retracedpathlist.RemoveAt(0);
    adminnotify.Execute(playercharacter, "thedot == nan. remove first node");
}*/



//adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared + "/nodex:" + pathfindscript.retracedpathlist[0].x + "/nodey:" + pathfindscript.retracedpathlist[0].y);



/*
if (swtcdebug == 0)
{
    for (int i = 0;i < pathfindscript.retracedpathlist.Count;i++)
    {
        adminnotify.Execute(playercharacter, "pathx:" + pathfindscript.retracedpathlist[i].worldpositionx + "/pathy:" + pathfindscript.retracedpathlist[i].worldpositiony);

    }

    swtcdebug = 1;
}*/






















/*
float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

rotationangledeg = -RadianToDegree(rotationanglerad);

adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
*/



//directionnpctopathfindnode.x = (int)Math.Round((decimal)directionnpctopathfindnode.x);
//directionnpctopathfindnode.y = (int)Math.Round((decimal)directionnpctopathfindnode.y);










//ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
//adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);

/*
if (Math.Abs(opposite) >= Math.Abs(adjacent))
{
    if (dirnodetoinitpos.y >= 0)
    {
        if (dirnodetoinitpos.x >= 0)
        {
            float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
        else
        {
            float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
    }
    else
    {
        if (dirnodetoinitpos.x >= 0)
        {
            float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
        else
        {
            float rotationanglerad = (float)Math.Asin(opposite / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
    }
}
else //if (Math.Abs(opposite) < Math.Abs(adjacent))
{
    if (dirnodetoinitpos.y >= 0)
    {
        if (dirnodetoinitpos.x >= 0)
        {
            float rotationanglerad = (float)Math.Acos(adjacent / hypothenuse);

            rotationangledeg = -RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
        else
        {
            float rotationanglerad = (float)Math.Acos(adjacent / hypothenuse);

            rotationangledeg = RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
    }
    else
    {
        if (dirnodetoinitpos.x >= 0)
        {
            float rotationanglerad = (float)Math.Acos(adjacent / hypothenuse);

            rotationangledeg = RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
        else
        {
            float rotationanglerad = (float)Math.Acos(adjacent / hypothenuse);

            rotationangledeg = RadianToDegree(rotationanglerad);

            ConsoleAdminNotifyPlayer adminnotify = new ConsoleAdminNotifyPlayer();
            adminnotify.Execute(playercharacter, "rotationangledeg:" + rotationangledeg + "/dist:" + distsquared);
        }
    }
}*/




